
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Text, Boolean
from sqlalchemy.orm import declarative_base, sessionmaker
from datetime import datetime, timedelta
import os, json, hashlib, random

app = FastAPI(title="MitoPulse v5 Guardian")
templates = Jinja2Templates(directory="templates")

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./mitopulse_v5_guardian.db")
engine = create_engine(DATABASE_URL, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

def now_dt():
    return datetime.utcnow()

# =============================
# DATA MODEL
# =============================
class Node(Base):
    __tablename__ = "nodes"
    node_id = Column(String, primary_key=True)
    label = Column(String, nullable=True)
    tenant = Column(String, default="pilot_alpha4")
    node_type = Column(String, default="mobile")
    industry = Column(String, default="banking")
    trust_rank = Column(Float, default=50.0)
    nodal_mass = Column(Float, default=20.0)
    guardian_score = Column(Float, default=0.0)
    fraud_exposure = Column(Float, default=0.0)
    pulse_count = Column(Integer, default=0)
    cross_pulse_count = Column(Integer, default=0)
    status = Column(String, default="healthy")
    last_seen = Column(DateTime, nullable=True)

class PilotUser(Base):
    __tablename__ = "pilot_users"
    pilot_user_id = Column(String, primary_key=True)
    display_name = Column(String, nullable=False)
    node_id = Column(String, unique=True, nullable=False)
    tenant = Column(String, default="pilot_alpha4")
    invite_code = Column(String, unique=True, nullable=False)
    active = Column(Boolean, default=True)
    linked_device_label = Column(String, nullable=True)
    created_at = Column(DateTime, default=now_dt)

class GuardianNode(Base):
    __tablename__ = "guardian_nodes"
    guardian_id = Column(String, primary_key=True)
    label = Column(String, nullable=False)
    tenant = Column(String, default="pilot_alpha4")
    sector = Column(String, default="banking")
    block_threshold = Column(Float, default=70.0)
    review_threshold = Column(Float, default=45.0)
    reputation = Column(Float, default=85.0)

class Edge(Base):
    __tablename__ = "edges"
    id = Column(Integer, primary_key=True, autoincrement=True)
    source = Column(String, index=True)
    target = Column(String, index=True)
    tenant = Column(String, default="pilot_alpha4")
    weight = Column(Float, default=20.0)
    shared_reality = Column(Float, default=0.0)
    interaction_count = Column(Integer, default=0)

class PilotBehaviorMemory(Base):
    __tablename__ = "pilot_behavior_memory"
    node_id = Column(String, primary_key=True)
    tenant = Column(String, default="pilot_alpha4")
    avg_daily_pulses = Column(Float, default=0.0)
    avg_weekly_relays = Column(Float, default=0.0)
    frequent_targets_json = Column(Text, default="[]")
    active_hours_json = Column(Text, default="[]")
    dominant_contexts_json = Column(Text, default="[]")
    communication_affinity_json = Column(Text, default="[]")
    baseline_score = Column(Float, default=50.0)
    updated_at = Column(DateTime, default=now_dt)

class InteractionEvent(Base):
    __tablename__ = "interaction_events"
    event_id = Column(String, primary_key=True)
    source_node_id = Column(String, index=True)
    target_node_id = Column(String, index=True)
    tenant = Column(String, default="pilot_alpha4")
    interaction_type = Column(String, default="message")
    context = Column(String, default="general")
    mutual_confirmation = Column(Boolean, default=False)
    created_at = Column(DateTime, default=now_dt)

class Evaluation(Base):
    __tablename__ = "evaluations"
    evaluation_id = Column(String, primary_key=True)
    source_node_id = Column(String)
    target_node_id = Column(String)
    tenant = Column(String)
    decision = Column(String)
    trust_score = Column(Float)
    anchor_match_score = Column(Float)
    breakdown_json = Column(Text)
    created_at = Column(DateTime, default=now_dt)

class ContactEvent(Base):
    __tablename__ = "contact_events"
    id = Column(Integer, primary_key=True, autoincrement=True)
    source_node_id = Column(String, index=True)
    target_node_id = Column(String, index=True)
    tenant = Column(String, default="pilot_alpha4")
    event_type = Column(String, default="contact_attempt")
    metadata_json = Column(Text, default="{}")
    timestamp = Column(DateTime, default=now_dt)

class PreContactAlert(Base):
    __tablename__ = "precontact_alerts"
    alert_id = Column(String, primary_key=True)
    source_node_id = Column(String)
    target_node_id = Column(String)
    tenant = Column(String)
    risk_score = Column(Float)
    severity = Column(String)
    reasons_json = Column(Text)
    created_at = Column(DateTime, default=now_dt)

class RelaySession(Base):
    __tablename__ = "relay_sessions"
    code = Column(String, primary_key=True)
    initiator = Column(String)
    tenant = Column(String, default="pilot_alpha4")

class SimulationRun(Base):
    __tablename__ = "simulation_runs"
    run_id = Column(String, primary_key=True)
    scenario = Column(String)
    status = Column(String, default="completed")
    config_json = Column(Text, default="{}")
    results_json = Column(Text, default="{}")
    created_at = Column(DateTime, default=now_dt)

Base.metadata.create_all(bind=engine)

SIM_SCENARIOS = {
    "family_scam_number_change": {"channel":"message","context":"financial_request","source":"nd_ana_01","target":"ext_impersonator_01","claimed":"nd_manu_01","hour":3},
    "marketplace_fake_receipt": {"channel":"marketplace","context":"product_release","source":"nd_bruno_01","target":"ext_buyer_01","claimed":"ext_buyer_01","hour":11},
    "urgent_financial_request": {"channel":"message","context":"urgent_transfer","source":"nd_carla_01","target":"ext_finance_01","claimed":"ext_finance_01","hour":8},
    "romance_scam_intro": {"channel":"message","context":"high_emotion","source":"nd_ana_01","target":"ext_romance_01","claimed":"ext_romance_01","hour":22},
    "wallet_phishing_link": {"channel":"crypto","context":"signature_request","source":"nd_manu_01","target":"ext_wallet_01","claimed":"ext_wallet_01","hour":10},
}

# =============================
# HELPERS
# =============================
def get_node(db, node_id, tenant="pilot_alpha4", node_type="mobile", label=None):
    n = db.query(Node).filter(Node.node_id == node_id).first()
    if not n:
        n = Node(node_id=node_id, tenant=tenant, node_type=node_type, label=label or node_id)
        db.add(n)
        db.commit()
        db.refresh(n)
    return n

def get_edge(db, a, b, tenant="pilot_alpha4"):
    return db.query(Edge).filter(
        Edge.tenant == tenant,
        (((Edge.source == a) & (Edge.target == b)) | ((Edge.source == b) & (Edge.target == a)))
    ).first()

def neighbors(db, node_id, tenant="pilot_alpha4"):
    return db.query(Edge).filter(Edge.tenant == tenant, ((Edge.source == node_id) | (Edge.target == node_id))).all()

def ensure_behavior_row(db, node_id, tenant="pilot_alpha4"):
    row = db.query(PilotBehaviorMemory).filter(PilotBehaviorMemory.node_id == node_id).first()
    if not row:
        row = PilotBehaviorMemory(node_id=node_id, tenant=tenant)
        db.add(row)
        db.commit()
        db.refresh(row)
    return row

def guardian_ids(db, tenant="pilot_alpha4"):
    return [g.guardian_id for g in db.query(GuardianNode).filter(GuardianNode.tenant == tenant).all()]

def graph_distance(db, src, tgt, tenant="pilot_alpha4", max_depth=6):
    if src == tgt:
        return 0
    frontier = [(src, 0)]
    visited = {src}
    while frontier:
        current, depth = frontier.pop(0)
        if depth >= max_depth:
            continue
        for e in neighbors(db, current, tenant):
            other = e.target if e.source == current else e.source
            if other == tgt:
                return depth + 1
            if other not in visited:
                visited.add(other)
                frontier.append((other, depth + 1))
    return None

def similarity_overlap(a, b):
    sa, sb = set(a), set(b)
    if not sa and not sb:
        return 1.0
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / max(1, len(sa | sb))

def recent_contact_stats(db, source_node_id, tenant="pilot_alpha4", minutes=60):
    cutoff = now_dt() - timedelta(minutes=minutes)
    rows = db.query(ContactEvent).filter(ContactEvent.source_node_id == source_node_id, ContactEvent.tenant == tenant, ContactEvent.timestamp >= cutoff).all()
    return len(rows), len(set(r.target_node_id for r in rows))

# =============================
# ENGINES
# =============================
def recompute_behavior_memory(db, tenant="pilot_alpha4"):
    pilots = db.query(PilotUser).filter(PilotUser.tenant == tenant, PilotUser.active == True).all()
    for u in pilots:
        n = get_node(db, u.node_id, tenant=tenant)
        rels = neighbors(db, u.node_id, tenant)
        frequent_targets = []
        contexts = {}
        channels = {}
        hours = []
        evs = db.query(InteractionEvent).filter(
            InteractionEvent.tenant == tenant,
            ((InteractionEvent.source_node_id == u.node_id) | (InteractionEvent.target_node_id == u.node_id))
        ).all()
        for ev in evs:
            other = ev.target_node_id if ev.source_node_id == u.node_id else ev.source_node_id
            frequent_targets.append(other)
            contexts[ev.context] = contexts.get(ev.context, 0) + 1
            channels[ev.interaction_type] = channels.get(ev.interaction_type, 0) + 1
            hours.append(ev.created_at.hour)
        if not hours:
            base_hour = 9 + (abs(hash(u.node_id)) % 8)
            hours = [base_hour, min(23, base_hour + 1), 19, 20]
        row = ensure_behavior_row(db, u.node_id, tenant)
        row.avg_daily_pulses = round(max(1.0, n.pulse_count / 7.0), 2)
        row.avg_weekly_relays = round(sum(r.interaction_count for r in rels) / 2.0 if rels else 0.0, 2)
        freq_top = []
        for other in set(frequent_targets):
            freq_top.append({"node_id": other, "count": frequent_targets.count(other)})
        freq_top = sorted(freq_top, key=lambda x: x["count"], reverse=True)[:5]
        row.frequent_targets_json = json.dumps(freq_top)
        row.active_hours_json = json.dumps(sorted(list(set(hours)))[:8])
        row.dominant_contexts_json = json.dumps([k for k, _v in sorted(contexts.items(), key=lambda x: x[1], reverse=True)[:5]])
        row.communication_affinity_json = json.dumps([k for k, _v in sorted(channels.items(), key=lambda x: x[1], reverse=True)[:5]])
        row.baseline_score = round(max(0, min(100, 40 + row.avg_daily_pulses * 5 + len(freq_top) * 4 + min(20, row.avg_weekly_relays * 1.5))), 2)
        row.updated_at = now_dt()
    db.commit()

def recompute_guardians(db, tenant="pilot_alpha4"):
    gids = set(guardian_ids(db, tenant))
    rows = db.query(Node).filter(Node.tenant == tenant).all()
    for n in rows:
        rels = neighbors(db, n.node_id, tenant)
        deg = len(rels)
        avgw = sum(r.weight for r in rels) / deg if deg else 0
        avgs = sum(r.shared_reality for r in rels) / deg if deg else 0
        guardian_links = sum(1 for r in rels if r.source in gids or r.target in gids)
        score = 0.20*min(100, deg*15) + 0.20*n.trust_rank + 0.15*n.nodal_mass + 0.15*min(100, n.pulse_count*5) + 0.10*avgs + 0.10*avgw + 0.10*min(100, guardian_links*20) - 0.20*n.fraud_exposure
        n.guardian_score = round(max(0, min(100, score)), 2)
    db.commit()

def recompute_fraud_spread(db, tenant="pilot_alpha4"):
    rows = db.query(Node).filter(Node.tenant == tenant).all()
    exposure = {n.node_id: max(0.0, n.fraud_exposure * 0.4) for n in rows}
    for _ in range(3):
        nxt = exposure.copy()
        for n in rows:
            spread = 0.0
            for e in neighbors(db, n.node_id, tenant):
                other = e.target if e.source == n.node_id else e.source
                spread += exposure.get(other, 0.0) * (e.weight / 100.0) * 0.18
            nxt[n.node_id] = min(100.0, max(nxt[n.node_id], round(spread, 2)))
        exposure = nxt
    for n in rows:
        n.fraud_exposure = exposure[n.node_id]
    db.commit()

def recompute_trust_waves(db, tenant="pilot_alpha4"):
    rows = db.query(Node).filter(Node.tenant == tenant).all()
    adjustments = {n.node_id: 0.0 for n in rows}
    for n in rows:
        for e in neighbors(db, n.node_id, tenant):
            other = e.target if e.source == n.node_id else e.source
            other_node = db.query(Node).filter(Node.node_id == other).first()
            wave = (e.shared_reality * 0.025) - (other_node.fraud_exposure * 0.01)
            adjustments[n.node_id] += wave
    for n in rows:
        n.trust_rank = round(max(1, min(99, n.trust_rank + adjustments[n.node_id])), 2)
    db.commit()

def anchor_match(db, candidate_node_id, claimed_node_id, tenant="pilot_alpha4", interaction_type="message", event_hour=None, context="general"):
    claimed = ensure_behavior_row(db, claimed_node_id, tenant)
    candidate_events = db.query(InteractionEvent).filter(
        InteractionEvent.tenant == tenant,
        ((InteractionEvent.source_node_id == candidate_node_id) | (InteractionEvent.target_node_id == candidate_node_id))
    ).all()
    candidate_targets, candidate_hours, candidate_contexts, candidate_channels = [], [], [], []
    for ev in candidate_events:
        other = ev.target_node_id if ev.source_node_id == candidate_node_id else ev.source_node_id
        candidate_targets.append(other)
        candidate_hours.append(ev.created_at.hour)
        candidate_contexts.append(ev.context)
        candidate_channels.append(ev.interaction_type)
    if event_hour is not None:
        candidate_hours.append(event_hour)
    candidate_contexts.append(context)
    candidate_channels.append(interaction_type)

    claimed_targets = [x["node_id"] for x in json.loads(claimed.frequent_targets_json or "[]")]
    claimed_hours = json.loads(claimed.active_hours_json or "[]")
    claimed_contexts = json.loads(claimed.dominant_contexts_json or "[]")
    claimed_channels = json.loads(claimed.communication_affinity_json or "[]")

    rpv = similarity_overlap(candidate_targets[:5], claimed_targets)
    tbv = similarity_overlap(candidate_hours[:8], claimed_hours)
    icv = similarity_overlap(candidate_contexts[:5], claimed_contexts)
    cav = similarity_overlap(candidate_channels[:5], claimed_channels)

    topo_scores = []
    for tgt in claimed_targets[:3]:
        d = graph_distance(db, candidate_node_id, tgt, tenant)
        topo_scores.append(0.0 if d is None else max(0.0, 1.0 - (d * 0.25)))
    gtv = round(sum(topo_scores)/len(topo_scores), 4) if topo_scores else 0.2

    score = round(0.25*rpv + 0.20*tbv + 0.20*icv + 0.20*gtv + 0.15*cav, 4)
    return {
        "candidate_node_id": candidate_node_id,
        "claimed_node_id": claimed_node_id,
        "anchor_match_score": score,
        "components": {"RPV": round(rpv, 4), "TBV": round(tbv, 4), "ICV": round(icv, 4), "GTV": round(gtv, 4), "CAV": round(cav, 4)}
    }

def evaluate_interaction(db, source_node_id, target_node_id, tenant="pilot_alpha4", channel="message", context="general", claimed_node_id=None, timestamp_hour=None):
    source = get_node(db, source_node_id, tenant=tenant)
    target = get_node(db, target_node_id, tenant=tenant, node_type="external" if target_node_id.startswith("ext_") else "mobile")
    edge = get_edge(db, source_node_id, target_node_id, tenant)
    dist = graph_distance(db, source_node_id, target_node_id, tenant)

    rds = edge.weight if edge else 8.0
    srs = min(100.0, (edge.shared_reality if edge else 10.0) + (15.0 if context in ("financial_request","urgent_transfer","product_release","signature_request") else 0.0))
    trust_radius_penalty = 0 if dist == 1 else 12 if dist == 2 else 24 if dist == 3 else 35
    hour = now_dt().hour if timestamp_hour is None else timestamp_hour
    behavior = ensure_behavior_row(db, source_node_id, tenant)
    active_hours = json.loads(behavior.active_hours_json or "[]")
    dominant_contexts = json.loads(behavior.dominant_contexts_json or "[]")
    behavior_penalty = 0 if hour in active_hours else 18
    if dominant_contexts and context not in dominant_contexts:
        behavior_penalty += 10

    anchor = anchor_match(db, target_node_id, claimed_node_id or target_node_id, tenant, interaction_type=channel, event_hour=hour, context=context)
    anchor_score = anchor["anchor_match_score"] * 100
    fraud_exposure = target.fraud_exposure

    score = round((0.30*rds) + (0.20*srs) + (0.20*max(0, 100 - behavior_penalty - trust_radius_penalty)) + (0.20*anchor_score) + (0.10*target.guardian_score) - fraud_exposure, 2)
    decision = "VERIFY" if score >= 80 else "REVIEW" if score >= 55 else "BLOCK"

    explain = []
    if dist is None:
        explain.append("trust radius violation")
    if behavior_penalty >= 18:
        explain.append("behavioral deviation")
    if anchor_score < 35:
        explain.append("low relational anchor match")
    if context in ("financial_request","urgent_transfer","signature_request"):
        explain.append("high-risk context")

    guardian_decisions = []
    for g in db.query(GuardianNode).filter(GuardianNode.tenant == tenant).all():
        if fraud_exposure >= g.block_threshold:
            guardian_decisions.append({"guardian_id": g.guardian_id, "decision": "BLOCK"})
            decision = "BLOCK"
        elif fraud_exposure >= g.review_threshold:
            guardian_decisions.append({"guardian_id": g.guardian_id, "decision": "REVIEW"})
            if decision == "VERIFY":
                decision = "REVIEW"

    return {
        "source_node_id": source_node_id,
        "target_node_id": target_node_id,
        "claimed_node_id": claimed_node_id or target_node_id,
        "tenant": tenant,
        "channel": channel,
        "context": context,
        "graph_distance": dist if dist is not None else "infinite",
        "anchor_match_score": round(anchor["anchor_match_score"], 4),
        "trust_score": score,
        "risk_level": "LOW" if decision == "VERIFY" else "MEDIUM" if decision == "REVIEW" else "HIGH",
        "decision": decision,
        "explainability": explain or ["interaction consistent with known pattern"],
        "breakdown": {
            "RDS": rds,
            "SRS": srs,
            "behavior_penalty": behavior_penalty,
            "trust_radius_penalty": trust_radius_penalty,
            "fraud_exposure": fraud_exposure,
            "guardian_score": target.guardian_score,
            "anchor_components": anchor["components"]
        },
        "guardian_decisions": guardian_decisions
    }

def precontact_eval(db, source_node_id, target_node_id, tenant="pilot_alpha4"):
    get_node(db, source_node_id, tenant=tenant, node_type="external", label=source_node_id)
    get_node(db, target_node_id, tenant=tenant)
    attempts, uniq = recent_contact_stats(db, source_node_id, tenant)
    score = 20
    reasons = ["source is external to the trusted pilot ring"]
    if uniq >= 2:
        score += min(30, uniq * 8)
        reasons.append(f"source contacted {uniq} unique targets in the last 60 minutes")
    if attempts >= 3:
        score += min(20, attempts * 3)
        reasons.append(f"source attempted {attempts} contacts in the last 60 minutes")
    if get_edge(db, source_node_id, target_node_id, tenant) is None:
        score += 20
        reasons.append("no prior trusted edge exists between source and target")
    severity = "LOW" if score < 45 else "MEDIUM" if score < 70 else "HIGH"
    alert_id = "pc_" + hashlib.sha256(f"{source_node_id}-{target_node_id}-{now_dt()}".encode()).hexdigest()[:12]
    db.add(PreContactAlert(alert_id=alert_id, source_node_id=source_node_id, target_node_id=target_node_id, tenant=tenant, risk_score=min(100, score), severity=severity, reasons_json=json.dumps(reasons)))
    db.commit()
    return {"alert_id": alert_id, "risk_score": min(100, score), "severity": severity, "reasons": reasons}

def simulate_attack(db, scenario_name):
    s = SIM_SCENARIOS[scenario_name]
    res = evaluate_interaction(db, s["source"], s["target"], "pilot_alpha4", channel=s["channel"], context=s["context"], claimed_node_id=s["claimed"], timestamp_hour=s["hour"])
    return {
        "scenario": scenario_name,
        "result": res,
        "network_integrity_score": round(max(0, 100 - res["breakdown"]["fraud_exposure"] - (30 if res["decision"] == "BLOCK" else 10)), 2),
        "fraud_activity_level": res["risk_level"]
    }

# =============================
# REQUEST MODELS
# =============================
class InviteIn(BaseModel):
    invite_code: str

class RegisterDeviceIn(BaseModel):
    node_id: str
    device_label: str

class PulseIn(BaseModel):
    node_id: str
    tenant: str = "pilot_alpha4"

class InteractionIn(BaseModel):
    source_node_id: str
    target_node_id: str
    tenant: str = "pilot_alpha4"
    interaction_type: str = "message"
    context: str = "general"
    mutual_confirmation: bool = True

class EvalIn(BaseModel):
    source_node_id: str
    target_node_id: str
    tenant: str = "pilot_alpha4"
    channel: str = "message"
    context: str = "general"
    claimed_node_id: str | None = None
    timestamp_hour: int | None = None

class AnchorIn(BaseModel):
    candidate_node_id: str
    claimed_node_id: str
    tenant: str = "pilot_alpha4"
    interaction_type: str = "message"
    event_hour: int | None = None
    context: str = "general"

class RelayCreateIn(BaseModel):
    node_id: str
    tenant: str = "pilot_alpha4"

class RelayConfirmIn(BaseModel):
    node_id: str
    code: str
    tenant: str = "pilot_alpha4"
    interaction_type: str = "in_person"
    context: str = "general"

class PreIn(BaseModel):
    source_node_id: str
    target_node_id: str
    tenant: str = "pilot_alpha4"
    event_type: str = "contact_attempt"
    metadata: dict = {}

class ScenarioIn(BaseModel):
    scenario: str

# =============================
# SEED
# =============================
def seed():
    db = SessionLocal()
    try:
        if db.query(PilotUser).count():
            return
        pilots = [
            ("pu_001", "Manuel", "nd_manu_01", "ALPHA-MANUEL"),
            ("pu_002", "Ana", "nd_ana_01", "ALPHA-ANA"),
            ("pu_003", "Bruno", "nd_bruno_01", "ALPHA-BRUNO"),
            ("pu_004", "Carla", "nd_carla_01", "ALPHA-CARLA"),
        ]
        for puid, name, nid, code in pilots:
            db.add(PilotUser(pilot_user_id=puid, display_name=name, node_id=nid, invite_code=code))
            db.add(Node(node_id=nid, label=name, tenant="pilot_alpha4", node_type="mobile", trust_rank=random.randint(45, 80), nodal_mass=random.randint(15, 40), pulse_count=random.randint(3, 12), cross_pulse_count=random.randint(1, 5)))
        guardians = [
            ("guardian_bank_01", "Bank Guardian", "banking", 70, 45, 90),
            ("guardian_telco_01", "Telecom Guardian", "telecom", 75, 50, 86),
            ("guardian_market_01", "Marketplace Guardian", "marketplace", 68, 42, 84),
        ]
        for gid, label, sector, bt, rt, rep in guardians:
            db.add(GuardianNode(guardian_id=gid, label=label, sector=sector, block_threshold=bt, review_threshold=rt, reputation=rep))
            db.add(Node(node_id=gid, label=label, tenant="pilot_alpha4", node_type="guardian", industry=sector, trust_rank=rep, nodal_mass=80, status="guardian"))
        edges = [
            ("nd_manu_01", "nd_ana_01", 68, 60, 6),
            ("nd_manu_01", "nd_bruno_01", 56, 44, 4),
            ("nd_ana_01", "nd_carla_01", 61, 49, 5),
            ("nd_bruno_01", "nd_carla_01", 52, 41, 3),
            ("nd_bruno_01", "guardian_bank_01", 88, 58, 4),
            ("nd_ana_01", "guardian_telco_01", 73, 45, 2),
            ("nd_manu_01", "guardian_market_01", 71, 46, 2),
        ]
        for a,b,w,sr,c in edges:
            db.add(Edge(source=a, target=b, tenant="pilot_alpha4", weight=w, shared_reality=sr, interaction_count=c))
        db.commit()
        seed_events = [
            ("ie1","nd_manu_01","nd_ana_01","message","general"),
            ("ie2","nd_manu_01","nd_bruno_01","call","general"),
            ("ie3","nd_ana_01","nd_carla_01","message","general"),
            ("ie4","nd_bruno_01","nd_carla_01","in_person","general"),
            ("ie5","nd_manu_01","nd_ana_01","financial","general"),
        ]
        for eid,s,t,it,ctx in seed_events:
            db.add(InteractionEvent(event_id=eid, source_node_id=s, target_node_id=t, interaction_type=it, context=ctx, mutual_confirmation=True))
        db.commit()
        recompute_behavior_memory(db)
        recompute_guardians(db)
        recompute_fraud_spread(db)
        recompute_trust_waves(db)
    finally:
        db.close()

seed()

# =============================
# PAGES
# =============================
@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("home.html", {"request": request})

@app.get("/pilot/dashboard", response_class=HTMLResponse)
def pilot_dashboard(request: Request):
    return templates.TemplateResponse("pilot_dashboard.html", {"request": request})

@app.get("/pilot/onboarding", response_class=HTMLResponse)
def pilot_onboarding(request: Request):
    return templates.TemplateResponse("pilot_onboarding.html", {"request": request})

@app.get("/mobile", response_class=HTMLResponse)
def mobile(request: Request):
    return templates.TemplateResponse("mobile.html", {"request": request})

@app.get("/graph", response_class=HTMLResponse)
def graph(request: Request):
    return templates.TemplateResponse("graph.html", {"request": request})

@app.get("/attack-theater", response_class=HTMLResponse)
def attack_theater(request: Request):
    return templates.TemplateResponse("attack_theater.html", {"request": request})

# =============================
# API
# =============================
@app.get("/api/platform-profile")
def api_platform_profile():
    return {
        "version": "MitoPulse_v5_Guardian",
        "pilot_ring": ["nd_manu_01", "nd_ana_01", "nd_bruno_01", "nd_carla_01"],
        "engines": ["mobile_guardian", "interaction_capture", "fast_legitimacy", "relational_anchor", "fraud_spread", "trust_waves", "guardian_layer", "attack_theater"]
    }

@app.get("/api/graph")
def api_graph(tenant: str = "pilot_alpha4"):
    db = SessionLocal()
    try:
        return {
            "nodes": [{
                "node_id": n.node_id, "label": n.label, "node_type": n.node_type,
                "trust_rank": n.trust_rank, "guardian_score": n.guardian_score,
                "fraud_exposure": n.fraud_exposure, "status": n.status
            } for n in db.query(Node).filter(Node.tenant == tenant).all()],
            "edges": [{
                "source": e.source, "target": e.target, "weight": e.weight,
                "shared_reality": e.shared_reality, "interaction_count": e.interaction_count
            } for e in db.query(Edge).filter(Edge.tenant == tenant).all()]
        }
    finally:
        db.close()

@app.get("/api/pilot/users")
def api_pilot_users():
    db = SessionLocal()
    try:
        return [{"display_name": u.display_name, "node_id": u.node_id, "invite_code": u.invite_code, "linked_device_label": u.linked_device_label} for u in db.query(PilotUser).filter(PilotUser.tenant == "pilot_alpha4").all()]
    finally:
        db.close()

@app.get("/api/pilot/behavior/{node_id}")
def api_pilot_behavior(node_id: str):
    db = SessionLocal()
    try:
        row = ensure_behavior_row(db, node_id)
        return {
            "node_id": row.node_id,
            "avg_daily_pulses": row.avg_daily_pulses,
            "avg_weekly_relays": row.avg_weekly_relays,
            "frequent_targets": json.loads(row.frequent_targets_json or "[]"),
            "active_hours": json.loads(row.active_hours_json or "[]"),
            "dominant_contexts": json.loads(row.dominant_contexts_json or "[]"),
            "communication_affinity": json.loads(row.communication_affinity_json or "[]"),
            "baseline_score": row.baseline_score
        }
    finally:
        db.close()

@app.post("/api/pilot/resolve-invite")
def api_resolve_invite(payload: InviteIn):
    db = SessionLocal()
    try:
        u = db.query(PilotUser).filter(PilotUser.invite_code == payload.invite_code, PilotUser.active == True).first()
        if not u:
            return {"ok": False, "error": "invalid_invite_code"}
        return {"ok": True, "display_name": u.display_name, "node_id": u.node_id, "tenant": u.tenant}
    finally:
        db.close()

@app.post("/api/pilot/register-device")
def api_register_device(payload: RegisterDeviceIn):
    db = SessionLocal()
    try:
        u = db.query(PilotUser).filter(PilotUser.node_id == payload.node_id).first()
        if not u:
            return {"ok": False, "error": "unknown_node"}
        u.linked_device_label = payload.device_label
        db.commit()
        return {"ok": True}
    finally:
        db.close()

@app.post("/api/pulse")
def api_pulse(payload: PulseIn):
    db = SessionLocal()
    try:
        n = get_node(db, payload.node_id, tenant=payload.tenant)
        n.pulse_count += 1
        n.nodal_mass = min(100, n.nodal_mass + 1)
        n.last_seen = now_dt()
        db.commit()
        recompute_behavior_memory(db, payload.tenant)
        recompute_guardians(db, payload.tenant)
        return {"node_id": n.node_id, "pulse_count": n.pulse_count}
    finally:
        db.close()

@app.post("/api/interaction/register")
def api_interaction_register(payload: InteractionIn):
    db = SessionLocal()
    try:
        get_node(db, payload.source_node_id, payload.tenant)
        get_node(db, payload.target_node_id, payload.tenant, node_type="external" if payload.target_node_id.startswith("ext_") else "mobile")
        event_id = "ie_" + hashlib.sha256(f"{payload.source_node_id}-{payload.target_node_id}-{now_dt()}".encode()).hexdigest()[:12]
        db.add(InteractionEvent(event_id=event_id, source_node_id=payload.source_node_id, target_node_id=payload.target_node_id, tenant=payload.tenant, interaction_type=payload.interaction_type, context=payload.context, mutual_confirmation=payload.mutual_confirmation))
        edge = get_edge(db, payload.source_node_id, payload.target_node_id, payload.tenant)
        if not edge:
            edge = Edge(source=payload.source_node_id, target=payload.target_node_id, tenant=payload.tenant, weight=25, shared_reality=18, interaction_count=0)
            db.add(edge)
        edge.weight = min(100, edge.weight + 6)
        edge.shared_reality = min(100, edge.shared_reality + (10 if payload.mutual_confirmation else 4))
        edge.interaction_count += 1
        db.commit()
        recompute_behavior_memory(db, payload.tenant)
        recompute_guardians(db, payload.tenant)
        recompute_trust_waves(db, payload.tenant)
        return {"event_id": event_id, "status": "registered"}
    finally:
        db.close()

@app.post("/api/evaluate")
def api_evaluate(payload: EvalIn):
    db = SessionLocal()
    try:
        result = evaluate_interaction(db, payload.source_node_id, payload.target_node_id, payload.tenant, payload.channel, payload.context, payload.claimed_node_id, payload.timestamp_hour)
        eid = "ev_" + hashlib.sha256(f"{payload.source_node_id}-{payload.target_node_id}-{now_dt()}".encode()).hexdigest()[:12]
        db.add(Evaluation(evaluation_id=eid, source_node_id=payload.source_node_id, target_node_id=payload.target_node_id, tenant=payload.tenant, decision=result["decision"], trust_score=result["trust_score"], anchor_match_score=result["anchor_match_score"], breakdown_json=json.dumps(result)))
        db.commit()
        result["evaluation_id"] = eid
        return result
    finally:
        db.close()

@app.post("/api/anchor/match")
def api_anchor_match(payload: AnchorIn):
    db = SessionLocal()
    try:
        return anchor_match(db, payload.candidate_node_id, payload.claimed_node_id, payload.tenant, payload.interaction_type, payload.event_hour, payload.context)
    finally:
        db.close()

@app.post("/api/relay/create")
def api_relay_create(payload: RelayCreateIn):
    db = SessionLocal()
    try:
        code = str(random.randint(1000, 9999))
        db.merge(RelaySession(code=code, initiator=payload.node_id, tenant=payload.tenant))
        db.commit()
        return {"code": code}
    finally:
        db.close()

@app.post("/api/relay/confirm")
def api_relay_confirm(payload: RelayConfirmIn):
    db = SessionLocal()
    try:
        sess = db.query(RelaySession).filter(RelaySession.code == payload.code, RelaySession.tenant == payload.tenant).first()
        if not sess:
            return {"error": "invalid_code"}
        return api_interaction_register(InteractionIn(source_node_id=sess.initiator, target_node_id=payload.node_id, tenant=payload.tenant, interaction_type=payload.interaction_type, context=payload.context, mutual_confirmation=True))
    finally:
        db.close()

@app.post("/api/pilot/precontact/attempt")
def api_precontact_attempt(payload: PreIn):
    db = SessionLocal()
    try:
        db.add(ContactEvent(source_node_id=payload.source_node_id, target_node_id=payload.target_node_id, tenant=payload.tenant, event_type=payload.event_type, metadata_json=json.dumps(payload.metadata)))
        db.commit()
        return precontact_eval(db, payload.source_node_id, payload.target_node_id, payload.tenant)
    finally:
        db.close()

@app.get("/api/pilot/precontact/alerts")
def api_pilot_precontact_alerts():
    db = SessionLocal()
    try:
        return [{
            "alert_id": a.alert_id,
            "source_node_id": a.source_node_id,
            "target_node_id": a.target_node_id,
            "risk_score": a.risk_score,
            "severity": a.severity,
            "reasons": json.loads(a.reasons_json)
        } for a in db.query(PreContactAlert).filter(PreContactAlert.tenant == "pilot_alpha4").order_by(PreContactAlert.created_at.desc()).all()]
    finally:
        db.close()

@app.post("/api/workers/run")
def api_workers_run(tenant: str = "pilot_alpha4"):
    db = SessionLocal()
    try:
        recompute_behavior_memory(db, tenant)
        recompute_guardians(db, tenant)
        recompute_fraud_spread(db, tenant)
        recompute_trust_waves(db, tenant)
        return {"status": "ok"}
    finally:
        db.close()

@app.get("/api/simulations/scenarios")
def api_scenarios():
    return SIM_SCENARIOS

@app.post("/api/simulations/run")
def api_sim_run(payload: ScenarioIn):
    db = SessionLocal()
    try:
        if payload.scenario not in SIM_SCENARIOS:
            return {"error":"unknown_scenario"}
        result = simulate_attack(db, payload.scenario)
        run_id = "sim_" + hashlib.sha256(f"{payload.scenario}-{now_dt()}".encode()).hexdigest()[:12]
        db.add(SimulationRun(run_id=run_id, scenario=payload.scenario, config_json=json.dumps(SIM_SCENARIOS[payload.scenario]), results_json=json.dumps(result)))
        db.commit()
        result["run_id"] = run_id
        return result
    finally:
        db.close()

@app.get("/api/simulations/results")
def api_sim_results():
    db = SessionLocal()
    try:
        return [{"run_id": r.run_id, "scenario": r.scenario, "created_at": r.created_at.isoformat(), "results": json.loads(r.results_json)} for r in db.query(SimulationRun).order_by(SimulationRun.created_at.desc()).all()]
    finally:
        db.close()
