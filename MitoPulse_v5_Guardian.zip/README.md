
# MitoPulse v5 Guardian

Versión avanzada del MVP.

## Incluye
- Mobile Guardian Layer
- Interaction Capture Layer
- Fast Legitimacy Engine
- Relational Anchor Engine
- Fraud Spread Engine
- Trust Waves
- Guardian Layer
- Graph Visualizer
- Attack Theater

## Ejecutar
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

## Rutas
- /
- /pilot/dashboard
- /graph
- /attack-theater
- /pilot/onboarding
- /mobile
