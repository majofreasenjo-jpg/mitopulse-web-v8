
# Manual de uso — MitoPulse v5 Guardian

## Objetivo
Acercar el MVP a un producto real con captura de interacciones del mundo real y visualización de la red.

## Flujo recomendado
1. Vincular dispositivo en `/pilot/onboarding`.
2. Entrar a `/mobile`.
3. Emitir pulse.
4. Registrar interacciones reales por tipo:
   - message
   - call
   - financial
   - in_person
   - marketplace
   - crypto
5. Revisar `/pilot/dashboard`.
6. Ver el grafo en `/graph`.
7. Ejecutar ataques en `/attack-theater`.

## Casos demo
- cambio de número
- recibo falso marketplace
- solicitud financiera urgente
- romance scam
- wallet phishing
