
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from datetime import datetime
import os, random, json, hashlib

app = FastAPI(title="MitoPulse v12.1")
templates = Jinja2Templates(directory="templates")

APP_MODE = os.getenv("APP_MODE", "cloud")
DATABASE_URL = os.getenv("DATABASE_URL", "")
DEMO_MODE = os.getenv("DEMO_MODE", "true").lower() == "true"

# Demo stores (PostgreSQL-ready abstraction point)
nodes = {}
edges = []
evaluations = []
relay_sessions = {}
fraud_flags = {"node_9", "node_10"}

def now():
    return datetime.utcnow().isoformat()

def rel_key(a,b):
    return "::".join(sorted([a,b]))

def ensure_node(n):
    if n not in nodes:
        nodes[n] = {
            "node_id": n,
            "trust_rank": random.randint(35, 95),
            "nodal_mass": random.randint(20, 95),
            "guardian": False,
            "status": "healthy",
            "fraud_exposure": random.randint(0, 35),
            "pulse_count": 0,
            "cross_pulse_count": 0,
            "last_seen": None
        }
    return nodes[n]

def seed():
    if nodes:
        return
    for i in range(1, 19):
        nid = f"node_{i}"
        ensure_node(nid)
        nodes[nid]["pulse_count"] = random.randint(1, 18)
        nodes[nid]["cross_pulse_count"] = random.randint(1, 12)
        if i in [1,2,7,11]:
            nodes[nid]["guardian"] = True
        if i == 10:
            nodes[nid]["status"] = "quarantined"
            nodes[nid]["fraud_exposure"] = 85
        elif i in [9,15]:
            nodes[nid]["status"] = "high_risk"
            nodes[nid]["fraud_exposure"] = 55
        else:
            nodes[nid]["status"] = "healthy"
    rels = [
        ("node_1","node_2",82),("node_1","node_3",76),("node_2","node_4",61),("node_3","node_5",55),
        ("node_4","node_6",52),("node_6","node_7",71),("node_7","node_8",63),("node_8","node_9",44),
        ("node_9","node_10",88),("node_11","node_12",78),("node_12","node_13",66),("node_13","node_14",54),
        ("node_14","node_15",41),("node_15","node_16",47),("node_16","node_17",59),("node_17","node_18",64),
        ("node_2","node_11",38),("node_5","node_12",33)
    ]
    for a,b,w in rels:
        edges.append({"source":a,"target":b,"weight":w})
seed()

def get_edge(a,b):
    return next((e for e in edges if set([e["source"], e["target"]]) == set([a,b])), None)

def compute_eval(src, tgt, industry, amount_anomaly, routine_break):
    ensure_node(src); ensure_node(tgt)
    rel = get_edge(src, tgt)
    rds = rel["weight"] if rel else 10
    ass = int((nodes[tgt]["trust_rank"] + nodes[tgt]["nodal_mass"]) / 2)
    srs = 30 + (10 if rel else 0) + min(20, nodes[tgt]["cross_pulse_count"])
    sc = max(0, int(100 - ((amount_anomaly*100 + routine_break*100)/2)))
    fe = nodes[tgt]["fraud_exposure"]
    trust_score = round((rds + ass + srs + sc)/4 - fe, 2)
    decision = "VERIFY" if trust_score >= 80 else "REVIEW" if trust_score >= 60 else "BLOCK"
    result = {
        "evaluation_id": f"ev_{len(evaluations)+1}",
        "timestamp": now(),
        "source_node_id": src,
        "target_node_id": tgt,
        "industry": industry,
        "decision": decision,
        "trust_score": trust_score,
        "recommended_action": "allow" if decision == "VERIFY" else "step_up_authentication",
        "reason": "supportive relationship and low exposure" if decision == "VERIFY" else "moderate support or moderate exposure" if decision == "REVIEW" else "low support and/or high fraud exposure",
        "breakdown": {"RDS":rds,"ASS":ass,"SRS":srs,"SC":sc,"FE":fe}
    }
    result["receipt"] = hashlib.sha256(json.dumps(result, sort_keys=True).encode()).hexdigest()[:24]
    evaluations.append(result)
    return result

class EvalIn(BaseModel):
    source_node_id: str
    target_node_id: str
    industry: str = "banking"
    amount_anomaly: float = 0.9
    routine_break: float = 0.8

class PulseIn(BaseModel):
    node_id: str

class RelayCreateIn(BaseModel):
    node_id: str

class RelayConfirmIn(BaseModel):
    node_id: str
    code: str

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("home.html", {"request": request, "app_mode": APP_MODE, "database_url_set": bool(DATABASE_URL)})

@app.get("/graph", response_class=HTMLResponse)
def graph(request: Request):
    return templates.TemplateResponse("graph.html", {"request": request})

@app.get("/sdk", response_class=HTMLResponse)
def sdk(request: Request):
    return templates.TemplateResponse("sdk.html", {"request": request})

@app.get("/pilot", response_class=HTMLResponse)
def pilot(request: Request):
    return templates.TemplateResponse("pilot.html", {"request": request})

@app.get("/mobile", response_class=HTMLResponse)
def mobile_home(request: Request):
    return templates.TemplateResponse("mobile_home.html", {"request": request})

@app.get("/mobile/relay", response_class=HTMLResponse)
def mobile_relay(request: Request):
    return templates.TemplateResponse("mobile_relay.html", {"request": request})

@app.get("/mobile/eval", response_class=HTMLResponse)
def mobile_eval(request: Request):
    return templates.TemplateResponse("mobile_eval.html", {"request": request})

@app.get("/mobile/audit", response_class=HTMLResponse)
def mobile_audit(request: Request):
    return templates.TemplateResponse("mobile_audit.html", {"request": request})

@app.get("/api/graph")
def api_graph():
    return {"nodes": list(nodes.values()), "edges": edges}

@app.get("/api/nodes")
def api_nodes():
    return list(nodes.values())

@app.get("/api/node/{node_id}")
def api_node(node_id: str):
    ensure_node(node_id)
    return nodes[node_id]

@app.post("/api/pulse")
def api_pulse(payload: PulseIn):
    ensure_node(payload.node_id)
    nodes[payload.node_id]["pulse_count"] += 1
    nodes[payload.node_id]["nodal_mass"] = min(100, nodes[payload.node_id]["nodal_mass"] + 1)
    nodes[payload.node_id]["last_seen"] = now()
    return nodes[payload.node_id]

@app.post("/api/evaluate")
def api_evaluate(payload: EvalIn):
    return compute_eval(payload.source_node_id, payload.target_node_id, payload.industry, payload.amount_anomaly, payload.routine_break)

@app.get("/api/evaluation/{evaluation_id}")
def api_get_evaluation(evaluation_id: str):
    e = next((x for x in evaluations if x["evaluation_id"] == evaluation_id), None)
    if not e:
        return JSONResponse({"error":"not_found"}, status_code=404)
    return e

@app.post("/api/relay/create")
def api_relay_create(payload: RelayCreateIn):
    ensure_node(payload.node_id)
    code = str(random.randint(1000, 9999))
    relay_sessions[code] = {"initiator": payload.node_id, "created_at": now()}
    return {"code": code, "initiator": payload.node_id, "created_at": relay_sessions[code]["created_at"]}

@app.post("/api/relay/confirm")
def api_relay_confirm(payload: RelayConfirmIn):
    ensure_node(payload.node_id)
    session = relay_sessions.get(payload.code)
    if not session:
        return JSONResponse({"error":"invalid_code"}, status_code=404)
    a = session["initiator"]
    b = payload.node_id
    if a == b:
        return JSONResponse({"error":"same_node"}, status_code=400)
    edge = get_edge(a, b)
    before = edge["weight"] if edge else 0
    if not edge:
        edge = {"source": a, "target": b, "weight": 25}
        edges.append(edge)
    edge["weight"] = min(100, edge["weight"] + 8)
    nodes[a]["cross_pulse_count"] += 1
    nodes[b]["cross_pulse_count"] += 1
    return {
        "status": "confirmed",
        "node_a": a,
        "node_b": b,
        "relationship_weight_before": before,
        "relationship_weight_after": edge["weight"],
        "source": "relay_code"
    }

@app.get("/api/platform_profile")
def api_platform_profile():
    return {
        "hosting": "cloud-only",
        "database": "PostgreSQL-ready via DATABASE_URL",
        "sdk": ["Web SDK", "Mobile SDK", "Backend API"],
        "clients": ["banks", "fintech", "wallets", "marketplaces"]
    }
