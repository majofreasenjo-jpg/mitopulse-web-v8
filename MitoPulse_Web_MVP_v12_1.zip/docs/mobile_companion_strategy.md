
# Mobile companion strategy

Mobile should be:
- lightweight
- persistent
- centered on node + relay + quick evaluation + audit

Web should be:
- dashboard
- graph
- pilot console
- integration / SDK
