
# MitoPulse v12.1

Independent release focused on:
- PostgreSQL-ready cloud deployment
- interactive graph visualization
- mobile-first companion experience
- relay handshake by short code
- quick evaluation + audit on mobile
