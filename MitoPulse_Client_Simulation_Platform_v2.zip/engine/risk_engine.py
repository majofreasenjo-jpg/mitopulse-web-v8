from collections import Counter
from engine.trust_propagation import propagate_risk

def calculate_node_risk(G, node):
    if node not in G:
        return {"risk_score": 0.0, "recommended_action": "ALLOW", "reason": "unknown"}

    degree = G.degree(node)
    attrs = G.nodes[node]
    signal = float(attrs.get("signal_severity", 0.0) or 0.0)
    propagated = propagate_risk(G, node)
    suspicious_neighbor_edges = 0
    contexts = Counter()

    for nbr in G.neighbors(node):
        edge = G.get_edge_data(node, nbr, default={})
        contexts[edge.get("context", "general")] += 1
        if edge.get("label") in {"mule_pattern", "scam_ring", "social_chain"}:
            suspicious_neighbor_edges += 1

    risk = 0.08
    risk += min(degree * 0.015, 0.20)
    risk += signal * 0.35
    risk += propagated * 0.30
    risk += min(suspicious_neighbor_edges * 0.07, 0.30)

    if contexts["urgent_transfer"] >= 2:
        risk += 0.08
    if contexts["social_engineering"] >= 1:
        risk += 0.12
    if contexts["fake_receipt"] >= 1:
        risk += 0.10

    risk = round(min(risk, 0.99), 3)
    if risk >= 0.80:
        action = "BLOCK"
        reason = "high_relational_risk"
    elif risk >= 0.45:
        action = "REVIEW"
        reason = "elevated_relational_risk"
    else:
        action = "ALLOW"
        reason = "normal_relational_profile"

    return {
        "node": node,
        "risk_score": risk,
        "recommended_action": action,
        "reason": reason,
        "propagated_risk": propagated,
        "direct_signal": signal,
        "degree": degree,
    }

def project_decisions(G):
    allow = review = block = 0
    top = []
    for node, attrs in G.nodes(data=True):
        if attrs.get("node_type") != "customer":
            continue
        r = calculate_node_risk(G, node)
        top.append(r)
        if r["recommended_action"] == "BLOCK":
            block += 1
        elif r["recommended_action"] == "REVIEW":
            review += 1
        else:
            allow += 1
    top.sort(key=lambda x: x["risk_score"], reverse=True)
    return {
        "ALLOW": allow,
        "REVIEW": review,
        "BLOCK": block,
        "top_risky_customers": top[:15],
    }
