import networkx as nx

def detect_clusters(G):
    communities = list(nx.connected_components(G))
    suspicious = []

    for cluster in communities:
        sub = G.subgraph(cluster)
        customer_nodes = [n for n, d in sub.nodes(data=True) if d.get("node_type") == "customer"]
        external_nodes = [n for n, d in sub.nodes(data=True) if d.get("node_type") == "external"]
        suspicious_edges = 0
        suspicious_contexts = 0

        for _, _, data in sub.edges(data=True):
            if data.get("label") in {"mule_pattern", "scam_ring", "social_chain"}:
                suspicious_edges += 1
            if data.get("context") in {"urgent_transfer", "social_engineering", "fake_receipt"}:
                suspicious_contexts += 1

        score = (
            suspicious_edges * 0.08 +
            suspicious_contexts * 0.05 +
            max(len(external_nodes) - 2, 0) * 0.02 +
            max(len(customer_nodes) - 15, 0) * 0.005
        )

        if score >= 0.35:
            suspicious.append({
                "cluster_size": len(cluster),
                "customer_nodes": len(customer_nodes),
                "external_nodes": len(external_nodes),
                "suspicious_score": round(min(score, 0.99), 3),
                "sample_nodes": list(sorted(cluster))[:12],
            })

    suspicious.sort(key=lambda x: x["suspicious_score"], reverse=True)
    return suspicious
