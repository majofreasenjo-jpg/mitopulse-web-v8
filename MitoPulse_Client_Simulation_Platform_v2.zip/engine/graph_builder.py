import networkx as nx

def build_graph(customers, transactions, devices, signals):
    G = nx.Graph()

    for _, row in customers.iterrows():
        G.add_node(
            row["customer_id"],
            node_type="customer",
            segment=row.get("segment", "unknown"),
            region=row.get("region", "unknown"),
            status=row.get("status", "active"),
        )

    for _, row in devices.iterrows():
        dev_id = row["device_id"]
        cust_id = row["customer_id"]
        if dev_id not in G:
            G.add_node(dev_id, node_type="device", channel=row.get("channel", "unknown"))
        G.add_edge(cust_id, dev_id, edge_type="owns_device", weight=0.35)

    for _, row in transactions.iterrows():
        sender = row["sender"]
        receiver = row["receiver"]
        if sender not in G:
            G.add_node(sender, node_type="external")
        if receiver not in G:
            G.add_node(receiver, node_type="external")
        existing = G.get_edge_data(sender, receiver, default={})
        weight = existing.get("weight", 0) + min(float(row["amount"]) / 1000.0, 2.5)
        G.add_edge(
            sender,
            receiver,
            edge_type=row.get("channel", "transaction"),
            amount=float(row["amount"]),
            context=row.get("context", "general"),
            label=row.get("label", "normal"),
            weight=weight,
        )

    for _, row in signals.iterrows():
        entity = row["entity_id"]
        if entity in G:
            G.nodes[entity]["signal_type"] = row["signal_type"]
            G.nodes[entity]["signal_severity"] = float(row["severity"])
            G.nodes[entity]["signal_source"] = row["source"]

    return G
