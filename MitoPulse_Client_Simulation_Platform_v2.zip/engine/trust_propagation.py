import networkx as nx

def propagate_risk(G, node, max_depth=2):
    if node not in G:
        return 0.0

    risk = 0.0
    for other, attrs in G.nodes(data=True):
        sev = float(attrs.get("signal_severity", 0.0) or 0.0)
        if sev <= 0:
            continue
        try:
            path = nx.shortest_path(G, node, other)
        except nx.NetworkXNoPath:
            continue
        depth = len(path) - 1
        if depth <= max_depth:
            risk += sev * (0.7 ** max(depth - 1, 0))
    return round(min(risk, 1.0), 3)
