from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from simulator.synthetic_client_generator import generate_dataset
from ingestion.client_data_loader import load_client_data, normalize_entities
from engine.graph_builder import build_graph
from engine.cluster_detector import detect_clusters
from engine.risk_engine import project_decisions
from dashboard.dashboard import summarize

app = FastAPI(title="MitoPulse Client Simulation Platform v2")
templates = Jinja2Templates(directory="templates")

LAST_RUN = {}

def _pipeline(scenario="retail_bank"):
    global LAST_RUN
    generation = generate_dataset("data", scenario=scenario)
    customers, tx, devices, signals = load_client_data("data")
    customers, tx, devices, signals = normalize_entities(customers, tx, devices, signals)
    G = build_graph(customers, tx, devices, signals)
    clusters = detect_clusters(G)
    decisions = project_decisions(G)

    top_nodes = []
    for node, attrs in list(G.nodes(data=True))[:120]:
        if attrs.get("node_type") == "customer":
            top_nodes.append({"id": node, "group": "customer"})
        elif attrs.get("node_type") == "external":
            top_nodes.append({"id": node, "group": "external"})
        elif attrs.get("node_type") == "device":
            top_nodes.append({"id": node, "group": "device"})

    edges = []
    count = 0
    for a, b, data in G.edges(data=True):
        edges.append({
            "source": a,
            "target": b,
            "type": data.get("label", data.get("edge_type", "edge")),
            "context": data.get("context", "general"),
        })
        count += 1
        if count >= 180:
            break

    LAST_RUN = {
        "generation": generation,
        "summary": summarize("data"),
        "clusters": clusters[:10],
        "decision_projection": decisions,
        "graph_preview": {
            "nodes": top_nodes[:80],
            "edges": edges
        }
    }
    return LAST_RUN

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.get("/api/simulate")
def simulate(scenario: str = "retail_bank"):
    return _pipeline(scenario)

@app.get("/api/results")
def results():
    return LAST_RUN or _pipeline("retail_bank")

@app.get("/api/scenarios")
def scenarios():
    return {
        "supported_scenarios": ["retail_bank", "marketplace", "telco"],
        "pipeline_steps": [
            "client_upload",
            "data_normalization",
            "graph_construction",
            "risk_scoring",
            "cluster_detection",
            "results_measurement"
        ]
    }
