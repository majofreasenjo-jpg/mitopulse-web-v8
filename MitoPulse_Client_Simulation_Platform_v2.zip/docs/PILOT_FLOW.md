# Pilot Flow

## Qué simula esta versión
- recepción de datasets del cliente
- carga de customers / transactions / devices / signals
- construcción del grafo relacional
- detección de patrones mule, scam ring y social engineering
- medición de resultados antifraude

## Tipos de cliente
- retail_bank
- marketplace
- telco
