import random
from pathlib import Path
import pandas as pd

RANDOM = random.Random(42)

BANK_SCENARIOS = {
    "retail_bank": {"customers": 1200, "transactions": 4500, "devices": 1400, "signals": 120},
    "marketplace": {"customers": 1500, "transactions": 5000, "devices": 1600, "signals": 160},
    "telco": {"customers": 1000, "transactions": 3000, "devices": 1300, "signals": 140}
}

def _pick(seq):
    return seq[RANDOM.randrange(0, len(seq))]

def generate_dataset(output_dir: str = "data", scenario: str = "retail_bank"):
    cfg = BANK_SCENARIOS.get(scenario, BANK_SCENARIOS["retail_bank"])
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    customers = []
    devices = []
    transactions = []
    signals = []

    customer_ids = [f"CUST_{i:05d}" for i in range(cfg["customers"])]
    merchants = [f"MERCH_{i:03d}" for i in range(25)]
    mule_accounts = [f"MULE_{i:03d}" for i in range(8)]
    bad_cluster = [f"BAD_{i:03d}" for i in range(12)]

    for cid in customer_ids:
        customers.append({
            "customer_id": cid,
            "segment": _pick(["mass", "premium", "new", "youth"]),
            "region": _pick(["north", "center", "south"]),
            "phone_hash": f"ph_{abs(hash(cid + '_p')) % 10**10}",
            "email_hash": f"em_{abs(hash(cid + '_e')) % 10**10}",
            "status": _pick(["active", "active", "active", "watch"])
        })

    for i in range(cfg["devices"]):
        cid = _pick(customer_ids)
        devices.append({
            "device_id": f"DEV_{i:05d}",
            "customer_id": cid,
            "channel": _pick(["mobile_app", "web", "call_center"]),
            "device_hash": f"dh_{abs(hash(cid + str(i))) % 10**12}",
            "risk_hint": _pick(["normal", "normal", "normal", "new_device", "new_channel"])
        })

    for i in range(cfg["transactions"] - 380):
        sender = _pick(customer_ids)
        receiver = _pick(customer_ids + merchants)
        if sender == receiver:
            receiver = _pick(merchants)
        transactions.append({
            "tx_id": f"TX_{i:06d}",
            "sender": sender,
            "receiver": receiver,
            "amount": RANDOM.randint(8, 1800),
            "channel": _pick(["bank_transfer", "p2p", "marketplace_payment"]),
            "context": _pick(["general", "family", "commerce", "salary"]),
            "label": "normal"
        })

    start_idx = len(transactions)
    for i in range(180):
        sender = _pick(customer_ids[:250])
        receiver = _pick(mule_accounts)
        transactions.append({
            "tx_id": f"TX_{start_idx + i:06d}",
            "sender": sender,
            "receiver": receiver,
            "amount": RANDOM.randint(70, 950),
            "channel": "bank_transfer",
            "context": "urgent_transfer",
            "label": "mule_pattern"
        })

    start_idx = len(transactions)
    for i in range(120):
        sender = _pick(bad_cluster)
        receiver = _pick(customer_ids[250:600])
        transactions.append({
            "tx_id": f"TX_{start_idx + i:06d}",
            "sender": sender,
            "receiver": receiver,
            "amount": RANDOM.randint(20, 400),
            "channel": _pick(["marketplace_payment", "p2p"]),
            "context": "fake_receipt",
            "label": "scam_ring"
        })

    start_idx = len(transactions)
    for i in range(80):
        sender = _pick(customer_ids[600:900])
        receiver = _pick(mule_accounts + bad_cluster)
        transactions.append({
            "tx_id": f"TX_{start_idx + i:06d}",
            "sender": sender,
            "receiver": receiver,
            "amount": RANDOM.randint(150, 2200),
            "channel": "bank_transfer",
            "context": "social_engineering",
            "label": "social_chain"
        })

    for i in range(cfg["signals"]):
        target = _pick(customer_ids + mule_accounts + bad_cluster + merchants)
        signals.append({
            "signal_id": f"SIG_{i:05d}",
            "entity_id": target,
            "signal_type": _pick([
                "new_channel", "identity_shift", "shared_signal_detected",
                "unknown_relationship", "sim_swap_hint", "device_reset"
            ]),
            "severity": round(RANDOM.uniform(0.25, 0.98), 3),
            "source": _pick(["bank", "marketplace", "telco", "wallet"])
        })

    pd.DataFrame(customers).to_csv(out / "synthetic_customers.csv", index=False)
    pd.DataFrame(transactions).to_csv(out / "synthetic_transactions.csv", index=False)
    pd.DataFrame(devices).to_csv(out / "synthetic_devices.csv", index=False)
    pd.DataFrame(signals).to_csv(out / "synthetic_signals.csv", index=False)

    return {
        "scenario": scenario,
        "customers": len(customers),
        "transactions": len(transactions),
        "devices": len(devices),
        "signals": len(signals),
        "mule_accounts": len(mule_accounts),
        "bad_cluster_nodes": len(bad_cluster),
    }
