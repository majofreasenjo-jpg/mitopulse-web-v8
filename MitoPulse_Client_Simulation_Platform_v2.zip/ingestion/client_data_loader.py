from pathlib import Path
import pandas as pd

def load_client_data(data_dir: str = "data"):
    d = Path(data_dir)
    customers = pd.read_csv(d / "synthetic_customers.csv")
    transactions = pd.read_csv(d / "synthetic_transactions.csv")
    devices = pd.read_csv(d / "synthetic_devices.csv")
    signals = pd.read_csv(d / "synthetic_signals.csv")
    return customers, transactions, devices, signals

def normalize_entities(customers, transactions, devices, signals):
    customers = customers.copy()
    transactions = transactions.copy()
    devices = devices.copy()
    signals = signals.copy()
    customers["entity_type"] = "customer"
    devices["entity_type"] = "device"
    signals["entity_type"] = "signal"
    return customers, transactions, devices, signals
