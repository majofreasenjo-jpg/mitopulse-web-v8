# MitoPulse Client Simulation Platform v2

Versión completa descargable para desarrollo con simulación realista del proceso de piloto de cliente.

## Incluye
- generador avanzado de fraude
- simulador de redes mule
- simulador de ataque coordinado
- simulador multi-industria
- motor de métricas antifraude
- grafo visual / preview de red

## Flujo
1. cliente entrega CSV sintético
2. MitoPulse ingesta datos
3. normaliza entidades
4. construye el grafo relacional
5. detecta clusters sospechosos
6. calcula scores y proyección ALLOW/REVIEW/BLOCK

## Ejecutar
```bash
pip install -r requirements.txt
python run.py
```

Abrir:
`http://127.0.0.1:8000`

## Endpoints
- `/api/simulate?scenario=retail_bank`
- `/api/simulate?scenario=marketplace`
- `/api/simulate?scenario=telco`
- `/api/results`
- `/api/scenarios`
