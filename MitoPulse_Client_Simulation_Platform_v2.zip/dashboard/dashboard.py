from ingestion.client_data_loader import load_client_data, normalize_entities
from engine.graph_builder import build_graph
from engine.cluster_detector import detect_clusters
from engine.risk_engine import project_decisions

def summarize(data_dir="data"):
    customers, tx, devices, signals = load_client_data(data_dir)
    customers, tx, devices, signals = normalize_entities(customers, tx, devices, signals)
    G = build_graph(customers, tx, devices, signals)
    clusters = detect_clusters(G)
    decisions = project_decisions(G)

    return {
        "nodes": G.number_of_nodes(),
        "edges": G.number_of_edges(),
        "clusters_detected": len(clusters),
        "largest_cluster_score": clusters[0]["suspicious_score"] if clusters else 0,
        "decision_projection": {
            "ALLOW": decisions["ALLOW"],
            "REVIEW": decisions["REVIEW"],
            "BLOCK": decisions["BLOCK"],
        },
        "top_risky_customers": decisions["top_risky_customers"][:10]
    }
