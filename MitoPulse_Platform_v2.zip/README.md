
# MitoPulse Platform v2

Versión más productiva de la plataforma.

## Incluye
- estructura modular (`app/core`, `app/models`, `app/services`, `app/api`)
- base de datos SQLite mediante SQLAlchemy
- bootstrap del piloto real
- captura de interacciones
- cross-pulse
- simulación de ataques
- dashboard web

## Ejecutar
```bash
pip install -r requirements.txt
python run.py
```

o

```bash
uvicorn app.main:app --reload
```

## Abrir
`http://127.0.0.1:8000`
