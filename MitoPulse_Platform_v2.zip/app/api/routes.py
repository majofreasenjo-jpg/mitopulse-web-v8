
from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.api.schemas import BootstrapIn, InteractionIn, CrossPulseIn, AttackIn
from app.services.platform import bootstrap_pilot, capture_interaction, create_crosspulse, simulate_attack, get_state, PILOT_USERS
from fastapi.templating import Jinja2Templates

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.post("/api/bootstrap")
def bootstrap(payload: BootstrapIn, db: Session = Depends(get_db)):
    bootstrap_pilot(db, payload.cluster)
    return {"ok": True}

@router.post("/api/interaction")
def interaction(payload: InteractionIn, db: Session = Depends(get_db)):
    capture_interaction(db, payload.source, payload.target, payload.interaction_type, payload.context)
    return {"ok": True}

@router.post("/api/crosspulse")
def crosspulse(payload: CrossPulseIn, db: Session = Depends(get_db)):
    pulse_id = create_crosspulse(db, payload.source, payload.target, payload.reason)
    return {"ok": True, "pulse_id": pulse_id}

@router.post("/api/attack")
def attack(payload: AttackIn, db: Session = Depends(get_db)):
    return {"ok": True, "alerts": simulate_attack(db, payload.attack_type)}

@router.get("/api/state")
def state(db: Session = Depends(get_db)):
    return get_state(db)

@router.get("/api/pilot/users")
def pilot_users():
    return [{"node_id": nid, "display_name": label} for nid, label in PILOT_USERS]

@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
