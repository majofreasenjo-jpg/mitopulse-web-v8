
# MitoPulse v12.5

Independent release focused on both:
- real deployment guidance
- unified product UI

Includes:
- production deployment checklist
- enterprise UI consistency across views
- premium demo and partner mode
- SQLAlchemy persistence
- mobile companion
