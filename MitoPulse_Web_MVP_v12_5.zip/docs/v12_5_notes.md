
# v12.5 notes

This version combines both directions:
1. Real deployment
   - production checklist
   - environment variables
   - PostgreSQL-ready DATABASE_URL
2. Product closure
   - unified navigation and branding
   - partner mode
   - guided demo
   - mobile companion consistency
