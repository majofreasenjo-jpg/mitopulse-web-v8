import React, { useMemo, useState } from 'react'

// ----- Demo engine (runs in browser; local-first) -----
function clamp01(x){ return Math.max(0, Math.min(1, x)) }

function pickTier({hrv, sleep, spo2, load}){
  // Tier2 if HRV present, Tier1 otherwise. Tier3 reserved for future NIRS.
  if (hrv !== null && !Number.isNaN(hrv)) return 'tier2'
  return 'tier1'
}

function computeIndex({hr, hrv, spo2, sleep, load, alt, temp, hum, press}){
  // Normalize heuristics for demo.
  const hr_n = clamp01(1 - (hr-45)/(120-45))       // lower HR better
  const hrv_n = hrv === null ? 0.55 : clamp01((hrv-10)/(90-10))
  const spo2_n = clamp01((spo2-88)/(100-88))
  const sleep_n = clamp01(sleep/100)
  const load_n = clamp01(1 - load) // lower load better (0..1)

  // Env compensation (simple)
  const c_env = 1 / (1 + 0.012*(alt/1000) + 0.008*Math.abs(temp-22) + 0.005*Math.abs(hum-50)/10)

  const base = 0.30*hr_n + 0.25*hrv_n + 0.20*spo2_n + 0.15*sleep_n + 0.10*load_n
  return clamp01(base * c_env)
}

function computeSlope(prevIndex, currIndex){
  if (prevIndex === null) return 0
  return currIndex - prevIndex
}

function randId(n=12){
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_'
  let s=''
  for (let i=0;i<n;i++) s += chars[Math.floor(Math.random()*chars.length)]
  return s
}

// NOTE: In browsers we can't safely keep HMAC secrets. For demo we just create dynamic_id as random.
// The server still provides replay protection and verifies on-demand against latest stored id.
function computeDynamicId(){
  return randId(20)
}

async function postJson(url, body, apiKey){
  const headers = { 'Content-Type':'application/json' }
  if (apiKey) headers['X-API-Key'] = apiKey
  const res = await fetch(url, { method:'POST', headers, body: JSON.stringify(body) })
  const txt = await res.text()
  let data = null
  try { data = JSON.parse(txt) } catch { data = { raw: txt } }
  return { ok: res.ok, status: res.status, data }
}

export default function App(){
  const [backend, setBackend] = useState('http://127.0.0.1:8000')
  const [apiKey, setApiKey] = useState('')
  const [user, setUser] = useState('manuel')
  const [device, setDevice] = useState('web-pwa')
  const [prevIndex, setPrevIndex] = useState(null)
  const [log, setLog] = useState('')

  // Inputs
  const [hr, setHr] = useState(72)
  const [hrv, setHrv] = useState(38)
  const [spo2, setSpo2] = useState(97)
  const [sleep, setSleep] = useState(78)
  const [load, setLoad] = useState(0.35)

  const [alt, setAlt] = useState(520)
  const [temp, setTemp] = useState(22)
  const [hum, setHum] = useState(50)
  const [press, setPress] = useState(1013)

  const tier = useMemo(() => pickTier({hrv, sleep, spo2, load}), [hrv, sleep, spo2, load])
  const index = useMemo(() => computeIndex({hr, hrv, spo2, sleep, load, alt, temp, hum, press}), [hr, hrv, spo2, sleep, load, alt, temp, hum, press])
  const slope = useMemo(() => computeSlope(prevIndex, index), [prevIndex, index])

  const [dynamicId, setDynamicId] = useState('')

  function append(s){ setLog(p => (p ? p + '\n' : '') + s) }

  async function sendEvent(){
    const ts = Math.floor(Date.now()/1000)
    const dyn = computeDynamicId()
    setDynamicId(dyn)
    const request_id = crypto?.randomUUID ? crypto.randomUUID() : randId(24)

    const body = { ts, user, device, tier, index, slope, dynamic_id: dyn, risk: 0, coercion: false, request_id }
    append(`POST /v1/identity-events ts=${ts} tier=${tier} idx=${index.toFixed(3)} slope=${slope.toFixed(4)} dyn=${dyn.slice(0,10)}…`)
    const res = await postJson(`${backend}/v1/identity-events`, body, apiKey)
    append(` -> ${res.status} ${JSON.stringify(res.data)}`)
    if (res.ok) setPrevIndex(index)
  }

  async function verify(){
    const ts = Math.floor(Date.now()/1000)
    const request_id = crypto?.randomUUID ? crypto.randomUUID() : randId(24)
    const body = { ts, user, device, dynamic_id: dynamicId, request_id }
    append(`POST /v1/verify ts=${ts} dyn=${dynamicId ? dynamicId.slice(0,10)+'…' : '(none)'}`)
    const res = await postJson(`${backend}/v1/verify`, body, apiKey)
    append(` -> ${res.status} ${JSON.stringify(res.data)}`)
  }

  return (
    <div className="container">
      <h1>MitoPulse v2 — DEMO GLOBAL (PWA)</h1>
      <div className="sub">PC / Notebook / Tablet / Mobile • local-first computation • backend verification • audit logs</div>

      <div className="panel">
        <div className="row">
          <div className="field">
            <label>Backend URL</label>
            <input value={backend} onChange={e=>setBackend(e.target.value)} placeholder="https://your-backend.example.com" />
          </div>
          <div className="field">
            <label>API Key (optional)</label>
            <input value={apiKey} onChange={e=>setApiKey(e.target.value)} placeholder="X-API-Key" />
          </div>
        </div>
        <div className="row" style={{marginTop:12}}>
          <div className="field">
            <label>User</label>
            <input value={user} onChange={e=>setUser(e.target.value)} />
          </div>
          <div className="field">
            <label>Device</label>
            <input value={device} onChange={e=>setDevice(e.target.value)} />
          </div>
        </div>
      </div>

      <div className="panel">
        <h2 style={{margin:'0 0 10px'}}>Inputs</h2>
        <div className="grid">
          <div className="field"><label>HR</label><input type="number" value={hr} onChange={e=>setHr(+e.target.value)} /></div>
          <div className="field"><label>HRV</label><input type="number" value={hrv} onChange={e=>setHrv(+e.target.value)} /></div>
          <div className="field"><label>SpO2</label><input type="number" value={spo2} onChange={e=>setSpo2(+e.target.value)} /></div>
          <div className="field"><label>Sleep</label><input type="number" value={sleep} onChange={e=>setSleep(+e.target.value)} /></div>
          <div className="field"><label>Load (0..1)</label><input type="number" step="0.01" value={load} onChange={e=>setLoad(+e.target.value)} /></div>
        </div>

        <h2 style={{margin:'16px 0 10px'}}>Environment</h2>
        <div className="grid">
          <div className="field"><label>Alt (m)</label><input type="number" value={alt} onChange={e=>setAlt(+e.target.value)} /></div>
          <div className="field"><label>Temp (°C)</label><input type="number" value={temp} onChange={e=>setTemp(+e.target.value)} /></div>
          <div className="field"><label>Hum (%)</label><input type="number" value={hum} onChange={e=>setHum(+e.target.value)} /></div>
          <div className="field"><label>Press (hPa)</label><input type="number" value={press} onChange={e=>setPress(+e.target.value)} /></div>
        </div>

        <div className="row" style={{marginTop:14, alignItems:'center'}}>
          <span className="badge mono">tier: {tier}</span>
          <span className="badge mono">index: {index.toFixed(3)}</span>
          <span className="badge mono">slope: {slope.toFixed(4)}</span>
          <span className={"badge mono " + (dynamicId ? "ok":"warn")}>dynamic_id: {dynamicId ? dynamicId.slice(0,14)+'…' : '(none)'}</span>
        </div>

        <div className="row" style={{marginTop:14}}>
          <button className="btn primary" onClick={sendEvent}>Send DEMO Event</button>
          <button className="btn" onClick={verify} disabled={!dynamicId}>Verify</button>
          <a className="btn" href={`${backend}/dashboard`} target="_blank" rel="noreferrer">Open Dashboard</a>
          <a className="btn" href={`${backend}/docs`} target="_blank" rel="noreferrer">Open API Docs</a>
        </div>

        <div className="log mono">{log || "Log…"}</div>
      </div>
    </div>
  )
}
