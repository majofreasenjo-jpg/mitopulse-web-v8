#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export MITOPULSE_ALLOWED_SKEW_SECONDS=${MITOPULSE_ALLOWED_SKEW_SECONDS:-86400}
uvicorn app.main:app --host 0.0.0.0 --port ${PORT:-8000}
