import hmac, hashlib, json
from fastapi import Header, HTTPException
from .config import settings

def require_api_key(x_api_key: str | None):
    if not settings.api_key:
        return
    if not x_api_key or x_api_key != settings.api_key:
        raise HTTPException(status_code=401, detail="invalid_api_key")

def verify_hmac_signature(raw_body: bytes, x_mitopulse_sig: str | None):
    """Optional HMAC signature check. Header is hex(HMAC_SHA256(secret, body)).
    Enabled when MITOPULSE_DEMO_HMAC_SECRET is set (always), but you can disable on clients by not sending the header.
    Server will only enforce if header is present (soft enforcement for demo).
    """
    if not x_mitopulse_sig:
        return
    mac = hmac.new(settings.demo_hmac_secret.encode("utf-8"), raw_body, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(mac, x_mitopulse_sig):
        raise HTTPException(status_code=400, detail="bad_signature")
