"""Shared rules for 'demo risk' and tier semantics (server-side).
In a real system, index computation is local-only. Server stores derived data and verifies on-demand.
"""

def compute_risk(index_value: float, slope: float) -> int:
    # Simple demo heuristic:
    # low index and strongly negative slope -> higher risk
    risk = 0
    if index_value < 0.25:
        risk += 60
    if index_value < 0.15:
        risk += 30
    if slope < -0.15:
        risk += 15
    return min(100, max(0, risk))

def is_coercion(risk: int) -> bool:
    return risk >= 80
