from sqlalchemy import Integer, String, Float, Boolean, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from .db import Base

class IdentityEvent(Base):
    __tablename__ = "identity_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ts: Mapped[int] = mapped_column(Integer, index=True)  # epoch seconds
    user: Mapped[str] = mapped_column(String(128), index=True)
    device: Mapped[str] = mapped_column(String(128), index=True)
    tier: Mapped[str] = mapped_column(String(16))
    index: Mapped[float] = mapped_column(Float)
    slope: Mapped[float] = mapped_column(Float)
    dynamic_id: Mapped[str] = mapped_column(String(256), index=True)
    risk: Mapped[int] = mapped_column(Integer, default=0)
    coercion: Mapped[bool] = mapped_column(Boolean, default=False)
    request_id: Mapped[str] = mapped_column(String(64), unique=True, index=True)

class Verification(Base):
    __tablename__ = "verifications"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ts: Mapped[int] = mapped_column(Integer, index=True)
    user: Mapped[str] = mapped_column(String(128), index=True)
    device: Mapped[str] = mapped_column(String(128), index=True)
    dynamic_id: Mapped[str] = mapped_column(String(256))
    verified: Mapped[bool] = mapped_column(Boolean)
    reason: Mapped[str] = mapped_column(String(128))

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ts: Mapped[int] = mapped_column(Integer, index=True)
    action: Mapped[str] = mapped_column(String(64))
    ok: Mapped[bool] = mapped_column(Boolean)
    reason: Mapped[str] = mapped_column(String(128))
    user: Mapped[str] = mapped_column(String(128), index=True)
    device: Mapped[str] = mapped_column(String(128), index=True)
    request_id: Mapped[str] = mapped_column(String(64), index=True)
