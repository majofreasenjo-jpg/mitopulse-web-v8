from fastapi import FastAPI, Depends, Request, Header
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
import time

from .config import settings
from .db import Base, engine, get_db
from .models import IdentityEvent, Verification, AuditLog
from .schemas import IdentityEventIn, VerifyIn, VerifyOut
from .security import require_api_key, verify_hmac_signature
from .engine import compute_risk, is_coercion

from fastapi.templating import Jinja2Templates

Base.metadata.create_all(bind=engine)

app = FastAPI(title="MitoPulse DEMO GLOBAL", version="2.0.0", openapi_url="/openapi.json")

# CORS for PWA and mobile apps
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

templates = Jinja2Templates(directory="app/templates")

# Serve built PWA (optional). If you build webapp, copy dist into backend/app/static/pwa
app.mount("/pwa", StaticFiles(directory="app/static/pwa", html=True), name="pwa")

@app.get("/health")
def health():
    return {"ok": True, "ts": int(time.time()), "version": app.version}

@app.post("/v1/identity-events")
async def post_identity_event(
    request: Request,
    payload: IdentityEventIn,
    db: Session = Depends(get_db),
    x_api_key: str | None = Header(default=None, alias="X-API-Key"),
    x_mitopulse_sig: str | None = Header(default=None, alias="X-MitoPulse-Signature"),
):
    require_api_key(x_api_key)
    raw = await request.body()
    verify_hmac_signature(raw, x_mitopulse_sig)

    now = int(time.time())
    if abs(payload.ts - now) > settings.allowed_skew_seconds:
        _audit(db, "post_identity_event", False, "ts_out_of_range", payload.user, payload.device, payload.request_id)
        return {"ok": False, "reason": "ts_out_of_range"}

    # Server-side risk/coercion (demo) to avoid trusting client.
    risk = compute_risk(payload.index, payload.slope)
    coercion = is_coercion(risk)

    row = IdentityEvent(
        ts=payload.ts,
        user=payload.user,
        device=payload.device,
        tier=payload.tier,
        index=payload.index,
        slope=payload.slope,
        dynamic_id=payload.dynamic_id,
        risk=risk,
        coercion=coercion,
        request_id=payload.request_id,
    )

    try:
        db.add(row)
        db.commit()
    except IntegrityError:
        db.rollback()
        _audit(db, "post_identity_event", False, "replay_request_id", payload.user, payload.device, payload.request_id)
        return {"ok": False, "reason": "replay_request_id"}

    _audit(db, "post_identity_event", True, "ok", payload.user, payload.device, payload.request_id)
    return {"ok": True, "risk": risk, "coercion": coercion}

@app.post("/v1/verify", response_model=VerifyOut)
async def verify(
    request: Request,
    payload: VerifyIn,
    db: Session = Depends(get_db),
    x_api_key: str | None = Header(default=None, alias="X-API-Key"),
    x_mitopulse_sig: str | None = Header(default=None, alias="X-MitoPulse-Signature"),
):
    require_api_key(x_api_key)
    raw = await request.body()
    verify_hmac_signature(raw, x_mitopulse_sig)

    now = int(time.time())
    if abs(payload.ts - now) > settings.allowed_skew_seconds:
        _audit(db, "verify", False, "ts_out_of_range", payload.user, payload.device, payload.request_id)
        _store_verify(db, payload, False, "ts_out_of_range")
        return VerifyOut(verified=False, reason="ts_out_of_range")

    # Replay protection on request_id (store as an audit log unique-ish, but we keep it simple: if already exists in audit with same request_id+action)
    # We'll just rely on IdentityEvent request_id uniqueness for post; for verify we log and block duplicates per action+request_id.
    existing = db.query(AuditLog).filter(AuditLog.action=="verify", AuditLog.request_id==payload.request_id).first()
    if existing:
        _audit(db, "verify", False, "replay_request_id", payload.user, payload.device, payload.request_id)
        _store_verify(db, payload, False, "replay_request_id")
        return VerifyOut(verified=False, reason="replay_request_id")

    latest = (
        db.query(IdentityEvent)
        .filter(IdentityEvent.user==payload.user, IdentityEvent.device==payload.device)
        .order_by(IdentityEvent.ts.desc())
        .first()
    )
    if not latest:
        _audit(db, "verify", False, "no_identity_events", payload.user, payload.device, payload.request_id)
        _store_verify(db, payload, False, "no_identity_events")
        return VerifyOut(verified=False, reason="no_identity_events")

    if payload.dynamic_id != latest.dynamic_id:
        _audit(db, "verify", False, "mismatch", payload.user, payload.device, payload.request_id)
        _store_verify(db, payload, False, "mismatch")
        return VerifyOut(verified=False, reason="mismatch")

    _audit(db, "verify", True, "ok", payload.user, payload.device, payload.request_id)
    _store_verify(db, payload, True, "ok")
    return VerifyOut(verified=True, reason="ok")

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request, db: Session = Depends(get_db)):
    events = db.query(IdentityEvent).order_by(IdentityEvent.ts.desc()).limit(200).all()
    verifs = db.query(Verification).order_by(Verification.ts.desc()).limit(200).all()
    audits = db.query(AuditLog).order_by(AuditLog.ts.desc()).limit(200).all()

    coercion_alerts = sum(1 for e in events if e.coercion)
    return templates.TemplateResponse(
        "dashboard.html",
        {
            "request": request,
            "events": events,
            "verifs": verifs,
            "audits": audits,
            "counts": {
                "events": len(events),
                "verifs": len(verifs),
                "coercion": coercion_alerts,
            },
            "skew": settings.allowed_skew_seconds,
            "db_path": settings.db_path,
            "version": app.version,
        },
    )

def _audit(db: Session, action: str, ok: bool, reason: str, user: str, device: str, request_id: str):
    row = AuditLog(ts=int(time.time()), action=action, ok=ok, reason=reason, user=user, device=device, request_id=request_id)
    db.add(row)
    db.commit()

def _store_verify(db: Session, payload: VerifyIn, verified: bool, reason: str):
    row = Verification(ts=payload.ts, user=payload.user, device=payload.device, dynamic_id=payload.dynamic_id, verified=verified, reason=reason)
    db.add(row)
    db.commit()
