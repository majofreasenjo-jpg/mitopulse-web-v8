from pydantic import BaseModel, Field
from typing import Optional

class IdentityEventIn(BaseModel):
    ts: int = Field(..., description="Epoch seconds (client timestamp)")
    user: str
    device: str
    tier: str
    index: float
    slope: float
    dynamic_id: str
    risk: int = 0
    coercion: bool = False
    request_id: str

class VerifyIn(BaseModel):
    ts: int
    user: str
    device: str
    dynamic_id: str
    request_id: str

class VerifyOut(BaseModel):
    verified: bool
    reason: str
