from pydantic import BaseModel
import os

class Settings(BaseModel):
    # Public base URL used by clients (optional)
    public_base_url: str = os.getenv("MITOPULSE_PUBLIC_BASE_URL", "")
    # Allowed timestamp skew for demo (seconds)
    allowed_skew_seconds: int = int(os.getenv("MITOPULSE_ALLOWED_SKEW_SECONDS", "86400"))
    # API key (optional). If set, clients must send X-API-Key.
    api_key: str = os.getenv("MITOPULSE_API_KEY", "")
    # SQLite path
    db_path: str = os.getenv("MITOPULSE_DB_PATH", "./mitopulse.db")
    # HMAC secret for demo signing (server-side verification of signature header)
    # In real systems you'd rotate and keep per-device secrets. Here it's a global demo key.
    demo_hmac_secret: str = os.getenv("MITOPULSE_DEMO_HMAC_SECRET", "CHANGE_ME_DEMO_SECRET")

settings = Settings()
