# Mobile / Wearables note (v2 DEMO GLOBAL)

This v2 package prioritizes a universal *off-store* demo:
- Use the PWA on Android/iOS
- Install it to home screen (app-like)
- It works on phones, tablets, PCs

For Samsung Watch (SM-R800) you will typically bridge data via the phone:
- Watch collects signals (HR etc.) using Samsung Health / Health Services
- Phone app (or PWA) uses those signals and posts derived events
- In this demo, you can simulate watch values via the PWA sliders

If you want native Android + Wear OS collectors next, we can add:
- Android (Kotlin) background service reading sensor streams
- Wear OS companion sending HR/steps to phone via Data Layer API
