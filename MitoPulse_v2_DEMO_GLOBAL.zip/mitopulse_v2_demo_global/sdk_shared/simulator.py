import time, json, uuid, random
import requests

def randid(n=16):
    chars="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"
    return "".join(random.choice(chars) for _ in range(n))

def post_json(url, payload, api_key=None):
    headers={"Content-Type":"application/json"}
    if api_key:
        headers["X-API-Key"]=api_key
    r=requests.post(url, headers=headers, data=json.dumps(payload))
    try:
        return r.status_code, r.json()
    except Exception:
        return r.status_code, {"raw": r.text}

def run(backend="http://127.0.0.1:8000", user="enterprise_user", device="pc-sim", api_key=""):
    # 5-day demo series
    series=[
        {"idx":0.62, "slope":0.00, "tier":"tier2"},
        {"idx":0.43, "slope":-0.18, "tier":"tier2"},
        {"idx":0.75, "slope":0.31, "tier":"tier2"},
        {"idx":0.33, "slope":-0.42, "tier":"tier2"},
        {"idx":0.14, "slope":-0.18, "tier":"tier2"},
    ]
    ts=int(time.time())-5*86400
    last_dyn=None
    for d in series:
        ts+=86400
        dyn=randid(20)
        last_dyn=dyn
        payload={
            "ts": ts,
            "user": user,
            "device": device,
            "tier": d["tier"],
            "index": d["idx"],
            "slope": d["slope"],
            "dynamic_id": dyn,
            "risk": 0,
            "coercion": False,
            "request_id": str(uuid.uuid4()),
        }
        code, data = post_json(f"{backend}/v1/identity-events", payload, api_key or None)
        print("POST", ts, d["idx"], "->", code, data)

    vpayload={"ts": int(time.time()), "user": user, "device": device, "dynamic_id": last_dyn, "request_id": str(uuid.uuid4())}
    code, data = post_json(f"{backend}/v1/verify", vpayload, api_key or None)
    print("VERIFY", code, data)

if __name__=="__main__":
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument("--backend", default="http://127.0.0.1:8000")
    ap.add_argument("--user", default="enterprise_user")
    ap.add_argument("--device", default="pc-sim")
    ap.add_argument("--api-key", default="")
    args=ap.parse_args()
    run(args.backend, args.user, args.device, args.api_key)
