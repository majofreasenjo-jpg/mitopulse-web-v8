
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from core.graph_engine.graph import nodes, edges, add_node, add_edge
from core.guardian_engine.guardian import evaluate_risk
from core.trust_engine.trust import update_trust
from core.fraud_spread_engine.spread import simulate_attack
from pilot.pilot import pilot_users
from simulation.simulate import run_campaign

app = FastAPI(title="MitoPulse Platform v1")
templates = Jinja2Templates(directory="templates")

@app.post("/api/bootstrap")
def bootstrap():
    nodes.clear()
    edges.clear()
    for nid,label in pilot_users:
        add_node(nid,label)
    add_edge("nd_manuel_01","nd_natalie_01")
    add_edge("nd_manuel_01","nd_ricardo_01")
    return {"nodes":nodes,"edges":edges}

@app.post("/api/interaction/{a}/{b}")
def interaction(a,b):
    add_edge(a,b)
    update_trust(nodes[a])
    return {"ok":True}

@app.post("/api/attack")
def attack():
    nid=simulate_attack(nodes)
    if nid:
        decision=evaluate_risk(nodes[nid])
        return {"target":nid,"risk":nodes[nid]["risk"],"decision":decision}

@app.get("/api/simulation")
def simulation():
    return run_campaign()

@app.get("/api/state")
def state():
    return {"nodes":nodes,"edges":edges}

@app.get("/",response_class=HTMLResponse)
def home(request:Request):
    return templates.TemplateResponse("index.html",{"request":request})
