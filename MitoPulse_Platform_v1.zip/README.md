
MitoPulse Platform v1

Arquitectura modular del sistema.

Incluye:
- Graph Engine
- Guardian Engine
- Trust Engine
- Fraud Spread Engine
- Pilot nodes
- Industry simulation
- Demo dashboard

Ejecutar:

pip install fastapi uvicorn jinja2
uvicorn server:app --reload

Abrir:
http://127.0.0.1:8000
