
flows={
"bank_transfer":"Urgent bank transfer requested",
"marketplace":"Fake payment confirmation",
"crypto_wallet":"Wallet signature request"
}
