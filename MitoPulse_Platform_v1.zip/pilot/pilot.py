
pilot_users = [
("nd_manuel_01","Manuel"),
("nd_natalie_01","Natalie"),
("nd_paulina_01","Paulina"),
("nd_ricardo_01","Ricardo")
]
