
nodes = {}
edges = []

def add_node(node_id, label):
    nodes[node_id] = {"id": node_id, "label": label, "trust": 0.6, "risk": 0.0}

def add_edge(a, b, interaction="message"):
    edges.append({"source": a, "target": b, "type": interaction})
