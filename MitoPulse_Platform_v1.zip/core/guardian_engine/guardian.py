
def evaluate_risk(node):
    risk = node.get("risk",0)
    if risk > 0.8:
        return "BLOCK"
    if risk > 0.5:
        return "REVIEW"
    return "ALLOW"
