
import random

def simulate_attack(nodes):
    import random
    if not nodes:
        return None
    nid = random.choice(list(nodes.keys()))
    nodes[nid]["risk"] = round(random.uniform(0.7,0.95),3)
    return nid
