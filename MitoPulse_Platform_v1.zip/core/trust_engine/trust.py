
def update_trust(node):
    node["trust"] = min(0.95, node.get("trust",0.6)+0.02)
