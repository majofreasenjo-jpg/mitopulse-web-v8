
import random

def run_campaign(size=10):
    results=[]
    for i in range(size):
        risk=random.uniform(0.2,0.95)
        decision="BLOCK" if risk>0.8 else "REVIEW" if risk>0.5 else "ALLOW"
        results.append({"risk":round(risk,3),"decision":decision})
    return results
