
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from datetime import datetime
import random

app = FastAPI(title="MitoPulse Industry Demo")
templates = Jinja2Templates(directory="templates")

flows = {
    "bank_transfer_fraud": "Hola, soy tu familiar. Necesito una transferencia urgente.",
    "marketplace_scam": "Ya transferí. Libera el producto ahora.",
    "crypto_wallet_phishing": "Firma esta transacción para verificar tu cuenta.",
    "executive_impersonation": "Soy el CEO. Paga esta factura de inmediato."
}

def now():
    return datetime.utcnow().isoformat()+"Z"

@app.get("/api/flows")
def get_flows():
    return flows

@app.post("/api/run/{flow_id}")
def run(flow_id: str):
    msg = flows.get(flow_id, "unknown")
    legitimacy = round(random.uniform(0.08, 0.80), 3)
    risk = round(1 - legitimacy, 3)
    decision = "BLOCK" if risk > 0.75 else "REVIEW" if risk > 0.45 else "ALLOW"
    return {"flow_id": flow_id, "message": msg, "legitimacy_score": legitimacy, "risk_score": risk, "guardian_decision": decision, "timestamp": now()}

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
