
# MitoPulse Industry Demo

Demo ejecutable para socios e inversionistas.

## Flujos incluidos
- bank_transfer_fraud
- marketplace_scam
- crypto_wallet_phishing
- executive_impersonation

## Ejecutar
```bash
pip install fastapi uvicorn jinja2
uvicorn server:app --reload
```
