
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from datetime import datetime
import random

app = FastAPI(title="MitoPulse v5 Industry Demo Layer")
templates = Jinja2Templates(directory="templates")

SCENARIOS = {
    "banking": {"title":"Fraude bancario","contexts":["financial_transfer","urgent_transfer"]},
    "marketplace": {"title":"Fraude marketplace","contexts":["fake_receipt","new_buyer"]},
    "crypto": {"title":"Wallet phishing","contexts":["signature_request","wallet_recovery"]},
}

class DemoRun(BaseModel):
    industry: str
    context: str

def now():
    return datetime.utcnow().isoformat()+"Z"

def run_demo(industry, context):
    base = {"banking":0.28,"marketplace":0.22,"crypto":0.34}[industry]
    anomaly = random.uniform(0.20,0.45)
    legitimacy = round(max(0.02, min(0.98, 1 - base - anomaly)), 3)
    risk = round(1 - legitimacy, 3)
    decision = "BLOCK" if risk >= 0.75 else "REVIEW" if risk >= 0.45 else "ALLOW"
    return {
        "industry": industry,
        "context": context,
        "legitimacy_score": legitimacy,
        "risk_score": risk,
        "guardian_decision": decision,
        "timestamp": now()
    }

@app.get("/api/scenarios")
def scenarios():
    return SCENARIOS

@app.post("/api/run")
def run(payload: DemoRun):
    return run_demo(payload.industry, payload.context)

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
