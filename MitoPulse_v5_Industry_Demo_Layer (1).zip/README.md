
# MitoPulse v5 Industry Demo Layer

Demos ejecutables por industria:
- banca
- marketplace
- crypto

## Ejecutar
```bash
pip install fastapi uvicorn jinja2
uvicorn server:app --reload
```
