import random
from app.services.simulation_profiles import PROFILE_LIBRARY

def build_scenario(profile: str, scenario_type: str, nodes: int, fraud_ratio: float, intensity: str) -> dict:
    library = PROFILE_LIBRARY.get(profile)
    if not library:
        raise ValueError(f"Unknown profile: {profile}")
    scenario = library["scenarios"].get(scenario_type)
    if not scenario:
        raise ValueError(f"Unknown scenario_type for profile {profile}: {scenario_type}")

    multiplier = {"low": 0.90, "medium": 1.0, "high": 1.12}.get(intensity, 1.0)
    fraud_nodes = int(nodes * fraud_ratio)
    total_edges = int(nodes * 1.8)
    alerts = []
    for i in range(min(fraud_nodes, 25)):
        alerts.append({
            "target": f"sim_{i:04d}",
            "risk_score": round(min(0.99, scenario["base_risk"] * multiplier + random.uniform(-0.05, 0.06)), 3),
            "reason_code": scenario_type,
        })
    decision_summary = {
        "ALLOW": max(0, int(nodes * 0.72 - fraud_nodes * 0.2)),
        "REVIEW": max(0, int(nodes * 0.20 + fraud_nodes * 0.25)),
        "BLOCK": max(0, int(nodes * 0.08 + fraud_nodes * 0.40)),
    }
    return {
        "profile": profile,
        "scenario_type": scenario_type,
        "description": scenario["description"],
        "nodes": nodes,
        "fraud_nodes": fraud_nodes,
        "total_edges_estimate": total_edges,
        "contexts": library["default_contexts"],
        "intensity": intensity,
        "decision_summary": decision_summary,
        "sample_alerts": alerts,
        "recommended_demo_message": f"Escenario {profile}/{scenario_type}: {scenario['description']}"
    }
