PROFILE_LIBRARY = {
    "retail_bank": {
        "default_contexts": ["bank_transfer", "urgent_transfer", "new_beneficiary"],
        "scenarios": {
            "social_fraud": {"description": "Hola mamá cambié mi número / urgencia financiera", "base_risk": 0.82},
            "mule_cluster": {"description": "Cuentas mule y funnel transaccional", "base_risk": 0.88},
            "new_beneficiary_push": {"description": "Transferencia a destinatario nuevo bajo presión", "base_risk": 0.77},
        },
    },
    "corporate_bank": {
        "default_contexts": ["supplier_payment", "invoice_change", "exec_impersonation"],
        "scenarios": {
            "supplier_fraud": {"description": "Cambio fraudulento de cuenta de proveedor", "base_risk": 0.84},
            "ceo_fraud": {"description": "Suplantación ejecutiva y pago urgente", "base_risk": 0.90},
        },
    },
    "marketplace_p2p": {
        "default_contexts": ["fake_receipt", "buyer_seller_chat", "shipment_release"],
        "scenarios": {
            "fake_receipt": {"description": "Comprobante falso y liberación anticipada", "base_risk": 0.83},
            "seller_cluster": {"description": "Cluster de cuentas recicladas", "base_risk": 0.79},
        },
    },
    "crypto_exchange": {
        "default_contexts": ["wallet_sign", "withdrawal", "drainer_link"],
        "scenarios": {
            "wallet_drainer": {"description": "Firma maliciosa y drenado de wallet", "base_risk": 0.91},
            "bridge_outflow": {"description": "Salida rápida a cluster riesgoso", "base_risk": 0.87},
        },
    },
    "telco_identity": {
        "default_contexts": ["sim_swap", "number_change", "identity_anchor"],
        "scenarios": {
            "sim_swap": {"description": "Fraude por cambio de SIM", "base_risk": 0.86},
            "new_channel_anchor": {"description": "Alta fraudulenta de nuevo canal", "base_risk": 0.74},
        },
    },
    "wallet_app": {
        "default_contexts": ["payment_request", "p2p", "shared_signal"],
        "scenarios": {
            "urgent_request": {"description": "Solicitud urgente P2P relacional", "base_risk": 0.78},
            "fraud_ring": {"description": "Anillo de cuentas mule y salida", "base_risk": 0.85},
        },
    },
}
