from sqlalchemy import Column, Integer, String, Float, Text, DateTime
from datetime import datetime
from app.core.database import Base

def now():
    return datetime.utcnow()

class ScenarioRun(Base):
    __tablename__ = "scenario_runs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    tenant_id = Column(String, index=True, nullable=False)
    profile = Column(String, nullable=False)
    scenario_type = Column(String, nullable=False)
    nodes = Column(Integer, default=1000)
    fraud_ratio = Column(Float, default=0.03)
    status = Column(String, default="ready")
    output_json = Column(Text, default="{}")
    created_at = Column(DateTime, default=now)
