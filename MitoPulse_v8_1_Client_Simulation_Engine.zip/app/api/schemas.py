from pydantic import BaseModel, Field

class ScenarioRequest(BaseModel):
    tenant_id: str = "bank_demo"
    profile: str = "retail_bank"
    scenario_type: str = "social_fraud"
    nodes: int = Field(default=1000, ge=50, le=10000)
    fraud_ratio: float = Field(default=0.03, ge=0.0, le=0.25)
    intensity: str = "medium"
