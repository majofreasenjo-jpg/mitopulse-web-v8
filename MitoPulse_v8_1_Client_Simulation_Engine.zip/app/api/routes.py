import json
from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.schema import ScenarioRun
from app.api.schemas import ScenarioRequest
from app.services.scenario_engine import build_scenario
from app.services.simulation_profiles import PROFILE_LIBRARY

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/api/profiles")
def profiles():
    return PROFILE_LIBRARY

@router.post("/api/scenario/run")
def run_scenario(payload: ScenarioRequest, db: Session = Depends(get_db)):
    output = build_scenario(payload.profile, payload.scenario_type, payload.nodes, payload.fraud_ratio, payload.intensity)
    row = ScenarioRun(
        tenant_id=payload.tenant_id,
        profile=payload.profile,
        scenario_type=payload.scenario_type,
        nodes=payload.nodes,
        fraud_ratio=payload.fraud_ratio,
        output_json=json.dumps(output),
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return {"run_id": row.id, "result": output}

@router.get("/api/scenario/runs")
def runs(db: Session = Depends(get_db)):
    rows = db.query(ScenarioRun).order_by(ScenarioRun.id.desc()).limit(20).all()
    return [{
        "id": r.id,
        "tenant_id": r.tenant_id,
        "profile": r.profile,
        "scenario_type": r.scenario_type,
        "nodes": r.nodes,
        "fraud_ratio": r.fraud_ratio,
        "status": r.status,
        "created_at": r.created_at.isoformat() + "Z"
    } for r in rows]

@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
