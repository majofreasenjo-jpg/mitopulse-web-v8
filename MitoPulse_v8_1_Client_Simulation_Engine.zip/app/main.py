from fastapi import FastAPI
from app.core.database import Base, engine
from app.api.routes import router

Base.metadata.create_all(bind=engine)
app = FastAPI(title="MitoPulse v8.1 Client Simulation Engine")
app.include_router(router)
