# MitoPulse v8.1 Client Simulation Engine

Motor de simulaciones parametrizables por cliente / industria.

## Perfiles incluidos
- retail_bank
- corporate_bank
- marketplace_p2p
- crypto_exchange
- telco_identity
- wallet_app

## Ejecutar
```bash
pip install -r requirements.txt
python run.py
```

Abrir:
`http://127.0.0.1:8000`
