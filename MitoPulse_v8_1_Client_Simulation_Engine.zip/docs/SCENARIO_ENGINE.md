# Scenario Engine

Esta versión agrega simulaciones a medida del cliente con:
- perfil por industria
- escenario por fraude
- volumen de nodos
- ratio de fraude
- intensidad

Pensada para demos comerciales y diseño de pilotos.
