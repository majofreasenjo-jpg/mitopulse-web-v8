
# MitoPulse Unified Pilot v4

Versión unificada y ejecutable del piloto real.

## Incluye
- 4 nodos reales: Manuel, Natalie, Paulina y Ricardo
- captura de interacciones
- cross-pulse
- simulación de ataques
- trust/risk scoring básico
- dashboard web

## Ejecutar
```bash
pip install fastapi uvicorn jinja2
uvicorn server:app --reload
```

Abre:
http://127.0.0.1:8000
