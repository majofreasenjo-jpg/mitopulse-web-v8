
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from datetime import datetime
import uuid, random

app = FastAPI(title="MitoPulse Unified Pilot v4")
templates = Jinja2Templates(directory="templates")

PILOT_USERS = [
    ("nd_manuel_01","Manuel","ALPHA-MANUEL"),
    ("nd_natalie_01","Natalie","ALPHA-NATALIE"),
    ("nd_paulina_01","Paulina","ALPHA-PAULINA"),
    ("nd_ricardo_01","Ricardo","ALPHA-RICARDO"),
]

nodes = {}
edges = []
events = []
alerts = []
cross_pulses = []

class InviteIn(BaseModel):
    invite_code: str

class InteractionIn(BaseModel):
    source: str
    target: str
    interaction_type: str = "whatsapp_message"
    context: str = "general"

class CrossPulseIn(BaseModel):
    source: str
    target: str
    reason: str = "validate_interaction"

class AttackIn(BaseModel):
    attack_type: str = "number_change"

def now():
    return datetime.utcnow().isoformat()+"Z"

def ensure_node(node_id, label=None, node_type="pilot"):
    if node_id not in nodes:
        nodes[node_id] = {
            "id": node_id,
            "label": label or node_id,
            "type": node_type,
            "trust_score": 0.50,
            "risk_score": 0.0
        }

def recompute():
    counts = {}
    for e in edges:
        counts[e["source"]] = counts.get(e["source"], 0) + 1
        counts[e["target"]] = counts.get(e["target"], 0) + 1
    for n in nodes.values():
        degree = counts.get(n["id"], 0)
        trust = 0.40 + min(0.50, degree * 0.08) - min(0.30, n["risk_score"] * 0.35)
        n["trust_score"] = round(max(0.05, min(0.98, trust)), 3)

@app.post("/api/pilot/bootstrap")
def bootstrap():
    nodes.clear(); edges.clear(); events.clear(); alerts.clear(); cross_pulses.clear()
    for nid, label, _code in PILOT_USERS:
        ensure_node(nid, label, "pilot")
    base = [
        ("nd_manuel_01","nd_natalie_01","whatsapp_message","general"),
        ("nd_manuel_01","nd_ricardo_01","call","general"),
        ("nd_natalie_01","nd_paulina_01","whatsapp_message","general"),
        ("nd_ricardo_01","nd_paulina_01","in_person","general"),
    ]
    for s,t,it,ctx in base:
        edges.append({"source":s,"target":t,"interaction_type":it,"context":ctx,"created_at":now()})
    events.append({"type":"bootstrap","message":"Pilot initialized","timestamp":now()})
    recompute()
    return {"ok": True, "nodes": list(nodes.values()), "edges": edges}

@app.get("/api/pilot/users")
def pilot_users():
    return [{"node_id": nid, "display_name": label, "invite_code": code} for nid, label, code in PILOT_USERS]

@app.post("/api/pilot/resolve-invite")
def resolve_invite(payload: InviteIn):
    for nid, label, code in PILOT_USERS:
        if payload.invite_code == code:
            ensure_node(nid, label, "pilot")
            return {"ok": True, "node_id": nid, "display_name": label}
    return {"ok": False, "error": "invalid_invite_code"}

@app.post("/api/interaction")
def add_interaction(payload: InteractionIn):
    ensure_node(payload.source, payload.source, "pilot" if payload.source.startswith("nd_") else "external")
    ensure_node(payload.target, payload.target, "pilot" if payload.target.startswith("nd_") else "external")
    edge = {
        "source": payload.source,
        "target": payload.target,
        "interaction_type": payload.interaction_type,
        "context": payload.context,
        "created_at": now()
    }
    edges.append(edge)
    events.append({"type":"interaction", **edge, "timestamp": now()})
    recompute()
    return {"ok": True, "edge": edge, "source_trust": nodes[payload.source]["trust_score"], "target_trust": nodes[payload.target]["trust_score"]}

@app.post("/api/crosspulse")
def crosspulse(payload: CrossPulseIn):
    ensure_node(payload.source)
    ensure_node(payload.target)
    pulse_id = "cp_" + uuid.uuid4().hex[:10]
    row = {"pulse_id": pulse_id, "source": payload.source, "target": payload.target, "reason": payload.reason, "status":"confirmed", "confirmed_at": now()}
    cross_pulses.append(row)
    edges.append({"source":payload.source,"target":payload.target,"interaction_type":"cross_pulse","context":payload.reason,"created_at":now()})
    events.append({"type":"cross_pulse","pulse_id":pulse_id,"source":payload.source,"target":payload.target,"timestamp":now()})
    recompute()
    return {"ok": True, "pulse": row}

@app.post("/api/attack")
def attack(payload: AttackIn):
    attacker = "ext_attacker_01"
    ensure_node(attacker, "Attacker X", "external")
    scenarios = {
        "number_change": (["nd_natalie_01","nd_ricardo_01"], "Hola, cambié mi número. Necesito ayuda urgente.", "number_change"),
        "marketplace": (["nd_ricardo_01"], "Ya transferí. Revisa el comprobante y envía el producto.", "fake_receipt"),
        "wallet": (["nd_paulina_01"], "Firma esta solicitud urgente ahora.", "wallet_phishing"),
    }
    targets, msg, ctx = scenarios.get(payload.attack_type, scenarios["number_change"])
    out = []
    for tgt in targets:
        score = round(random.uniform(0.72, 0.95), 3)
        nodes[tgt]["risk_score"] = max(nodes[tgt]["risk_score"], round(score * 0.55, 3))
        decision = "BLOCK" if score >= 0.80 else "REVIEW"
        alert = {"attack_type":payload.attack_type,"source":attacker,"target":tgt,"risk_score":score,"guardian_decision":decision,"message":msg,"context":ctx,"timestamp":now()}
        alerts.append(alert)
        events.append({"type":"attack","source":attacker,"target":tgt,"attack_type":payload.attack_type,"timestamp":now()})
        out.append(alert)
    recompute()
    return {"ok": True, "alerts": out}

@app.get("/api/graph")
def graph():
    return {"nodes": list(nodes.values()), "edges": edges}

@app.get("/api/events")
def get_events():
    return list(reversed(events[-30:]))

@app.get("/api/alerts")
def get_alerts():
    return list(reversed(alerts[-20:]))

@app.get("/api/crosspulse")
def get_cross():
    return list(reversed(cross_pulses[-20:]))

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
