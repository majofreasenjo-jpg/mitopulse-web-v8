
# MitoPulse v5 Network Growth Engine

Motor ejecutable para crecimiento seguro de la red.

## Incluye
- red semilla
- sistema de invitaciones
- unión automática de nodos
- clusters
- simulación de nodo malicioso
- quarantine relacional

## Ejecutar
```bash
pip install fastapi uvicorn jinja2
uvicorn server:app --reload
```
