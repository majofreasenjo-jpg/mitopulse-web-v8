
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from datetime import datetime
import uuid, random

app = FastAPI(title="MitoPulse v5 Network Growth Engine")
templates = Jinja2Templates(directory="templates")

nodes = {}
invites = []
clusters = {}
quarantine = []

class SeedIn(BaseModel):
    seed_cluster: str = "pilot_seed"

class InviteIn(BaseModel):
    inviter: str
    label: str
    cluster: str | None = None

class JoinIn(BaseModel):
    invite_id: str

class AttackIn(BaseModel):
    node_id: str

def now():
    return datetime.utcnow().isoformat()+"Z"

def ensure_node(node_id, label, cluster, status="active"):
    nodes[node_id] = {
        "id": node_id,
        "label": label,
        "cluster": cluster,
        "status": status,
        "trust_score": 0.65,
        "risk_score": 0.0,
        "neighbors": []
    }
    clusters.setdefault(cluster, []).append(node_id)

def recompute():
    for nid, n in nodes.items():
        degree = len(set(n["neighbors"]))
        n["trust_score"] = round(max(0.05, min(0.98, 0.35 + degree*0.08 - n["risk_score"]*0.45)), 3)

@app.post("/api/network/seed")
def seed(payload: SeedIn):
    nodes.clear(); invites.clear(); clusters.clear(); quarantine.clear()
    seed_nodes = [
        ("nd_manuel_01","Manuel",payload.seed_cluster),
        ("nd_natalie_01","Natalie",payload.seed_cluster),
        ("nd_paulina_01","Paulina",payload.seed_cluster),
        ("nd_ricardo_01","Ricardo",payload.seed_cluster),
    ]
    for nid, label, cluster in seed_nodes:
        ensure_node(nid, label, cluster)
    base_edges=[("nd_manuel_01","nd_natalie_01"),("nd_manuel_01","nd_ricardo_01"),("nd_natalie_01","nd_paulina_01"),("nd_ricardo_01","nd_paulina_01")]
    for a,b in base_edges:
        nodes[a]["neighbors"].append(b)
        nodes[b]["neighbors"].append(a)
    recompute()
    return {"ok": True, "nodes": list(nodes.values()), "clusters": clusters}

@app.post("/api/network/invite")
def invite(payload: InviteIn):
    if payload.inviter not in nodes:
        return {"ok": False, "error": "inviter_not_found"}
    invite_id = "inv_" + uuid.uuid4().hex[:10]
    cluster = payload.cluster or nodes[payload.inviter]["cluster"]
    row = {"invite_id": invite_id, "inviter": payload.inviter, "label": payload.label, "cluster": cluster, "status": "pending", "created_at": now()}
    invites.append(row)
    return {"ok": True, "invite": row}

@app.post("/api/network/join")
def join(payload: JoinIn):
    row = next((x for x in invites if x["invite_id"] == payload.invite_id), None)
    if not row:
        return {"ok": False, "error": "invite_not_found"}
    nid = "nd_" + row["label"].lower().replace(" ", "_") + "_" + uuid.uuid4().hex[:4]
    ensure_node(nid, row["label"], row["cluster"])
    inviter = row["inviter"]
    nodes[nid]["neighbors"].append(inviter)
    nodes[inviter]["neighbors"].append(nid)
    row["status"] = "accepted"
    row["joined_node_id"] = nid
    row["joined_at"] = now()
    recompute()
    return {"ok": True, "node": nodes[nid]}

@app.post("/api/network/attack")
def attack(payload: AttackIn):
    if payload.node_id not in nodes:
        return {"ok": False, "error": "node_not_found"}
    n = nodes[payload.node_id]
    n["risk_score"] = round(random.uniform(0.72, 0.95), 3)
    if len(set(n["neighbors"])) <= 1 and n["risk_score"] >= 0.80:
        n["status"] = "quarantined"
        quarantine.append({"node_id": n["id"], "cluster": n["cluster"], "reason": "relational_quarantine", "timestamp": now()})
    recompute()
    return {"ok": True, "node": n}

@app.get("/api/network/state")
def state():
    return {"nodes": list(nodes.values()), "invites": invites, "clusters": clusters, "quarantine": quarantine}

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
