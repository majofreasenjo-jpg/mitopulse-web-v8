
# Piloto de 4 nodos

Participantes:

- Nodo A: Manuel
- Nodo B: Ana
- Nodo C: Bruno
- Nodo D: Carla

## Fase 1

Crear interacciones legítimas.

Ejemplo:

Manuel <-> Ana
Manuel <-> Bruno
Ana <-> Carla

El sistema aprende:

- horarios
- frecuencia
- direcciones de interacción

## Fase 2

Introducir nodo atacante:

Nodo X

X -> Ana

Simular estafa:

"Cambié mi número, necesito ayuda urgente."

## Resultado esperado

Legitimacy Score bajo
Alerta de impersonación
