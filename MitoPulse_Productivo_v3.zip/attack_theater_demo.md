
# Attack Theater Demo

Duración: 10 minutos

Escenario:

1. Red normal
2. Aparece nodo atacante
3. Intenta contactar múltiples usuarios
4. Fraud Spread Engine detecta patrón
5. Nodo marcado como HIGH RISK

Dashboard muestra:

Network Integrity Score
Fraud Spread Alert
