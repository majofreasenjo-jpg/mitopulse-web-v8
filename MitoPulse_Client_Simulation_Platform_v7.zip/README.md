# MitoPulse Commercial Platform v7

Versión comercial con:
- JWT por tenant
- multi-tenant real
- creación de casos
- audit log
- export report
- upload real
- SQLite por defecto / PostgreSQL opcional

## Ejecutar
cp .env.example .env
pip install -r requirements.txt
python run.py

## Flujo
1. Generar token en `/api/auth/token?tenant_id=...`
2. Usar Bearer token en endpoints protegidos
3. Cargar o generar corridas
4. Crear casos
5. Exportar reportes
