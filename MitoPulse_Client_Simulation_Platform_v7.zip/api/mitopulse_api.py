import json, os, shutil
from pathlib import Path
from fastapi import FastAPI, Request, UploadFile, File, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse, PlainTextResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from api.db import init_db, get_db, UploadRun, CaseRecord, AuditLog
from api.security import create_token, require_tenant_token
from simulator.client_dataset_builder import make_dataset
from ingestion.client_data_loader import load_client_folder, dataset_profile
from engine.graph_builder import build_graph
from engine.cluster_detector import suspicious_clusters
from engine.risk_engine import decision_projection

app = FastAPI(title="MitoPulse Commercial Platform v7")
templates = Jinja2Templates(directory="templates")
init_db()
UPLOAD_BASE_DIR = Path(os.getenv("UPLOAD_BASE_DIR", "uploads"))
UPLOAD_BASE_DIR.mkdir(parents=True, exist_ok=True)

def log_action(db: Session, tenant_id: str, action: str, payload: dict):
    db.add(AuditLog(tenant_id=tenant_id, action=action, payload_json=json.dumps(payload)))
    db.commit()

def run_pipeline(folder: str):
    customers, devices, events, signals = load_client_folder(folder)
    profile = dataset_profile(customers, devices, events, signals)
    G = build_graph(customers, devices, events, signals)
    clusters = suspicious_clusters(G)
    decisions = decision_projection(G)
    total_loss_exposure = int(events[events["label"].isin(["mule_pattern", "scam_ring", "social_chain"])]["amount"].sum())
    reviewed = decisions["REVIEW"]; blocked = decisions["BLOCK"]
    customers_count = max(profile["customers"], 1)
    review_rate = round((reviewed / customers_count) * 100, 2)
    false_positive_proxy = round(max(0.5, 8.5 - (len(clusters) * 0.6)), 2)
    prevented_estimate = int(total_loss_exposure * min(0.72, 0.35 + blocked / max(customers_count, 1)))
    before = {
        "estimated_exposure": total_loss_exposure,
        "review_rate_pct": round(review_rate + 3.0, 2),
        "false_positive_proxy_pct": round(false_positive_proxy + 2.2, 2),
    }
    after = {
        "estimated_exposure": max(total_loss_exposure - prevented_estimate, 0),
        "review_rate_pct": review_rate,
        "false_positive_proxy_pct": false_positive_proxy,
    }
    return {
        "dataset_profile": profile,
        "graph_stats": {"nodes": G.number_of_nodes(), "edges": G.number_of_edges()},
        "clusters": clusters[:12],
        "decision_projection": decisions,
        "executive_kpis": {
            "estimated_loss_exposure": total_loss_exposure,
            "estimated_prevented_loss": prevented_estimate,
            "review_rate_pct": review_rate,
            "false_positive_proxy_pct": false_positive_proxy,
            "clusters_detected": len(clusters),
        },
        "before_after": {"before": before, "after": after},
    }

@app.get("/", response_class=HTMLResponse)
def home(request: Request, db: Session = Depends(get_db)):
    runs = db.query(UploadRun).order_by(UploadRun.id.desc()).limit(20).all()
    cases = db.query(CaseRecord).order_by(CaseRecord.id.desc()).limit(15).all()
    audits = db.query(AuditLog).order_by(AuditLog.id.desc()).limit(15).all()
    return templates.TemplateResponse("dashboard.html", {"request": request, "runs": runs, "cases": cases, "audits": audits})

@app.get("/api/auth/token")
def token(tenant_id: str):
    return {"tenant_id": tenant_id, "token": create_token(tenant_id)}

@app.get("/api/generate")
def generate(client_type: str = "bank", risk_multiplier: float = 1.0, tenant_id: str = Depends(require_tenant_token), db: Session = Depends(get_db)):
    out = f"data/generated_{tenant_id}_{client_type}_{str(risk_multiplier).replace('.', '_')}"
    make_dataset(out, client_type, risk_multiplier=risk_multiplier)
    result = run_pipeline(out)
    result["generation"] = {"tenant_id": tenant_id, "client_type": client_type, "risk_multiplier": risk_multiplier, "folder": out}
    row = UploadRun(tenant_id=tenant_id, client_type=client_type, source_kind="generated", folder_path=out, summary_json=json.dumps(result))
    db.add(row); db.commit(); db.refresh(row)
    log_action(db, tenant_id, "generate_run", {"run_id": row.id, "folder": out})
    return result

@app.get("/api/load-sample")
def load_sample(client_type: str = "bank", tenant_id: str = Depends(require_tenant_token), db: Session = Depends(get_db)):
    folder = f"data/sample_{client_type}"
    result = run_pipeline(folder)
    result["sample_folder"] = folder
    row = UploadRun(tenant_id=tenant_id, client_type=client_type, source_kind="sample", folder_path=folder, summary_json=json.dumps(result))
    db.add(row); db.commit(); db.refresh(row)
    log_action(db, tenant_id, "load_sample", {"run_id": row.id, "folder": folder})
    return result

@app.post("/api/upload")
async def upload_dataset(
    client_type: str = Form(...),
    tenant_id_form: str = Form(...),
    customers: UploadFile = File(...),
    devices: UploadFile = File(...),
    events: UploadFile = File(...),
    signals: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    folder = UPLOAD_BASE_DIR / f"{tenant_id_form}_{client_type}_{len(list(UPLOAD_BASE_DIR.iterdir()))+1:03d}"
    folder.mkdir(parents=True, exist_ok=True)
    mapping = {"customers.csv": customers, "devices.csv": devices, "events.csv": events, "signals.csv": signals}
    for fname, up in mapping.items():
        with open(folder / fname, "wb") as f:
            shutil.copyfileobj(up.file, f)
    result = run_pipeline(str(folder))
    row = UploadRun(tenant_id=tenant_id_form, client_type=client_type, source_kind="upload", folder_path=str(folder), summary_json=json.dumps(result))
    db.add(row); db.commit(); db.refresh(row)
    log_action(db, tenant_id_form, "upload_run", {"run_id": row.id, "folder": str(folder)})
    return RedirectResponse(url="/", status_code=303)

@app.post("/api/cases/create")
def create_case(run_id: int, case_title: str, tenant_id: str = Depends(require_tenant_token), db: Session = Depends(get_db)):
    row = db.query(UploadRun).filter(UploadRun.id == run_id, UploadRun.tenant_id == tenant_id).first()
    if not row:
        return JSONResponse({"error": "run not found"}, status_code=404)
    details = json.loads(row.summary_json)
    case = CaseRecord(tenant_id=tenant_id, run_id=run_id, case_title=case_title, details_json=json.dumps(details))
    db.add(case); db.commit(); db.refresh(case)
    log_action(db, tenant_id, "create_case", {"case_id": case.id, "run_id": run_id})
    return {"case_id": case.id, "status": case.status}

@app.get("/api/cases")
def list_cases(tenant_id: str = Depends(require_tenant_token), db: Session = Depends(get_db)):
    rows = db.query(CaseRecord).filter(CaseRecord.tenant_id == tenant_id).order_by(CaseRecord.id.desc()).all()
    return [{"id": r.id, "run_id": r.run_id, "case_title": r.case_title, "status": r.status, "created_at": r.created_at.isoformat() + "Z"} for r in rows]

@app.get("/api/export/report/{run_id}")
def export_report(run_id: int, tenant_id: str = Depends(require_tenant_token), db: Session = Depends(get_db)):
    row = db.query(UploadRun).filter(UploadRun.id == run_id, UploadRun.tenant_id == tenant_id).first()
    if not row:
        return PlainTextResponse("run not found", status_code=404)
    summary = json.loads(row.summary_json)
    lines = [
        f"MitoPulse Commercial Report - Run {run_id}",
        f"Tenant: {tenant_id}",
        f"Client type: {row.client_type}",
        f"Source: {row.source_kind}",
        "",
        "Executive KPIs:",
        json.dumps(summary.get('executive_kpis', {}), indent=2),
        "",
        "Before vs After:",
        json.dumps(summary.get('before_after', {}), indent=2),
        "",
        "Top Risky Customers:",
        json.dumps(summary.get('decision_projection', {}).get('top_risky_customers', [])[:10], indent=2),
    ]
    log_action(db, tenant_id, "export_report", {"run_id": run_id})
    return PlainTextResponse("\n".join(lines))

@app.get("/api/runs")
def runs(tenant_id: str = Depends(require_tenant_token), db: Session = Depends(get_db)):
    rows = db.query(UploadRun).filter(UploadRun.tenant_id == tenant_id).order_by(UploadRun.id.desc()).limit(40).all()
    return [{"id": r.id, "client_type": r.client_type, "source_kind": r.source_kind, "folder_path": r.folder_path, "created_at": r.created_at.isoformat() + "Z"} for r in rows]

@app.get("/api/run/{run_id}")
def run_detail(run_id: int, tenant_id: str = Depends(require_tenant_token), db: Session = Depends(get_db)):
    row = db.query(UploadRun).filter(UploadRun.id == run_id, UploadRun.tenant_id == tenant_id).first()
    return json.loads(row.summary_json) if row else {"error": "run not found"}
