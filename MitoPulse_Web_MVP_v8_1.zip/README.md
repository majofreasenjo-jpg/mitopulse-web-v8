# MitoPulse Web MVP v8.1

Versión reforzada con:
- cloud-only
- dashboard + app móvil/web
- simulador antifalsos positivos
- guardian mode
- trust graph
- cross pulses entre usuarios
- vista móvil tipo nodo
- métricas FP/FN/accuracy

## Variable obligatoria
DATABASE_URL=postgresql+psycopg2://USER:PASSWORD@HOST/DB?sslmode=require

## Ejecutar
pip install -r requirements.txt
export DATABASE_URL='postgresql+psycopg2://USER:PASSWORD@HOST/DB?sslmode=require'
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload

## Rutas
- / dashboard
- /app app principal
- /simulator simulador
- /node vista móvil tipo nodo
- /present modo presentación
- /onboarding guía
