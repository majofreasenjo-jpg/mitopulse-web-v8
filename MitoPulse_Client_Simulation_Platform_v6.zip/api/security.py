import os
from fastapi import Header, HTTPException

API_KEY = os.getenv("API_KEY", "demo-api-key")

def require_api_key(x_api_key: str | None = Header(default=None)):
    if x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API key")
    return True
