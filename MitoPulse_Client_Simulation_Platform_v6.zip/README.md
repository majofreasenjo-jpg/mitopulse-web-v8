# MitoPulse Pilot Platform v6

Versión piloto con:
- API key simple
- export de reportes
- endpoint de check-risk
- upload real
- persistencia de corridas
- SQLite por defecto / PostgreSQL opcional

## Ejecutar
cp .env.example .env
pip install -r requirements.txt
python run.py

## API protegida
Enviar header:
X-API-Key: demo-api-key
