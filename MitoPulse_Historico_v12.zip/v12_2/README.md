MitoPulse v12.2

Persistencia + mobile companion + graph usable

Run:
uvicorn main:app --reload
