
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

app = FastAPI(title="MitoPulse v12.2")
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("home.html", {"request": request})

@app.get("/status")
def status():
    return {"version": "v12_2", "title": "MitoPulse v12.2", "description": "Persistencia + mobile companion + graph usable" }
