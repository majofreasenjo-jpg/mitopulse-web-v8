
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

app = FastAPI(title="MitoPulse v12.5")
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("home.html", {"request": request})

@app.get("/status")
def status():
    return {"version": "v12_5", "title": "MitoPulse v12.5", "description": "Deploy checklist + UI unificada + cierre de producto" }
