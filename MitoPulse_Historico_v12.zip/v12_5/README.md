MitoPulse v12.5

Deploy checklist + UI unificada + cierre de producto

Run:
uvicorn main:app --reload
