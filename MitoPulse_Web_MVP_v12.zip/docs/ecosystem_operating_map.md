
# Full operating ecosystem map

Users / devices
→ client apps / wallets / banks / marketplaces
→ MitoPulse SDK
→ client backend
→ MitoPulse API
→ Trust Graph + MitoRelay + Fraud Hunter
→ Decision Engine
→ Global Fraud Memory
