
# MitoPulse v12

Independent release focused on:
- PostgreSQL-ready cloud deployment
- interactive graph visualization
- B2B SDK integration profile
- pilot flow demo

Run locally (optional):
pip install -r requirements.txt
uvicorn main:app --reload
