
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from datetime import datetime
import os, random, json, hashlib

app = FastAPI(title="MitoPulse v12")
templates = Jinja2Templates(directory="templates")

APP_MODE = os.getenv("APP_MODE", "cloud")
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://demo:demo@localhost/demo")

nodes = {}
edges = []
evaluations = []

def now():
    return datetime.utcnow().isoformat()

def seed():
    if nodes:
        return
    for i in range(1, 19):
        nid = f"node_{i}"
        nodes[nid] = {
            "node_id": nid,
            "trust_rank": random.randint(35, 95),
            "nodal_mass": random.randint(20, 95),
            "guardian": i in [1, 2, 7, 11],
            "status": "healthy" if i not in [9,10,15] else ("high_risk" if i in [9,15] else "quarantined"),
            "fraud_exposure": random.randint(0, 65) if i not in [10] else 85
        }
    rels = [
        ("node_1","node_2",82),("node_1","node_3",76),("node_2","node_4",61),("node_3","node_5",55),
        ("node_4","node_6",52),("node_6","node_7",71),("node_7","node_8",63),("node_8","node_9",44),
        ("node_9","node_10",88),("node_11","node_12",78),("node_12","node_13",66),("node_13","node_14",54),
        ("node_14","node_15",41),("node_15","node_16",47),("node_16","node_17",59),("node_17","node_18",64),
        ("node_2","node_11",38),("node_5","node_12",33)
    ]
    for a,b,w in rels:
        edges.append({"source":a,"target":b,"weight":w})
seed()

class EvalIn(BaseModel):
    source_node_id: str
    target_node_id: str
    industry: str = "banking"
    amount_anomaly: float = 0.9
    routine_break: float = 0.8

def compute_eval(src, tgt, industry, amount_anomaly, routine_break):
    rel = next((e for e in edges if set([e["source"], e["target"]]) == set([src, tgt])), None)
    rds = rel["weight"] if rel else 10
    ass = int((nodes[tgt]["trust_rank"] + nodes[tgt]["nodal_mass"]) / 2)
    srs = 30 + (10 if rel else 0)
    sc = max(0, int(100 - ((amount_anomaly*100 + routine_break*100)/2)))
    fe = nodes[tgt]["fraud_exposure"]
    trust_score = round((rds + ass + srs + sc)/4 - fe, 2)
    decision = "VERIFY" if trust_score >= 80 else "REVIEW" if trust_score >= 60 else "BLOCK"
    result = {
        "evaluation_id": f"ev_{len(evaluations)+1}",
        "timestamp": now(),
        "source_node_id": src,
        "target_node_id": tgt,
        "industry": industry,
        "decision": decision,
        "trust_score": trust_score,
        "breakdown": {"RDS":rds,"ASS":ass,"SRS":srs,"SC":sc,"FE":fe}
    }
    result["receipt"] = hashlib.sha256(json.dumps(result, sort_keys=True).encode()).hexdigest()[:24]
    evaluations.append(result)
    return result

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("home.html", {"request": request, "app_mode": APP_MODE, "database_url": DATABASE_URL})

@app.get("/graph", response_class=HTMLResponse)
def graph(request: Request):
    return templates.TemplateResponse("graph.html", {"request": request})

@app.get("/sdk", response_class=HTMLResponse)
def sdk(request: Request):
    return templates.TemplateResponse("sdk.html", {"request": request})

@app.get("/pilot", response_class=HTMLResponse)
def pilot(request: Request):
    return templates.TemplateResponse("pilot.html", {"request": request})

@app.get("/api/graph")
def api_graph():
    return {"nodes": list(nodes.values()), "edges": edges}

@app.post("/api/evaluate")
def api_evaluate(payload: EvalIn):
    return compute_eval(payload.source_node_id, payload.target_node_id, payload.industry, payload.amount_anomaly, payload.routine_break)

@app.get("/api/platform_profile")
def api_platform_profile():
    return {
        "hosting": "cloud-only",
        "database": "PostgreSQL-ready via DATABASE_URL",
        "sdk": ["Web SDK", "Mobile SDK", "Backend API"],
        "clients": ["banks", "fintech", "wallets", "marketplaces"]
    }
