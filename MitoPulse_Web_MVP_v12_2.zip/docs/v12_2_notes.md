
# v12.2 notes

This version combines both requested directions:
1. real persistence
2. stronger mobile + graph UI

Recommended cloud stack:
- Render / Railway / Fly.io
- Neon / Supabase PostgreSQL
- Cloudflare for domain
