
# MitoPulse v12.2

Independent release focused on:
- real persistence with SQLAlchemy
- PostgreSQL-ready DATABASE_URL
- stronger interactive graph
- mobile companion UI with relay, quick evaluation and audit

For cloud deployment, set DATABASE_URL to a managed PostgreSQL instance.
