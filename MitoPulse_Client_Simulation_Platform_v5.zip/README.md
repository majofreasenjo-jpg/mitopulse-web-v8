# MitoPulse Client Simulation Platform v5

Versión institucional con:
- KPIs ejecutivos
- visualización de grafo
- múltiples corridas por cliente
- comparación antes vs después
- upload real de archivos
- SQLite por defecto / PostgreSQL opcional

## Ejecutar
```bash
cp .env.example .env
pip install -r requirements.txt
python run.py
```

Abrir:
`http://127.0.0.1:8000`

## PostgreSQL opcional
```bash
docker compose up -d
```
Luego ajusta `DATABASE_URL` en `.env`.
