import os
from datetime import datetime
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./mitopulse_v5.db")
engine = create_engine(DATABASE_URL, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
Base = declarative_base()

class UploadRun(Base):
    __tablename__ = "upload_runs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    client_type = Column(String, nullable=False)
    source_kind = Column(String, nullable=False)
    folder_path = Column(String, nullable=False)
    summary_json = Column(Text, default="{}")
    created_at = Column(DateTime, default=datetime.utcnow)

def init_db():
    Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
