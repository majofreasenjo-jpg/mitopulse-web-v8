# V5 Notes

Esta versión está pensada para demo institucional.

## Qué agrega
- dashboard con KPIs ejecutivos
- graph preview visual
- persistencia de corridas
- apertura de corridas históricas
- comparación antes vs después del piloto
- simulación con stress variable (`risk_multiplier`)
