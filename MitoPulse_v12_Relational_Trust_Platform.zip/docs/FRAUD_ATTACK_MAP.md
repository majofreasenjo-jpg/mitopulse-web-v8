GLOBAL SOCIAL FRAUD MAP

Common fraud attacks:

1 Social engineering
2 Fake supplier account change
3 Romance scam
4 Investment scam
5 SIM swap
6 Marketplace fake payment
7 Fake receipt
8 Crypto wallet drainer
9 Identity takeover
10 Mule networks

Industries affected:

Banking
Marketplaces
Telcos
Crypto
Payments
E‑commerce

Fraud lifecycle:

contact
trust building
request
transfer
laundering
