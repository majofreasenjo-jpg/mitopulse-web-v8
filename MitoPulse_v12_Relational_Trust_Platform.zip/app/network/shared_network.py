class SharedFraudNetwork:

    def __init__(self):
        self.signals=[]

    def share_signal(self,source,institution,risk):
        signal={
            "source":source,
            "institution":institution,
            "risk_score":risk
        }
        self.signals.append(signal)
        return signal

    def get_network_signals(self):
        return self.signals
