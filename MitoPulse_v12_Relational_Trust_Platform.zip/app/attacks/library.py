ATTACK_LIBRARY = {
 "social_engineering":"Manipulación psicológica para obtener transferencias",
 "mule_network":"Red de cuentas intermediarias",
 "fake_receipt":"Comprobante falso",
 "sim_swap":"Cambio fraudulento de SIM",
 "identity_takeover":"Toma de identidad digital",
 "supplier_change":"Cambio de cuenta proveedor",
 "marketplace_scam":"Fraude comprador-vendedor",
 "wallet_drainer":"Drenaje de wallet crypto",
 "romance_scam":"Estafa emocional prolongada",
 "investment_scam":"Inversión falsa"
}
