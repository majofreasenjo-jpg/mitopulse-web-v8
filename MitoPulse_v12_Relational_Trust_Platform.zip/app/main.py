from fastapi import FastAPI
from app.api.routes import router

app = FastAPI(title="MitoPulse v12 Relational Trust Platform")
app.include_router(router)
