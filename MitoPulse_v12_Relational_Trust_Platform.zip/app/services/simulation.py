import random
from app.attacks.library import ATTACK_LIBRARY

def simulate(client):

    nodes=3000
    fraud_ratio=0.04
    fraud_nodes=int(nodes*fraud_ratio)

    block=int(fraud_nodes*0.65)
    review=int(fraud_nodes*0.20)
    allow=nodes-block-review

    attack=random.choice(list(ATTACK_LIBRARY.keys()))

    return {
        "client":client,
        "attack":attack,
        "nodes":nodes,
        "fraud_nodes":fraud_nodes,
        "decision_projection":{
            "ALLOW":allow,
            "REVIEW":review,
            "BLOCK":block
        }
    }
