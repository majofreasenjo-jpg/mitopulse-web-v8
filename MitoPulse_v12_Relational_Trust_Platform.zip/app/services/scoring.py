def risk_score(interactions,anomalies,network_signal):

    score=0.2
    score+=interactions*0.05
    score+=anomalies*0.15
    score+=network_signal*0.25

    if score>1:
        score=1

    return score
