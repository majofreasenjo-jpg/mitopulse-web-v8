from fastapi import APIRouter
from app.services.simulation import simulate
from app.attacks.library import ATTACK_LIBRARY

router=APIRouter()

@router.get("/attacks")
def attacks():
    return ATTACK_LIBRARY

@router.get("/simulate/{client}")
def simulate_client(client:str):
    return simulate(client)
