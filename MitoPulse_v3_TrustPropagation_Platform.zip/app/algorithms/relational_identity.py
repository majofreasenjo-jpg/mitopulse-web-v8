
import networkx as nx

def relational_identity_score(graph: nx.Graph, node):
    if node not in graph:
        return 0.0
    degree = graph.degree(node)
    neighbors = list(graph.neighbors(node))
    diversity = len(set(neighbors))
    score = min(1.0, (degree * 0.1) + (diversity * 0.05))
    return round(score,3)
