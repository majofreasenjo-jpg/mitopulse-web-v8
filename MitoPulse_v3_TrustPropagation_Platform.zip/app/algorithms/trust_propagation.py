
import networkx as nx

def compute_trust(graph: nx.Graph, start_node: str, max_depth=3):
    scores = {}
    for node in graph.nodes():
        try:
            path = nx.shortest_path(graph, start_node, node)
        except:
            continue
        if len(path) - 1 > max_depth:
            continue

        trust = 1.0
        for i in range(len(path)-1):
            weight = graph[path[i]][path[i+1]].get("weight",1)
            trust *= weight
        scores[node] = trust
    return scores
