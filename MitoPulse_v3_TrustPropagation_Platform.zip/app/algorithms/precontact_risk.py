
def precontact_risk(node_exists, identity_score, trust_score):
    risk = 0.6
    if node_exists:
        risk -= identity_score * 0.4
        risk -= trust_score * 0.3
    return max(0.0, min(1.0, round(risk,3)))
