
from sqlalchemy import Column, String, Float, Integer
from app.core.database import Base

class Node(Base):
    __tablename__ = "nodes"
    node_id = Column(String, primary_key=True)
    trust_score = Column(Float, default=0.5)
    risk_score = Column(Float, default=0.0)

class Edge(Base):
    __tablename__ = "edges"
    id = Column(Integer, primary_key=True, autoincrement=True)
    source = Column(String)
    target = Column(String)
    weight = Column(Float, default=1.0)
