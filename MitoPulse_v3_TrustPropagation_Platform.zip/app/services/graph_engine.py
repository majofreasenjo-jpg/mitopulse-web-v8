
import networkx as nx

class GraphEngine:

    def __init__(self):
        self.G = nx.Graph()

    def add_interaction(self, a, b, weight=1.0):
        self.G.add_edge(a,b,weight=weight)

    def graph(self):
        return self.G
