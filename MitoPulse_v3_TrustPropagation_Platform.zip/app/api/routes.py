
from fastapi import APIRouter
from app.services.graph_engine import GraphEngine
from app.algorithms.trust_propagation import compute_trust
from app.algorithms.relational_identity import relational_identity_score
from app.algorithms.precontact_risk import precontact_risk

router = APIRouter()
engine = GraphEngine()

@router.post("/interaction")
def interaction(a:str,b:str):
    engine.add_interaction(a,b)
    return {"ok":True}

@router.get("/trust/{node}")
def trust(node:str):
    G = engine.graph()
    return compute_trust(G,node)

@router.get("/identity/{node}")
def identity(node:str):
    G = engine.graph()
    return {"score":relational_identity_score(G,node)}

@router.get("/precontact/{node}")
def risk(node:str):
    G = engine.graph()
    identity = relational_identity_score(G,node)
    trust = 0.5
    exists = node in G
    r = precontact_risk(exists,identity,trust)
    return {"risk_score":r}
