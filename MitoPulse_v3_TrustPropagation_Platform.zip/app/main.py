
from fastapi import FastAPI
from app.api.routes import router
from app.core.database import Base,engine

Base.metadata.create_all(bind=engine)

app = FastAPI(title="MitoPulse v3 Trust Propagation Engine")
app.include_router(router)
