
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Text
from sqlalchemy.orm import declarative_base, sessionmaker
from datetime import datetime, timedelta
import os, json, hashlib

app = FastAPI(title="MitoPulse Pre-Contact Risk Module v1")
templates = Jinja2Templates(directory="templates")

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./mitopulse_precontact_v1.db")
engine = create_engine(DATABASE_URL, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

def now_dt():
    return datetime.utcnow()

class Node(Base):
    __tablename__ = "nodes"
    node_id = Column(String, primary_key=True)
    label = Column(String, nullable=True)
    node_type = Column(String, default="internal")
    trust_rank = Column(Float, default=50.0)
    nodal_mass = Column(Float, default=20.0)
    status = Column(String, default="healthy")
    fraud_exposure = Column(Float, default=0.0)
    created_at = Column(DateTime, default=now_dt)

class Edge(Base):
    __tablename__ = "edges"
    id = Column(Integer, primary_key=True, autoincrement=True)
    source = Column(String, index=True)
    target = Column(String, index=True)
    weight = Column(Float, default=20.0)
    interaction_count = Column(Integer, default=1)
    last_seen = Column(DateTime, default=now_dt)

class ContactEvent(Base):
    __tablename__ = "contact_events"
    id = Column(Integer, primary_key=True, autoincrement=True)
    source_node_id = Column(String, index=True)
    target_node_id = Column(String, index=True)
    event_type = Column(String, default="contact_attempt")
    timestamp = Column(DateTime, default=now_dt)
    metadata_json = Column(Text, default="{}")

class PreContactAlert(Base):
    __tablename__ = "precontact_alerts"
    id = Column(Integer, primary_key=True, autoincrement=True)
    alert_id = Column(String, unique=True, index=True)
    source_node_id = Column(String, index=True)
    target_node_id = Column(String, index=True)
    risk_score = Column(Float)
    severity = Column(String)
    reasons_json = Column(Text)
    created_at = Column(DateTime, default=now_dt)

Base.metadata.create_all(bind=engine)

def get_node(db, node_id: str, node_type: str = "internal", label: str | None = None):
    node = db.query(Node).filter(Node.node_id == node_id).first()
    if not node:
        node = Node(node_id=node_id, node_type=node_type, label=label or node_id)
        db.add(node)
        db.commit()
        db.refresh(node)
    return node

def get_edge(db, a: str, b: str):
    return db.query(Edge).filter(((Edge.source == a) & (Edge.target == b)) | ((Edge.source == b) & (Edge.target == a))).first()

def seed():
    db = SessionLocal()
    try:
        if db.query(Node).count() > 0:
            return
        internals = [("pilot_A","Ana"),("pilot_B","Bruno"),("pilot_C","Carla"),("pilot_D","Diego")]
        for nid, label in internals:
            db.add(Node(node_id=nid, label=label, node_type="internal"))
        edges = [("pilot_A","pilot_B",70,5),("pilot_A","pilot_C",58,3),("pilot_B","pilot_C",62,4),("pilot_C","pilot_D",54,2)]
        for a,b,w,c in edges:
            db.add(Edge(source=a, target=b, weight=w, interaction_count=c))
        db.commit()
    finally:
        db.close()
seed()

def count_recent_targets(db, external_node_id: str, minutes: int = 60):
    cutoff = now_dt() - timedelta(minutes=minutes)
    rows = db.query(ContactEvent).filter(ContactEvent.source_node_id == external_node_id, ContactEvent.timestamp >= cutoff).all()
    return len(set(r.target_node_id for r in rows))

def count_recent_attempts(db, external_node_id: str, minutes: int = 60):
    cutoff = now_dt() - timedelta(minutes=minutes)
    return db.query(ContactEvent).filter(ContactEvent.source_node_id == external_node_id, ContactEvent.timestamp >= cutoff).count()

def target_has_history(db, source_node_id: str, target_node_id: str):
    return get_edge(db, source_node_id, target_node_id) is not None

def evaluate_precontact(db, source_node_id: str, target_node_id: str):
    source = get_node(db, source_node_id, node_type="external")
    target = get_node(db, target_node_id, node_type="internal")
    reasons = []
    score = 0.0
    if source.node_type == "external":
        score += 20
        reasons.append("source is external to the trusted pilot ring")
    recent_unique_targets = count_recent_targets(db, source_node_id, 60)
    if recent_unique_targets >= 2:
        bump = min(30, recent_unique_targets * 8)
        score += bump
        reasons.append(f"source contacted {recent_unique_targets} unique targets in the last 60 minutes")
    recent_attempts = count_recent_attempts(db, source_node_id, 60)
    if recent_attempts >= 3:
        bump = min(20, recent_attempts * 3)
        score += bump
        reasons.append(f"source attempted {recent_attempts} contacts in the last 60 minutes")
    if not target_has_history(db, source_node_id, target_node_id):
        score += 20
        reasons.append("no prior trusted edge exists between source and target")
    severity = "LOW"
    if score >= 70:
        severity = "HIGH"
    elif score >= 45:
        severity = "MEDIUM"
    score = round(min(100, score), 2)
    return {
        "source_node_id": source_node_id,
        "target_node_id": target_node_id,
        "risk_score": score,
        "severity": severity,
        "reasons": reasons,
        "recommended_action": "alert_and_review" if severity in ("MEDIUM","HIGH") else "monitor"
    }

class ContactAttemptIn(BaseModel):
    source_node_id: str
    target_node_id: str
    source_type: str = "external"
    event_type: str = "contact_attempt"
    metadata: dict = {}

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("home.html", {"request": request})

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.get("/manual", response_class=HTMLResponse)
def manual(request: Request):
    return templates.TemplateResponse("manual.html", {"request": request})

@app.post("/api/precontact/attempt")
def precontact_attempt(payload: ContactAttemptIn):
    db = SessionLocal()
    try:
        get_node(db, payload.source_node_id, node_type=payload.source_type, label=payload.source_node_id)
        get_node(db, payload.target_node_id, node_type="internal", label=payload.target_node_id)
        db.add(ContactEvent(source_node_id=payload.source_node_id, target_node_id=payload.target_node_id, event_type=payload.event_type, metadata_json=json.dumps(payload.metadata)))
        db.commit()
        result = evaluate_precontact(db, payload.source_node_id, payload.target_node_id)
        alert_id = "pc_" + hashlib.sha256(json.dumps(result, sort_keys=True).encode()).hexdigest()[:12]
        db.add(PreContactAlert(alert_id=alert_id, source_node_id=payload.source_node_id, target_node_id=payload.target_node_id, risk_score=result["risk_score"], severity=result["severity"], reasons_json=json.dumps(result["reasons"])))
        db.commit()
        result["alert_id"] = alert_id
        return result
    finally:
        db.close()

@app.get("/api/precontact/alerts")
def get_alerts():
    db = SessionLocal()
    try:
        rows = db.query(PreContactAlert).order_by(PreContactAlert.id.desc()).limit(100).all()
        return [{"alert_id": r.alert_id, "source_node_id": r.source_node_id, "target_node_id": r.target_node_id, "risk_score": r.risk_score, "severity": r.severity, "reasons": json.loads(r.reasons_json), "created_at": r.created_at.isoformat() if r.created_at else None} for r in rows]
    finally:
        db.close()

@app.get("/api/precontact/summary")
def summary():
    db = SessionLocal()
    try:
        return {"nodes": db.query(Node).count(), "internal_nodes": db.query(Node).filter(Node.node_type == "internal").count(), "external_nodes": db.query(Node).filter(Node.node_type == "external").count(), "contact_events": db.query(ContactEvent).count(), "alerts": db.query(PreContactAlert).count()}
    finally:
        db.close()

@app.get("/api/precontact/graph")
def graph():
    db = SessionLocal()
    try:
        nodes = db.query(Node).all()
        edges = db.query(Edge).all()
        return {"nodes": [{"node_id": n.node_id, "label": n.label, "node_type": n.node_type, "trust_rank": n.trust_rank, "nodal_mass": n.nodal_mass, "status": n.status, "fraud_exposure": n.fraud_exposure} for n in nodes], "edges": [{"source": e.source, "target": e.target, "weight": e.weight, "interaction_count": e.interaction_count} for e in edges]}
    finally:
        db.close()

@app.post("/api/precontact/demo/reset")
def reset_demo():
    db = SessionLocal()
    try:
        db.query(ContactEvent).delete()
        db.query(PreContactAlert).delete()
        db.query(Edge).delete()
        db.query(Node).delete()
        db.commit()
    finally:
        db.close()
    seed()
    return {"status": "reset_ok"}

@app.post("/api/precontact/demo/run")
def run_demo():
    scenarios = [
        {"source_node_id":"ext_scam_01","target_node_id":"pilot_B"},
        {"source_node_id":"ext_scam_01","target_node_id":"pilot_C"},
        {"source_node_id":"ext_scam_01","target_node_id":"pilot_A"},
    ]
    out = []
    for s in scenarios:
        out.append(precontact_attempt(ContactAttemptIn(**s)))
    return {"status": "demo_completed", "results": out}
