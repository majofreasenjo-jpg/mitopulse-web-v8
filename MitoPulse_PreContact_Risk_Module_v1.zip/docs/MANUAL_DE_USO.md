
# Manual de uso — MitoPulse Pre-Contact Risk Module v1

## 1. Qué es
Este módulo evalúa contactos externos antes de una interacción crítica y genera una alerta de riesgo anticipado.

## 2. Cómo ejecutarlo
### Local
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

Abrir:
- http://localhost:8000/
- http://localhost:8000/dashboard
- http://localhost:8000/manual

### Docker
```bash
docker build -t mitopulse-precontact .
docker run -p 10000:10000 mitopulse-precontact
```

## 3. Demo rápida
1. Abrir `/dashboard`
2. Presionar `Run demo`
3. Observar las alertas
4. Presionar `Reset demo` para reiniciar

## 4. Caso manual
Enviar un POST a `/api/precontact/attempt` con:

```json
{
  "source_node_id": "ext_scam_02",
  "target_node_id": "pilot_A",
  "source_type": "external",
  "event_type": "contact_attempt",
  "metadata": {
    "channel": "phone",
    "note": "unknown caller claims to be from the bank"
  }
}
```

## 5. Qué mide
- si la fuente es externa al trust ring
- cuántos nodos únicos intentó contactar recientemente
- cuántos intentos hizo en la última hora
- si ya existía o no una relación confiable con el objetivo

## 6. Interpretación del score
- LOW: monitorear
- MEDIUM: alertar y revisar
- HIGH: alertar y revisar con máxima prioridad
