
# MitoPulse Pre-Contact Risk Module v1

## Ejecución local
pip install -r requirements.txt
uvicorn main:app --reload

Abrir:
- /
- /dashboard
- /manual

## Endpoints
- POST /api/precontact/attempt
- GET /api/precontact/alerts
- GET /api/precontact/summary
- GET /api/precontact/graph
- POST /api/precontact/demo/run
- POST /api/precontact/demo/reset
