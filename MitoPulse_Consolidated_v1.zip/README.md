
MitoPulse Consolidated Demo

Incluye:
- piloto real 4 nodos
- simulación de ataques
- captura de interacciones
- motor trust/risk simple
- dashboard web

Ejecutar:

pip install fastapi uvicorn jinja2
uvicorn server:app --reload

Abrir:
http://127.0.0.1:8000
