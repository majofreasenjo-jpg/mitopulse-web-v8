
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from datetime import datetime
import random, uuid

app = FastAPI(title="MitoPulse Consolidated Demo")
templates = Jinja2Templates(directory="templates")

nodes={}
edges=[]
events=[]
alerts=[]

pilot=[
("nd_manuel_01","Manuel"),
("nd_natalie_01","Natalie"),
("nd_paulina_01","Paulina"),
("nd_ricardo_01","Ricardo")
]

class Interaction(BaseModel):
    source:str
    target:str
    type:str="message"

class Attack(BaseModel):
    attack_type:str="number_change"

def now():
    return datetime.utcnow().isoformat()+"Z"

@app.post("/api/bootstrap")
def bootstrap():
    nodes.clear(); edges.clear()
    for nid,label in pilot:
        nodes[nid]={"id":nid,"label":label,"trust":0.6,"risk":0.0}
    edges.extend([
        {"source":"nd_manuel_01","target":"nd_natalie_01"},
        {"source":"nd_manuel_01","target":"nd_ricardo_01"},
        {"source":"nd_natalie_01","target":"nd_paulina_01"}
    ])
    return {"nodes":nodes,"edges":edges}

@app.post("/api/interaction")
def interaction(p:Interaction):
    edges.append({"source":p.source,"target":p.target,"type":p.type})
    nodes[p.source]["trust"]=round(min(0.95,nodes[p.source]["trust"]+0.02),3)
    return {"ok":True}

@app.post("/api/attack")
def attack(p:Attack):
    tgt=random.choice(list(nodes.keys()))
    risk=round(random.uniform(0.7,0.95),3)
    nodes[tgt]["risk"]=risk
    decision="BLOCK" if risk>0.8 else "REVIEW"
    alerts.append({"target":tgt,"risk":risk,"decision":decision})
    return alerts[-1]

@app.get("/api/state")
def state():
    return {"nodes":nodes,"edges":edges,"alerts":alerts}

@app.get("/",response_class=HTMLResponse)
def home(request:Request):
    return templates.TemplateResponse("index.html",{"request":request})
