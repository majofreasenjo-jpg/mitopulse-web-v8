# MitoPulse v13.2 Pilot Behavior Memory

Versión con memoria de rutina, baseline y chequeo de anomalías por usuario piloto.

Local:

pip install -r requirements.txt
uvicorn main:app --reload
