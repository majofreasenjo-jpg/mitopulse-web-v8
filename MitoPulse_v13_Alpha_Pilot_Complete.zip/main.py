
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Text
from sqlalchemy.orm import declarative_base, sessionmaker
from datetime import datetime, timedelta
import os, json, hashlib, random

app = FastAPI(title="MitoPulse v13 Alpha Pilot")
templates = Jinja2Templates(directory="templates")

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./mitopulse_v13_alpha_pilot.db")
engine = create_engine(DATABASE_URL, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

def now_dt():
    return datetime.utcnow()

class Node(Base):
    __tablename__ = "nodes"
    node_id = Column(String, primary_key=True)
    label = Column(String, nullable=True)
    tenant = Column(String, default="demo")
    node_type = Column(String, default="internal")
    industry = Column(String, default="banking")
    trust_rank = Column(Float, default=50.0)
    nodal_mass = Column(Float, default=20.0)
    guardian_score = Column(Float, default=0.0)
    fraud_exposure = Column(Float, default=0.0)
    pulse_count = Column(Integer, default=0)
    cross_pulse_count = Column(Integer, default=0)
    status = Column(String, default="healthy")
    last_seen = Column(DateTime, nullable=True)

class Edge(Base):
    __tablename__ = "edges"
    id = Column(Integer, primary_key=True, autoincrement=True)
    source = Column(String, index=True)
    target = Column(String, index=True)
    tenant = Column(String, default="demo")
    weight = Column(Float, default=20.0)
    shared_reality = Column(Float, default=0.0)

class Evaluation(Base):
    __tablename__ = "evaluations"
    id = Column(Integer, primary_key=True, autoincrement=True)
    evaluation_id = Column(String, unique=True, index=True)
    source_node_id = Column(String)
    target_node_id = Column(String)
    tenant = Column(String)
    decision = Column(String)
    trust_score = Column(Float)
    breakdown_json = Column(Text)
    created_at = Column(DateTime, default=now_dt)

class RelaySession(Base):
    __tablename__ = "relay_sessions"
    code = Column(String, primary_key=True)
    initiator = Column(String)
    tenant = Column(String, default="pilot_alpha4")

class ContactEvent(Base):
    __tablename__ = "contact_events"
    id = Column(Integer, primary_key=True, autoincrement=True)
    source_node_id = Column(String, index=True)
    target_node_id = Column(String, index=True)
    tenant = Column(String, default="pilot_alpha4")
    event_type = Column(String, default="contact_attempt")
    metadata_json = Column(Text, default="{}")
    timestamp = Column(DateTime, default=now_dt)

class PreContactAlert(Base):
    __tablename__ = "precontact_alerts"
    id = Column(Integer, primary_key=True, autoincrement=True)
    alert_id = Column(String, unique=True, index=True)
    source_node_id = Column(String)
    target_node_id = Column(String)
    tenant = Column(String)
    risk_score = Column(Float)
    severity = Column(String)
    reasons_json = Column(Text)
    created_at = Column(DateTime, default=now_dt)

Base.metadata.create_all(bind=engine)

INDUSTRY_OVERLAYS = {
    "banking": {"amount_weight": 1.2, "routine_weight": 1.1, "fraud_weight": 1.2, "shared_reality_boost": 1.0},
    "marketplace": {"amount_weight": 0.8, "routine_weight": 0.7, "fraud_weight": 1.1, "shared_reality_boost": 1.2},
    "crypto": {"amount_weight": 1.0, "routine_weight": 0.9, "fraud_weight": 1.5, "shared_reality_boost": 0.8},
    "messaging": {"amount_weight": 0.7, "routine_weight": 1.3, "fraud_weight": 1.0, "shared_reality_boost": 1.1},
}

def get_node(db, node_id, tenant="demo", node_type="internal", label=None):
    n = db.query(Node).filter(Node.node_id == node_id).first()
    if not n:
        n = Node(node_id=node_id, tenant=tenant, node_type=node_type, label=label or node_id)
        db.add(n)
        db.commit()
        db.refresh(n)
    return n

def get_edge(db, a, b, tenant=None):
    q = db.query(Edge).filter(((Edge.source == a) & (Edge.target == b)) | ((Edge.source == b) & (Edge.target == a)))
    if tenant:
        q = q.filter(Edge.tenant == tenant)
    return q.first()

def neighbors(db, node_id, tenant=None):
    q = db.query(Edge).filter((Edge.source == node_id) | (Edge.target == node_id))
    if tenant:
        q = q.filter(Edge.tenant == tenant)
    return q.all()

def recompute_guardians(db, tenant):
    rows = db.query(Node).filter(Node.tenant == tenant).all()
    for n in rows:
        rels = neighbors(db, n.node_id, tenant)
        deg = len(rels)
        avgw = sum(r.weight for r in rels) / deg if deg else 0
        avgs = sum(r.shared_reality for r in rels) / deg if deg else 0
        score = 0.25 * min(100, deg * 15) + 0.25 * n.trust_rank + 0.15 * n.nodal_mass + 0.15 * min(100, n.pulse_count * 5) + 0.10 * avgs + 0.10 * avgw - 0.20 * n.fraud_exposure
        n.guardian_score = round(max(0, min(100, score)), 2)
    db.commit()

def recompute_spread(db, tenant):
    rows = db.query(Node).filter(Node.tenant == tenant).all()
    exposure = {n.node_id: max(0, n.fraud_exposure * 0.4) for n in rows}
    for _ in range(2):
        nxt = exposure.copy()
        for n in rows:
            spread = 0
            for r in neighbors(db, n.node_id, tenant):
                other = r.target if r.source == n.node_id else r.source
                spread += exposure.get(other, 0) * (r.weight / 100.0) * 0.18
            nxt[n.node_id] = min(100, max(nxt[n.node_id], round(spread, 2)))
        exposure = nxt
    for n in rows:
        n.fraud_exposure = exposure[n.node_id]
    db.commit()

def shared_reality(db, src, tgt, tenant):
    e = get_edge(db, src, tgt, tenant)
    if e:
        return min(100, 30 + e.shared_reality * 0.7 + e.weight * 0.2)
    s = get_node(db, src, tenant=tenant)
    t = get_node(db, tgt, tenant=tenant)
    return min(100, 20 + (15 if s.industry == t.industry else 0) + min(s.cross_pulse_count, t.cross_pulse_count))

def evaluate(db, src, tgt, tenant, industry, amount_anomaly, routine_break):
    target = get_node(db, tgt, tenant=tenant)
    edge = get_edge(db, src, tgt, tenant)
    overlay = INDUSTRY_OVERLAYS[industry]
    rds = edge.weight if edge else 10
    ass = int((target.trust_rank * 0.5) + (target.nodal_mass * 0.2) + (target.guardian_score * 0.3))
    srs = min(100, round(shared_reality(db, src, tgt, tenant) * overlay["shared_reality_boost"], 2))
    sc = max(0, int(100 - (((amount_anomaly * 100) * overlay["amount_weight"] + (routine_break * 100) * overlay["routine_weight"]) / 2)))
    fe = min(100, round(target.fraud_exposure * overlay["fraud_weight"], 2))
    score = round((rds + ass + srs + sc) / 4 - fe, 2)
    decision = "VERIFY" if score >= 80 else "REVIEW" if score >= 60 else "BLOCK"
    result = {
        "source_node_id": src, "target_node_id": tgt, "tenant": tenant, "industry": industry,
        "decision": decision, "trust_score": score,
        "breakdown": {"RDS": rds, "ASS": ass, "SRS": srs, "SC": sc, "FE": fe}
    }
    return result

def recent_stats(db, source_node_id, tenant, minutes=60):
    cutoff = now_dt() - timedelta(minutes=minutes)
    rows = db.query(ContactEvent).filter(ContactEvent.source_node_id == source_node_id, ContactEvent.tenant == tenant, ContactEvent.timestamp >= cutoff).all()
    return len(rows), len(set(r.target_node_id for r in rows))

def precontact_eval(db, source_node_id, target_node_id, tenant="pilot_alpha4"):
    get_node(db, source_node_id, tenant=tenant, node_type="external", label=source_node_id)
    get_node(db, target_node_id, tenant=tenant, node_type="mobile", label=target_node_id)
    attempts, uniq = recent_stats(db, source_node_id, tenant)
    score = 20
    reasons = ["source is external to the trusted pilot ring"]
    if uniq >= 2:
        score += min(30, uniq * 8)
        reasons.append(f"source contacted {uniq} unique targets in the last 60 minutes")
    if attempts >= 3:
        score += min(20, attempts * 3)
        reasons.append(f"source attempted {attempts} contacts in the last 60 minutes")
    if get_edge(db, source_node_id, target_node_id, tenant) is None:
        score += 20
        reasons.append("no prior trusted edge exists between source and target")
    severity = "LOW"
    if score >= 70:
        severity = "HIGH"
    elif score >= 45:
        severity = "MEDIUM"
    result = {
        "source_node_id": source_node_id, "target_node_id": target_node_id, "tenant": tenant,
        "risk_score": round(min(100, score), 2), "severity": severity,
        "reasons": reasons, "recommended_action": "alert_and_review" if severity in ("MEDIUM", "HIGH") else "monitor"
    }
    alert_id = "pc_" + hashlib.sha256(json.dumps(result, sort_keys=True).encode()).hexdigest()[:12]
    db.add(PreContactAlert(alert_id=alert_id, source_node_id=source_node_id, target_node_id=target_node_id, tenant=tenant, risk_score=result["risk_score"], severity=severity, reasons_json=json.dumps(reasons)))
    db.commit()
    result["alert_id"] = alert_id
    return result

def seed():
    db = SessionLocal()
    try:
        if db.query(Node).count():
            return
        for nid, label, tenant in [
            ("demo_1", "Demo A", "demo"), ("demo_2", "Demo B", "demo"), ("demo_3", "Demo C", "demo"), ("demo_4", "Demo D", "demo"),
            ("pilot_A", "Ana", "pilot_alpha4"), ("pilot_B", "Bruno", "pilot_alpha4"), ("pilot_C", "Carla", "pilot_alpha4"), ("pilot_D", "Diego", "pilot_alpha4")
        ]:
            db.add(Node(node_id=nid, label=label, tenant=tenant, node_type="mobile" if tenant == "pilot_alpha4" else "internal", trust_rank=random.randint(45, 80), nodal_mass=random.randint(15, 40), pulse_count=random.randint(0, 3), cross_pulse_count=random.randint(0, 2)))
        for a, b, tenant, w, sr in [
            ("demo_1", "demo_2", "demo", 70, 62), ("demo_2", "demo_3", "demo", 58, 48), ("demo_3", "demo_4", "demo", 46, 30),
            ("pilot_A", "pilot_B", "pilot_alpha4", 68, 60), ("pilot_A", "pilot_C", "pilot_alpha4", 56, 44), ("pilot_B", "pilot_C", "pilot_alpha4", 61, 49), ("pilot_C", "pilot_D", "pilot_alpha4", 52, 41)
        ]:
            db.add(Edge(source=a, target=b, tenant=tenant, weight=w, shared_reality=sr))
        db.commit()
        recompute_guardians(db, "demo")
        recompute_guardians(db, "pilot_alpha4")
        recompute_spread(db, "demo")
        recompute_spread(db, "pilot_alpha4")
    finally:
        db.close()

seed()

class EvalIn(BaseModel):
    source_node_id: str
    target_node_id: str
    tenant: str = "demo"
    industry: str = "banking"
    amount_anomaly: float = 0.9
    routine_break: float = 0.8

class PulseIn(BaseModel):
    node_id: str
    tenant: str = "pilot_alpha4"

class RelayCreateIn(BaseModel):
    node_id: str
    tenant: str = "pilot_alpha4"

class RelayConfirmIn(BaseModel):
    node_id: str
    code: str
    tenant: str = "pilot_alpha4"
    shared_reality_boost: float = 8.0

class PreIn(BaseModel):
    source_node_id: str
    target_node_id: str
    tenant: str = "pilot_alpha4"
    source_type: str = "external"
    event_type: str = "contact_attempt"
    metadata: dict = {}

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("home.html", {"request": request})

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.get("/graph", response_class=HTMLResponse)
def graph_page(request: Request):
    return templates.TemplateResponse("graph.html", {"request": request})

@app.get("/demo", response_class=HTMLResponse)
def demo(request: Request):
    return templates.TemplateResponse("demo.html", {"request": request})

@app.get("/pilot", response_class=HTMLResponse)
def pilot(request: Request):
    return templates.TemplateResponse("pilot.html", {"request": request})

@app.get("/pilot/dashboard", response_class=HTMLResponse)
def pilot_dashboard(request: Request):
    return templates.TemplateResponse("pilot_dashboard.html", {"request": request})

@app.get("/partner", response_class=HTMLResponse)
def partner(request: Request):
    return templates.TemplateResponse("partner.html", {"request": request})

@app.get("/sdk", response_class=HTMLResponse)
def sdk(request: Request):
    return templates.TemplateResponse("sdk.html", {"request": request})

@app.get("/deploy", response_class=HTMLResponse)
def deploy(request: Request):
    return templates.TemplateResponse("deploy.html", {"request": request})

@app.get("/mobile", response_class=HTMLResponse)
def mobile(request: Request):
    return templates.TemplateResponse("mobile_home.html", {"request": request})

@app.get("/mobile/relay", response_class=HTMLResponse)
def mobile_relay(request: Request):
    return templates.TemplateResponse("mobile_relay.html", {"request": request})

@app.get("/mobile/eval", response_class=HTMLResponse)
def mobile_eval(request: Request):
    return templates.TemplateResponse("mobile_eval.html", {"request": request})

@app.get("/mobile/audit", response_class=HTMLResponse)
def mobile_audit(request: Request):
    return templates.TemplateResponse("mobile_audit.html", {"request": request})

@app.get("/api/summary")
def api_summary(tenant: str = "demo"):
    db = SessionLocal()
    try:
        return {
            "tenant": tenant,
            "nodes": db.query(Node).filter(Node.tenant == tenant).count(),
            "evaluations": db.query(Evaluation).filter(Evaluation.tenant == tenant).count(),
            "alerts": db.query(PreContactAlert).filter(PreContactAlert.tenant == tenant).count()
        }
    finally:
        db.close()

@app.get("/api/graph")
def api_graph(tenant: str = "demo"):
    db = SessionLocal()
    try:
        return {
            "nodes": [{"node_id": n.node_id, "label": n.label, "tenant": n.tenant, "node_type": n.node_type, "industry": n.industry, "trust_rank": n.trust_rank, "nodal_mass": n.nodal_mass, "guardian_score": n.guardian_score, "fraud_exposure": n.fraud_exposure, "pulse_count": n.pulse_count, "cross_pulse_count": n.cross_pulse_count, "status": n.status} for n in db.query(Node).filter(Node.tenant == tenant).all()],
            "edges": [{"source": e.source, "target": e.target, "weight": e.weight, "shared_reality": e.shared_reality, "tenant": e.tenant} for e in db.query(Edge).filter(Edge.tenant == tenant).all()]
        }
    finally:
        db.close()

@app.get("/api/node/{node_id}")
def api_node(node_id: str):
    db = SessionLocal()
    try:
        n = get_node(db, node_id)
        return {"node_id": n.node_id, "label": n.label, "tenant": n.tenant, "node_type": n.node_type, "industry": n.industry, "trust_rank": n.trust_rank, "nodal_mass": n.nodal_mass, "guardian_score": n.guardian_score, "fraud_exposure": n.fraud_exposure, "pulse_count": n.pulse_count, "cross_pulse_count": n.cross_pulse_count, "status": n.status}
    finally:
        db.close()

@app.post("/api/pulse")
def api_pulse(payload: PulseIn):
    db = SessionLocal()
    try:
        n = get_node(db, payload.node_id, tenant=payload.tenant, node_type="mobile", label=payload.node_id)
        n.pulse_count += 1
        n.nodal_mass = min(100, n.nodal_mass + 1)
        n.last_seen = now_dt()
        db.commit()
        return {"node_id": n.node_id, "pulse_count": n.pulse_count, "nodal_mass": n.nodal_mass}
    finally:
        db.close()

@app.post("/api/evaluate")
def api_evaluate(payload: EvalIn):
    db = SessionLocal()
    try:
        result = evaluate(db, payload.source_node_id, payload.target_node_id, payload.tenant, payload.industry, payload.amount_anomaly, payload.routine_break)
        eid = f"ev_{db.query(Evaluation).count()+1}"
        db.add(Evaluation(evaluation_id=eid, source_node_id=payload.source_node_id, target_node_id=payload.target_node_id, tenant=payload.tenant, decision=result["decision"], trust_score=result["trust_score"], breakdown_json=json.dumps(result)))
        db.commit()
        result["evaluation_id"] = eid
        return result
    finally:
        db.close()

@app.get("/api/evaluation/{evaluation_id}")
def api_evaluation(evaluation_id: str):
    db = SessionLocal()
    try:
        ev = db.query(Evaluation).filter(Evaluation.evaluation_id == evaluation_id).first()
        if not ev:
            return {"error": "not_found"}
        data = json.loads(ev.breakdown_json)
        data["evaluation_id"] = ev.evaluation_id
        return data
    finally:
        db.close()

@app.post("/api/relay/create")
def api_relay_create(payload: RelayCreateIn):
    db = SessionLocal()
    try:
        get_node(db, payload.node_id, tenant=payload.tenant, node_type="mobile", label=payload.node_id)
        code = str(random.randint(1000, 9999))
        db.merge(RelaySession(code=code, initiator=payload.node_id, tenant=payload.tenant))
        db.commit()
        return {"code": code, "initiator": payload.node_id}
    finally:
        db.close()

@app.post("/api/relay/confirm")
def api_relay_confirm(payload: RelayConfirmIn):
    db = SessionLocal()
    try:
        sess = db.query(RelaySession).filter(RelaySession.code == payload.code, RelaySession.tenant == payload.tenant).first()
        if not sess:
            return {"error": "invalid_code"}
        a, b = sess.initiator, payload.node_id
        edge = get_edge(db, a, b, payload.tenant)
        before = edge.weight if edge else 0
        if not edge:
            edge = Edge(source=a, target=b, tenant=payload.tenant, weight=25, shared_reality=20)
            db.add(edge)
        edge.weight = min(100, edge.weight + 8)
        edge.shared_reality = min(100, edge.shared_reality + payload.shared_reality_boost)
        get_node(db, a, tenant=payload.tenant).cross_pulse_count += 1
        get_node(db, b, tenant=payload.tenant).cross_pulse_count += 1
        db.commit()
        return {"status": "confirmed", "node_a": a, "node_b": b, "relationship_weight_before": before, "relationship_weight_after": edge.weight, "shared_reality_after": edge.shared_reality}
    finally:
        db.close()

@app.post("/api/workers/run")
def api_workers_run(tenant: str = "demo"):
    db = SessionLocal()
    try:
        recompute_guardians(db, tenant)
        recompute_spread(db, tenant)
        return {"status": "ok", "tenant": tenant}
    finally:
        db.close()

@app.get("/api/demo-cases")
def api_demo_cases():
    return {
        "whatsapp_fake_relative": {"source_node_id": "demo_1", "target_node_id": "demo_4", "tenant": "demo", "industry": "banking", "amount_anomaly": 0.9, "routine_break": 0.8},
        "legit_qr_payment": {"source_node_id": "demo_2", "target_node_id": "demo_3", "tenant": "demo", "industry": "marketplace", "amount_anomaly": 0.1, "routine_break": 0.1}
    }

@app.post("/api/demo/run/{case_name}")
def api_demo_run(case_name: str):
    cases = api_demo_cases()
    if case_name not in cases:
        return {"error": "unknown_case"}
    return api_evaluate(EvalIn(**cases[case_name]))

@app.post("/api/pilot/precontact/attempt")
def api_precontact_attempt(payload: PreIn):
    db = SessionLocal()
    try:
        get_node(db, payload.source_node_id, tenant=payload.tenant, node_type=payload.source_type, label=payload.source_node_id)
        get_node(db, payload.target_node_id, tenant=payload.tenant, node_type="mobile", label=payload.target_node_id)
        db.add(ContactEvent(source_node_id=payload.source_node_id, target_node_id=payload.target_node_id, tenant=payload.tenant, event_type=payload.event_type, metadata_json=json.dumps(payload.metadata)))
        db.commit()
        return precontact_eval(db, payload.source_node_id, payload.target_node_id, payload.tenant)
    finally:
        db.close()

@app.get("/api/pilot/precontact/alerts")
def api_pilot_alerts(tenant: str = "pilot_alpha4"):
    db = SessionLocal()
    try:
        rows = db.query(PreContactAlert).filter(PreContactAlert.tenant == tenant).order_by(PreContactAlert.id.desc()).all()
        return [{"alert_id": r.alert_id, "source_node_id": r.source_node_id, "target_node_id": r.target_node_id, "risk_score": r.risk_score, "severity": r.severity, "reasons": json.loads(r.reasons_json), "created_at": r.created_at.isoformat()} for r in rows]
    finally:
        db.close()

@app.get("/api/pilot/precontact/summary")
def api_pilot_summary(tenant: str = "pilot_alpha4"):
    db = SessionLocal()
    try:
        return {
            "tenant": tenant,
            "nodes": db.query(Node).filter(Node.tenant == tenant).count(),
            "internal_nodes": db.query(Node).filter(Node.tenant == tenant, Node.node_type != "external").count(),
            "external_nodes": db.query(Node).filter(Node.tenant == tenant, Node.node_type == "external").count(),
            "contact_events": db.query(ContactEvent).filter(ContactEvent.tenant == tenant).count(),
            "alerts": db.query(PreContactAlert).filter(PreContactAlert.tenant == tenant).count()
        }
    finally:
        db.close()

@app.post("/api/pilot/reset")
def api_pilot_reset(tenant: str = "pilot_alpha4"):
    db = SessionLocal()
    try:
        db.query(ContactEvent).filter(ContactEvent.tenant == tenant).delete()
        db.query(PreContactAlert).filter(PreContactAlert.tenant == tenant).delete()
        db.commit()
        return {"status": "reset_ok"}
    finally:
        db.close()

@app.post("/api/pilot/demo/run")
def api_pilot_demo_run():
    out = []
    for item in [
        {"source_node_id": "ext_scam_01", "target_node_id": "pilot_B", "tenant": "pilot_alpha4"},
        {"source_node_id": "ext_scam_01", "target_node_id": "pilot_C", "tenant": "pilot_alpha4"},
        {"source_node_id": "ext_scam_01", "target_node_id": "pilot_A", "tenant": "pilot_alpha4"}
    ]:
        out.append(api_precontact_attempt(PreIn(**item)))
    return {"status": "demo_completed", "results": out}

@app.get("/api/platform-profile")
def api_platform_profile():
    return {
        "version": "v13_alpha_pilot",
        "real_time_plane": ["evaluate", "relay", "node", "precontact fast check"],
        "async_plane": ["workers/run"],
        "pilot_tenant": "pilot_alpha4"
    }
