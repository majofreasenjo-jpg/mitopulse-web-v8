# MitoPulse v13 Alpha Pilot

Ejecutable con core, demo, mobile, pilot ring y pre-contact risk.

Local:

pip install -r requirements.txt
uvicorn main:app --reload
