Ver /dashboard, /graph, /pilot/dashboard y /mobile. Para contacto externo usa POST /api/pilot/precontact/attempt con source_node_id externo y target_node_id pilot_A/B/C/D.
