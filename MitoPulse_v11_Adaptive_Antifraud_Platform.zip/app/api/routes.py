from fastapi import APIRouter
from app.services.simulation import run_simulation
from app.attacks.library import ATTACK_LIBRARY

router = APIRouter()

@router.get("/attacks")
def attacks():
    return ATTACK_LIBRARY

@router.get("/simulate/{client}")
def simulate(client:str):
    return run_simulation(client)
