def realtime_score(interactions, anomalies):
    base=0.2
    risk=base+(anomalies*0.15)+(interactions*0.05)
    return min(risk,1.0)
