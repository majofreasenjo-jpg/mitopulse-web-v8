import random
from app.attacks.library import ATTACK_LIBRARY

def run_simulation(client):
    attack=random.choice(list(ATTACK_LIBRARY.keys()))
    nodes=2000
    fraud=int(nodes*0.04)
    block=int(fraud*0.6)
    review=int(fraud*0.25)
    allow=nodes-block-review

    return {
        "client":client,
        "attack":attack,
        "nodes":nodes,
        "fraud_nodes":fraud,
        "decision_projection":{
            "ALLOW":allow,
            "REVIEW":review,
            "BLOCK":block
        }
    }
