ATTACK_LIBRARY = {
 "social_engineering":"Fraude por manipulación psicológica",
 "mule_accounts":"Red de cuentas mule",
 "fake_receipt":"Comprobante falso",
 "sim_swap":"Cambio fraudulento de SIM",
 "identity_takeover":"Toma de identidad",
 "wallet_drainer":"Drenaje de wallet crypto",
 "supplier_change":"Cambio de cuenta proveedor",
 "marketplace_scam":"Fraude comprador-vendedor"
}
