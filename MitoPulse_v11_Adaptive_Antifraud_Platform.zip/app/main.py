from fastapi import FastAPI
from app.api.routes import router

app = FastAPI(title="MitoPulse v11 Adaptive Antifraud Platform")
app.include_router(router)
