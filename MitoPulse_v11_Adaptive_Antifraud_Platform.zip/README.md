MitoPulse v11 Adaptive Antifraud Platform

Run:

pip install -r requirements.txt
python run.py

Open:
http://127.0.0.1:8000

Endpoints:

/attacks
/simulate/{client}

Modules included:

attack_library
trust_graph
realtime_scoring
mobile_sdk_stub
