
# MitoPulse v11.2

This version is independent from prior releases and is oriented to **cloud-only deployment**.

## Recommended deployment
- Render / Railway / Fly.io
- Managed PostgreSQL (Neon / Supabase)
- Cloudflare for domain and DNS

## Local run (optional only)
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

## Docker
```bash
docker build -t mitopulse-v11-2 .
docker run -p 10000:10000 -e APP_MODE=cloud mitopulse-v11-2
```
