
# Cloud-only strategy

Goal:
- host the product fully in the web
- avoid using a PC as a permanent server

Recommended:
- Render / Railway / Fly.io for app
- Neon / Supabase for PostgreSQL
- Cloudflare for domain and DNS
