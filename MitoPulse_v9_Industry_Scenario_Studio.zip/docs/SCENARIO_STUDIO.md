# Scenario Studio

Esta versión está pensada para venta consultiva.

Cada cliente puede ver:
- su industria
- su patrón de ataque
- su tamaño de red
- su combinación de módulos MitoPulse
- su proyección de decisiones ALLOW / REVIEW / BLOCK
