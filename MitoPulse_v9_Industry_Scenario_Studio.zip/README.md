# MitoPulse v9 Industry Scenario Studio

Estudio completo de escenarios por industria y cliente.

## Permite
- construir escenarios por cliente
- elegir industria
- elegir ataque
- activar shared reality
- activar mobile verify
- ajustar trusted hubs
- usar narrativa comercial por cliente

## Ejecutar
```bash
pip install -r requirements.txt
python run.py
```

Abrir:
`http://127.0.0.1:8000`
