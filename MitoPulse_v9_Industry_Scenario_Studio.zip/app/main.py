from fastapi import FastAPI
from app.core.database import Base, engine
from app.api.routes import router

Base.metadata.create_all(bind=engine)
app = FastAPI(title="MitoPulse v9 Industry Scenario Studio")
app.include_router(router)
