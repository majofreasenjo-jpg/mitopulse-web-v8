from pydantic import BaseModel, Field

class StudioRequest(BaseModel):
    customer_name: str = "Banco Demo"
    industry: str = "retail_bank"
    attack_pattern: str = "social_fraud"
    nodes: int = Field(default=1500, ge=100, le=20000)
    fraud_ratio: float = Field(default=0.04, ge=0.0, le=0.25)
    trusted_hubs: int = Field(default=5, ge=0, le=100)
    cross_channel: bool = True
    shared_reality: bool = True
    mobile_verify: bool = True
