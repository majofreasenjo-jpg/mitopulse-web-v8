import json
from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.schema import StudioRun
from app.api.schemas import StudioRequest
from app.services.studio_engine import INDUSTRY_PACKS, create_studio_output

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/api/industries")
def industries():
    return INDUSTRY_PACKS

@router.post("/api/studio/run")
def run_studio(payload: StudioRequest, db: Session = Depends(get_db)):
    output = create_studio_output(
        payload.customer_name,
        payload.industry,
        payload.attack_pattern,
        payload.nodes,
        payload.fraud_ratio,
        payload.trusted_hubs,
        payload.cross_channel,
        payload.shared_reality,
        payload.mobile_verify,
    )
    row = StudioRun(
        customer_name=payload.customer_name,
        industry=payload.industry,
        configuration_json=json.dumps(payload.model_dump()),
        output_json=json.dumps(output),
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return {"run_id": row.id, "result": output}

@router.get("/api/studio/runs")
def runs(db: Session = Depends(get_db)):
    rows = db.query(StudioRun).order_by(StudioRun.id.desc()).limit(20).all()
    return [{
        "id": r.id,
        "customer_name": r.customer_name,
        "industry": r.industry,
        "created_at": r.created_at.isoformat() + "Z"
    } for r in rows]

@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
