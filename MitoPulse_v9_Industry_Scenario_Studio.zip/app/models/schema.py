from sqlalchemy import Column, Integer, String, Text, DateTime
from datetime import datetime
from app.core.database import Base

def now():
    return datetime.utcnow()

class StudioRun(Base):
    __tablename__ = "studio_runs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    customer_name = Column(String, nullable=False)
    industry = Column(String, nullable=False)
    configuration_json = Column(Text, default="{}")
    output_json = Column(Text, default="{}")
    created_at = Column(DateTime, default=now)
