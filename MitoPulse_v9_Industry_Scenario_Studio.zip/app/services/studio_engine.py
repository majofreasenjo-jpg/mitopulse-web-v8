INDUSTRY_PACKS = {
    "retail_bank": {
        "attacks": ["social_fraud", "mule_cluster", "new_beneficiary_push"],
        "channels": ["bank_app", "messaging", "phone"],
        "kpis": ["fraud_prevented", "review_rate", "false_positive_target"],
    },
    "marketplace_p2p": {
        "attacks": ["fake_receipt", "seller_cluster", "link_phishing"],
        "channels": ["marketplace_chat", "bank_app", "messaging"],
        "kpis": ["seller_risk_precision", "fraud_ring_detection", "time_to_alert"],
    },
    "crypto_exchange": {
        "attacks": ["wallet_drainer", "bridge_outflow", "signature_request"],
        "channels": ["wallet", "browser", "messaging"],
        "kpis": ["withdrawal_block_rate", "cluster_detection", "wallet_risk_precision"],
    },
    "telco_identity": {
        "attacks": ["sim_swap", "new_channel_anchor", "number_change"],
        "channels": ["telco_app", "sms", "bank_app"],
        "kpis": ["identity_anchor_quality", "channel_change_risk", "fraud_before_transfer"],
    },
}

def create_studio_output(customer_name: str, industry: str, attack_pattern: str, nodes: int, fraud_ratio: float, trusted_hubs: int, cross_channel: bool, shared_reality: bool, mobile_verify: bool):
    pack = INDUSTRY_PACKS[industry]
    fraud_nodes = int(nodes * fraud_ratio)
    block = int(fraud_nodes * (0.62 if shared_reality else 0.48))
    review = int(fraud_nodes * (0.24 if mobile_verify else 0.18))
    allow = max(0, nodes - block - review)
    narrative = f"{customer_name}: escenario {industry}/{attack_pattern} con {nodes} nodos y {fraud_nodes} nodos de riesgo."
    return {
        "customer_name": customer_name,
        "industry": industry,
        "attack_pattern": attack_pattern,
        "nodes": nodes,
        "fraud_nodes": fraud_nodes,
        "trusted_hubs": trusted_hubs,
        "cross_channel": cross_channel,
        "shared_reality": shared_reality,
        "mobile_verify": mobile_verify,
        "channels": pack["channels"],
        "kpis": pack["kpis"],
        "decision_projection": {"ALLOW": allow, "REVIEW": review, "BLOCK": block},
        "narrative": narrative,
        "recommended_pitch": f"Para {customer_name}, MitoPulse reduce fraude {attack_pattern} usando pre-contact risk, relational identity y shared reality."
    }
