# MitoPulse v7 Hardening Edition

Versión endurecida para mostrar a bancos con una base más seria.

## Incluye
- todo lo de v6
- rate limiting básico por Redis
- JWT demo para tenants
- helpers de HMAC por tenant
- logging central
- métricas internas
- audit log
- tests base
- health endpoint

## Ejecución local
```bash
cp .env.example .env
pip install -r requirements.txt
python run.py
```

## Ejecución con Docker
```bash
cp .env.example .env
docker compose up --build
```

## Demo
Tenant:
`bank_demo`

API key:
`demo-bank-key`

Abrir:
`http://127.0.0.1:8000`
