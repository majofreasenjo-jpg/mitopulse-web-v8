# Notas v7

Esta versión sigue siendo una base de desarrollo. No es un entorno certificado ni auditoría final.
Se endureció la arquitectura para conversaciones serias con bancos.

## Qué cambió respecto a v6
- rate limiting
- JWT demo
- HMAC helpers
- logging
- métricas
- audit log
- tests base
