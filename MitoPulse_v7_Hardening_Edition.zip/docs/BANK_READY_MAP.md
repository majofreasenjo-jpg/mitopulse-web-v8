# Mapa bank-ready de MitoPulse

## Hardening agregado
- tenant isolation
- API keys
- JWT demo
- HMAC helpers
- rate limit
- audit log
- health checks
- metrics

## Mensaje a banco
1. no veamos personas; veamos geometría relacional
2. valor individual desde el día 1 con su propio grafo
3. Shared Reality después para consorcio
4. mobile verify para app bancaria

## Próximos pasos
- observabilidad Prometheus/OpenTelemetry
- migrations Alembic
- secret manager
- WAF/API gateway
- RBAC institucional
- SDKs Android/iOS reales
