from collections import defaultdict
from threading import Lock

class MetricsRegistry:
    def __init__(self):
        self.lock = Lock()
        self.counters = defaultdict(int)

    def inc(self, key: str, value: int = 1):
        with self.lock:
            self.counters[key] += value

    def dump(self) -> dict:
        with self.lock:
            return dict(self.counters)

metrics = MetricsRegistry()
