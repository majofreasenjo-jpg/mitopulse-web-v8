from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field
import json

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    app_name: str = Field(default="MitoPulse v7 Hardening Edition", alias="APP_NAME")
    database_url: str = Field(default="sqlite:///./mitopulse_v7.db", alias="DATABASE_URL")
    redis_url: str = Field(default="redis://localhost:6379/0", alias="REDIS_URL")
    default_tenant: str = Field(default="bank_demo", alias="DEFAULT_TENANT")
    api_keys_json: str = Field(default='{"bank_demo":"demo-bank-key"}', alias="API_KEYS_JSON")
    tenant_hmac_secrets_json: str = Field(default='{"bank_demo":"demo-bank-secret"}', alias="TENANT_HMAC_SECRETS_JSON")
    jwt_secret: str = Field(default="mitopulse-jwt-demo-secret", alias="JWT_SECRET")
    rate_limit_requests: int = Field(default=120, alias="RATE_LIMIT_REQUESTS")
    rate_limit_window_seconds: int = Field(default=60, alias="RATE_LIMIT_WINDOW_SECONDS")

    @property
    def api_keys(self) -> dict[str, str]:
        try:
            return json.loads(self.api_keys_json)
        except Exception:
            return {"bank_demo": "demo-bank-key"}

    @property
    def tenant_hmac_secrets(self) -> dict[str, str]:
        try:
            return json.loads(self.tenant_hmac_secrets_json)
        except Exception:
            return {"bank_demo": "demo-bank-secret"}

settings = Settings()
