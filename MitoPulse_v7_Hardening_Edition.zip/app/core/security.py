import hmac, hashlib, json, time
import jwt
from fastapi import Header, HTTPException, Request
from app.core.config import settings

def verify_api_key(x_api_key: str | None = Header(default=None), x_tenant_id: str | None = Header(default=None)) -> str:
    if not x_tenant_id:
        raise HTTPException(status_code=400, detail="Missing X-Tenant-ID header")
    expected = settings.api_keys.get(x_tenant_id)
    if not expected or x_api_key != expected:
        raise HTTPException(status_code=401, detail="Invalid API key or tenant")
    return x_tenant_id

def create_tenant_jwt(tenant_id: str) -> str:
    payload = {"tenant_id": tenant_id, "iat": int(time.time())}
    return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")

def verify_tenant_jwt(token: str) -> dict:
    return jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])

def sign_payload(tenant_id: str, payload: dict) -> str:
    secret = settings.tenant_hmac_secrets.get(tenant_id)
    if not secret:
        raise ValueError("Missing HMAC secret for tenant")
    body = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()

def verify_hmac_signature(tenant_id: str, payload: dict, signature: str) -> bool:
    expected = sign_payload(tenant_id, payload)
    return hmac.compare_digest(expected, signature)

async def verify_signed_request(request: Request, x_tenant_signature: str | None = Header(default=None)):
    if not x_tenant_signature:
        raise HTTPException(status_code=400, detail="Missing X-Tenant-Signature header")
    tenant_id = request.headers.get("X-Tenant-ID")
    if not tenant_id:
        raise HTTPException(status_code=400, detail="Missing X-Tenant-ID header")
    payload = await request.json()
    if not verify_hmac_signature(tenant_id, payload, x_tenant_signature):
        raise HTTPException(status_code=401, detail="Invalid HMAC signature")
    return tenant_id
