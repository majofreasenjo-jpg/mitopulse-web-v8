import time
from fastapi import Request, HTTPException
from app.core.cache import get_redis
from app.core.config import settings

async def rate_limit(request: Request):
    tenant = request.headers.get("X-Tenant-ID", "unknown")
    client = request.client.host if request.client else "unknown"
    key = f"ratelimit:{tenant}:{client}"
    r = get_redis()
    now = int(time.time())
    pipe = r.pipeline()
    pipe.incr(key, 1)
    pipe.expire(key, settings.rate_limit_window_seconds)
    count, _ = pipe.execute()
    if int(count) > settings.rate_limit_requests:
        raise HTTPException(status_code=429, detail="Rate limit exceeded")
