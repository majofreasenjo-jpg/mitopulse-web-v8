from app.services.mobile_sdk import MitoPulseMobileSDK

sdk = MitoPulseMobileSDK(
    base_url="http://127.0.0.1:8000",
    tenant_id="bank_demo",
    api_key="demo-bank-key"
)

# Example:
# result = sdk.verify_contact("user_natalie", "ext_attacker_01", "financial_request")
# print(result)
