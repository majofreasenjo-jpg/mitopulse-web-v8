from sqlalchemy.orm import Session
from app.models.schema import Node, Edge
from app.services.graph_ops import build_graph, trust_propagation, relational_identity, cluster_risk, precontact_risk
from app.services.platform import find_shared_signals

def load_graph(db: Session, tenant_id: str):
    nodes = db.query(Node).filter(Node.tenant_id == tenant_id).all()
    edges = db.query(Edge).filter(Edge.tenant_id == tenant_id).all()
    node_list = [{"id": n.node_id, "label": n.label, "trust_score": n.trust_score, "risk_score": n.risk_score, "identity_confidence": n.identity_confidence, "is_guardian": n.is_guardian} for n in nodes]
    edge_list = [{"source": e.source, "target": e.target, "weight": e.weight, "interaction_type": e.interaction_type, "context": e.context, "channel": e.channel} for e in edges]
    return build_graph(node_list, edge_list)

def run_trust_propagation(db: Session, tenant_id: str, node_id: str):
    return trust_propagation(load_graph(db, tenant_id), node_id)

def run_relational_identity(db: Session, tenant_id: str, node_id: str):
    return relational_identity(load_graph(db, tenant_id), node_id)

def run_cluster_risk(db: Session, tenant_id: str, node_id: str):
    return {"node_id": node_id, "cluster_risk": cluster_risk(load_graph(db, tenant_id), node_id)}

def run_precontact(db: Session, tenant_id: str, source: str, target: str, context: str):
    g = load_graph(db, tenant_id)
    if target not in g:
        return {"source": source, "target": target, "risk_score": 0.93, "signal": "unknown_target", "guardian_decision": "REVIEW", "propagated_trust": 0.0, "cluster_risk": 0.95}
    propagated = trust_propagation(g, source).get(target, 0.0) if source in g else 0.0
    ident = relational_identity(g, target)
    own_risk = g.nodes[target].get("risk_score", 0.0)
    crisk = cluster_risk(g, target)
    shared_signals = find_shared_signals(db, target)
    shared_boost = max([s["severity"] for s in shared_signals], default=0.0)
    risk = precontact_risk(True, ident["score"], propagated, max(own_risk, crisk, shared_boost), context)
    decision = "BLOCK" if risk >= 0.82 else "REVIEW" if risk >= 0.48 else "ALLOW"
    signal = "shared_reality_alert" if shared_boost >= 0.65 else "fraud_cluster" if crisk >= 0.55 else "weak_relational_history" if ident["score"] < 0.45 else "stable_relational_presence"
    return {"source": source, "target": target, "risk_score": risk, "signal": signal, "guardian_decision": decision, "propagated_trust": propagated, "identity_score": ident["score"], "cluster_risk": crisk, "shared_signal_severity": shared_boost}
