import networkx as nx

def build_graph(nodes, edges):
    g = nx.Graph()
    for n in nodes:
        g.add_node(
            n["id"],
            trust_score=n["trust_score"],
            risk_score=n["risk_score"],
            identity_confidence=n["identity_confidence"],
            is_guardian=n["is_guardian"],
            label=n["label"]
        )
    for e in edges:
        g.add_edge(
            e["source"],
            e["target"],
            weight=e["weight"],
            interaction_type=e["interaction_type"],
            context=e["context"],
            channel=e.get("channel", "app")
        )
    return g

def trust_propagation(graph: nx.Graph, start_node: str, max_depth: int = 3):
    if start_node not in graph:
        return {}
    scores = {}
    for node in graph.nodes():
        try:
            path = nx.shortest_path(graph, start_node, node)
        except Exception:
            continue
        depth = len(path) - 1
        if depth > max_depth:
            continue
        trust = 1.0
        for i in range(len(path)-1):
            edge_data = graph[path[i]][path[i+1]]
            trust *= edge_data.get("weight", 1.0)
            trust *= 0.88
        scores[node] = round(max(0.0, min(1.0, trust)), 3)
    return scores

def relational_identity(graph: nx.Graph, node: str):
    if node not in graph:
        return {"score": 0.0, "confidence": "low", "signals": ["unknown_identity"]}
    degree = graph.degree(node)
    neighbors = list(graph.neighbors(node))
    types, contexts, channels = set(), set(), set()
    for n in neighbors:
        d = graph[node][n]
        types.add(d.get("interaction_type", "unknown"))
        contexts.add(d.get("context", "general"))
        channels.add(d.get("channel", "app"))
    score = 0.22 + min(0.30, degree * 0.06) + min(0.16, len(types) * 0.05) + min(0.16, len(contexts) * 0.05) + min(0.10, len(channels) * 0.03)
    if graph.nodes[node].get("is_guardian"):
        score += 0.08
    score = round(max(0.01, min(0.99, score)), 3)
    confidence = "high" if score >= 0.78 else "medium" if score >= 0.48 else "low"
    signals = []
    if degree >= 3: signals.append("multi_edge_history")
    if len(types) >= 2: signals.append("channel_diversity")
    if len(contexts) >= 2: signals.append("context_diversity")
    if graph.nodes[node].get("is_guardian"): signals.append("guardian_anchor")
    if not signals: signals.append("weak_relational_history")
    return {"score": score, "confidence": confidence, "signals": signals}

def cluster_risk(graph: nx.Graph, node: str):
    if node not in graph:
        return 0.95
    neighbors = list(graph.neighbors(node))
    degree = len(neighbors)
    suspicious, weak = 0, 0
    for n in neighbors:
        if graph.nodes[n].get("risk_score", 0) >= 0.35:
            suspicious += 1
        if graph.degree(n) <= 2:
            weak += 1
    risk = 0.18 + min(0.24, suspicious * 0.08) + min(0.16, weak * 0.05)
    if degree <= 1:
        risk += 0.18
    return round(max(0.01, min(0.99, risk)), 3)

def precontact_risk(node_exists: bool, identity_score: float, propagated_trust: float, own_risk: float, context: str):
    risk = 0.68
    if node_exists:
        risk -= identity_score * 0.30
        risk -= propagated_trust * 0.26
        risk += own_risk * 0.34
    if context in ("financial_request", "urgent_transfer", "signature_request"):
        risk += 0.10
    return round(max(0.01, min(0.99, risk)), 3)
