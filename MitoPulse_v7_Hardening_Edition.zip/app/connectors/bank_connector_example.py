import hashlib, requests, json
from app.core.security import sign_payload

def stable_hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:24]

def evaluate_transfer(base_url: str, tenant: str, api_key: str, source_account: str, target_account: str, secret_signer=None):
    payload = {"source": stable_hash(source_account), "target": stable_hash(target_account), "context": "financial_request"}
    headers = {"Content-Type": "application/json", "X-Tenant-ID": tenant, "X-API-Key": api_key}
    if secret_signer:
        headers["X-Tenant-Signature"] = secret_signer(payload)
    r = requests.post(f"{base_url}/api/precontact", headers=headers, json=payload, timeout=10)
    r.raise_for_status()
    return r.json()
