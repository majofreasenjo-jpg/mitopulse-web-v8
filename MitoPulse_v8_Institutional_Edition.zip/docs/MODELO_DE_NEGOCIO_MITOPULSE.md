# Modelo de negocio de MitoPulse

## 1. Posicionamiento
MitoPulse puede operar en dos capas al mismo tiempo:

### Capa A — Producto antifraude institucional
Clientes:
- bancos
- fintech
- marketplaces
- telcos
- wallets

Producto:
- Pre-Contact Risk API
- Relational Identity API
- Fraud Spread / Cluster Risk
- Institutional Dashboard

### Capa B — Protocolo de confianza digital
Red compartida entre instituciones para publicar y consultar señales relacionales codificadas.

---

## 2. Modelo de ingresos recomendado

### A. Licencia base institucional
Rango sugerido:
- fintech pequeña: USD 25k – 80k/año
- marketplace mediano: USD 60k – 150k/año
- banco mediano: USD 150k – 500k/año
- banco grande / telco grande: USD 500k – 2M/año

### B. Consumo por evaluación
Rango sugerido:
- USD 0.001 – 0.02 por consulta
Ideal para:
- transferencias
- validaciones rápidas
- mobile verify
- consultas pre-contacto

### C. Consorcio / Shared Reality
Membresía adicional por participar en la red interinstitucional.
Rango sugerido:
- USD 100k – 1M/año según tamaño y volumen

### D. SDK móvil y verificaciones premium
Licencias B2B2C para apps que quieran mostrar:
- contacto verificado
- solicitud de riesgo
- link de riesgo
- verificación de nuevo canal

---

## 3. Secuencia comercial recomendada

### Etapa 1
Fintech / marketplace / wallet
Objetivo:
- validar producto
- conseguir datos
- demostrar reducción de fraude

### Etapa 2
Telco
Objetivo:
- reforzar continuidad de canales
- casos de SIM swap / cambio de número

### Etapa 3
Primer banco
Objetivo:
- vender Fraud Social Detection Layer
- demostrar valor con su propio grafo interno

### Etapa 4
Consorcio
Objetivo:
- Shared Reality Layer
- ventaja estructural y efecto red

---

## 4. Qué compra realmente el cliente

El cliente no compra "IA".
Compra:
- reducción de fraude social
- menos pérdidas por cuentas mule
- mejor scoring de destino
- mejor priorización operativa
- señales antes de la transacción

---

## 5. Métricas comerciales clave

- fraude detectado o evitado
- falsos positivos
- reducción de pérdidas
- consultas por mes
- tenants activos
- señales compartidas entre instituciones

---

## 6. Narrativa de alto valor

Cloudflare protege servidores.
MitoPulse protege relaciones humanas digitales.

Stripe mueve pagos.
MitoPulse valida legitimidad relacional antes del pago.

SWIFT mueve mensajes financieros.
MitoPulse mueve señales de confianza digital.
