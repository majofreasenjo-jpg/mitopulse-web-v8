# V8 Overview

## Qué agrega v8
- Alembic base
- Prometheus metrics
- Grafana dashboard base
- Android SDK base
- iOS SDK base
- business model document
- conectores y despliegue más institucionales

## Importante
Esta sigue siendo una base de desarrollo seria, no un sistema certificado listo para producción regulada.
Aún faltan:
- OpenTelemetry completo
- RBAC real
- secret manager
- WAF / API gateway
- políticas de compliance / auditoría externa
