from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_metrics():
    r = client.get("/metrics")
    assert r.status_code == 200
