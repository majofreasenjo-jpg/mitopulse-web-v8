# MitoPulse v8 Institutional Edition

Base completa de desarrollo para llevar MitoPulse a una presentación seria ante bancos, fintech y marketplaces.

## Incluye
- PostgreSQL
- Redis
- multi-tenant
- API keys
- JWT demo
- HMAC helpers
- rate limiting
- audit log
- Prometheus
- Grafana dashboard base
- Alembic base
- SDK Android base
- SDK iOS base
- conector bancario de ejemplo
- Shared Reality Protocol
- Pre-Contact Risk
- Relational Identity
- Trust Propagation
- Cluster Risk
- Institutional dashboard

## Local
```bash
cp .env.example .env
pip install -r requirements.txt
python run.py
```

## Docker
```bash
cp .env.example .env
docker compose up --build
```

## Endpoints útiles
- `/healthz`
- `/metrics`
- `/api/precontact`
- `/api/identity`
- `/api/protocol/publish-signal`
- `/api/mobile/verify`
