import time
from app.core.database import SessionLocal
from app.models.schema import Node
from app.services.platform import recompute_scores

def main():
    print("MitoPulse v8 deep graph worker started")
    while True:
        db = SessionLocal()
        try:
            tenants = [row[0] for row in db.query(Node.tenant_id).distinct().all()]
            for tenant_id in tenants:
                recompute_scores(db, tenant_id)
        except Exception as exc:
            print("worker error:", exc)
        finally:
            db.close()
        time.sleep(15)

if __name__ == "__main__":
    main()
