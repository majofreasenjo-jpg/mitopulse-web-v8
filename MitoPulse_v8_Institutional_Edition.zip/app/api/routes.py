from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session
from fastapi.templating import Jinja2Templates

from app.core.database import get_db
from app.core.security import verify_api_key, create_tenant_jwt
from app.core.rate_limit import rate_limit
from app.core.metrics import REQUEST_COUNTER, TENANT_GAUGE, RISK_GAUGE, prometheus_payload
from app.api.schemas import BootstrapIn, InteractionIn, CrossPulseIn, AttackIn, PreContactIn, IdentityIn, SeedSimulationIn, SharedSignalIn, MobileVerifyIn
from app.services.platform import bootstrap_pilot, capture_interaction, create_crosspulse, simulate_attack, get_state, PILOT_USERS, seed_simulation, publish_shared_signal, find_shared_signals
from app.services.analysis import run_trust_propagation, run_relational_identity, run_precontact, run_cluster_risk

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/metrics")
def metrics_endpoint():
    payload, ctype = prometheus_payload()
    return Response(content=payload, media_type=ctype)

@router.get("/api/auth/token")
def get_demo_token(tenant_id: str = Depends(verify_api_key)):
    REQUEST_COUNTER.labels(endpoint="auth_token").inc()
    return {"token": create_tenant_jwt(tenant_id)}

@router.post("/api/bootstrap", dependencies=[Depends(rate_limit)])
def bootstrap(payload: BootstrapIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    REQUEST_COUNTER.labels(endpoint="bootstrap").inc(); TENANT_GAUGE.set(len({tenant_id}))
    bootstrap_pilot(db, tenant_id, payload.cluster)
    return {"ok": True, "tenant_id": tenant_id}

@router.post("/api/interaction", dependencies=[Depends(rate_limit)])
def interaction(payload: InteractionIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    REQUEST_COUNTER.labels(endpoint="interaction").inc()
    capture_interaction(db, tenant_id, payload.source, payload.target, payload.interaction_type, payload.context, payload.weight, payload.channel)
    return {"ok": True, "tenant_id": tenant_id}

@router.post("/api/crosspulse", dependencies=[Depends(rate_limit)])
def crosspulse(payload: CrossPulseIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    REQUEST_COUNTER.labels(endpoint="crosspulse").inc()
    pulse_id = create_crosspulse(db, tenant_id, payload.source, payload.target, payload.reason)
    return {"ok": True, "pulse_id": pulse_id}

@router.post("/api/attack", dependencies=[Depends(rate_limit)])
def attack(payload: AttackIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    REQUEST_COUNTER.labels(endpoint="attack").inc()
    return {"ok": True, "alerts": simulate_attack(db, tenant_id, payload.attack_type)}

@router.post("/api/precontact", dependencies=[Depends(rate_limit)])
def precontact(payload: PreContactIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    REQUEST_COUNTER.labels(endpoint="precontact").inc()
    result = run_precontact(db, tenant_id, payload.source, payload.target, payload.context)
    RISK_GAUGE.labels(tenant=tenant_id).set(result["risk_score"])
    return result

@router.post("/api/identity", dependencies=[Depends(rate_limit)])
def identity(payload: IdentityIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    REQUEST_COUNTER.labels(endpoint="identity").inc()
    return run_relational_identity(db, tenant_id, payload.node_id)

@router.get("/api/trust/{node_id}", dependencies=[Depends(rate_limit)])
def trust(node_id: str, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    REQUEST_COUNTER.labels(endpoint="trust").inc()
    return run_trust_propagation(db, tenant_id, node_id)

@router.get("/api/cluster-risk/{node_id}", dependencies=[Depends(rate_limit)])
def cluster(node_id: str, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    REQUEST_COUNTER.labels(endpoint="cluster").inc()
    return run_cluster_risk(db, tenant_id, node_id)

@router.post("/api/simulation/seed", dependencies=[Depends(rate_limit)])
def simulation_seed(payload: SeedSimulationIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    REQUEST_COUNTER.labels(endpoint="simulation_seed").inc()
    seed_simulation(db, tenant_id, payload.nodes, payload.fraud_ratio)
    return {"ok": True, "tenant_id": tenant_id, "nodes": payload.nodes, "fraud_ratio": payload.fraud_ratio}

@router.post("/api/protocol/publish-signal", dependencies=[Depends(rate_limit)])
def publish_signal(payload: SharedSignalIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    REQUEST_COUNTER.labels(endpoint="publish_signal").inc()
    row = publish_shared_signal(db, tenant_id, payload.shared_hash, payload.signal_type, payload.severity, payload.payload)
    return {"ok": True, "signal_id": row.id}

@router.get("/api/protocol/signals/{shared_hash}", dependencies=[Depends(rate_limit)])
def get_signals(shared_hash: str, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    REQUEST_COUNTER.labels(endpoint="query_signals").inc()
    return {"ok": True, "shared_hash": shared_hash, "signals": find_shared_signals(db, shared_hash)}

@router.post("/api/mobile/verify", dependencies=[Depends(rate_limit)])
def mobile_verify(payload: MobileVerifyIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    REQUEST_COUNTER.labels(endpoint="mobile_verify").inc()
    result = run_precontact(db, tenant_id, payload.source, payload.target, payload.context)
    RISK_GAUGE.labels(tenant=tenant_id).set(result["risk_score"])
    return result

@router.get("/api/state", dependencies=[Depends(rate_limit)])
def state(tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    REQUEST_COUNTER.labels(endpoint="state").inc()
    return get_state(db, tenant_id)

@router.get("/api/pilot/users")
def users():
    return [{"node_id": nid, "display_name": label, "guardian": guardian} for nid, label, guardian in PILOT_USERS]

@router.get("/healthz")
def healthz():
    return {"ok": True}

@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
