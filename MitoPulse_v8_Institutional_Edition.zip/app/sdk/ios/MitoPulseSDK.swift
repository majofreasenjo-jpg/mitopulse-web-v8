import Foundation

public final class MitoPulseSDK {
    let baseURL: String
    let tenantId: String
    let apiKey: String

    public init(baseURL: String, tenantId: String, apiKey: String) {
        self.baseURL = baseURL
        self.tenantId = tenantId
        self.apiKey = apiKey
    }

    public func verifyContact(source: String, target: String, context: String = "financial_request", completion: @escaping (Data?, URLResponse?, Error?) -> Void) {
        let url = URL(string: "\(baseURL)/api/mobile/verify")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(tenantId, forHTTPHeaderField: "X-Tenant-ID")
        request.setValue(apiKey, forHTTPHeaderField: "X-API-Key")
        let payload = ["source": source, "target": target, "context": context, "device_hash": "ios-demo"]
        request.httpBody = try? JSONSerialization.data(withJSONObject: payload)
        URLSession.shared.dataTask(with: request, completionHandler: completion).resume()
    }
}
