package com.mitopulse.sdk

import java.net.HttpURLConnection
import java.net.URL

class MitoPulseSdk(private val baseUrl: String, private val tenantId: String, private val apiKey: String) {
    fun verifyContact(source: String, target: String, context: String = "financial_request"): String {
        val url = URL("$baseUrl/api/mobile/verify")
        val body = "{"source":"$source","target":"$target","context":"$context","device_hash":"android-demo"}"
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("X-Tenant-ID", tenantId)
        conn.setRequestProperty("X-API-Key", apiKey)
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toByteArray()) }
        return conn.inputStream.bufferedReader().readText()
    }
}
