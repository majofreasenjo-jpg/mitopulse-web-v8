import hmac, hashlib, json, time, jwt
from fastapi import Header, HTTPException
from app.core.config import settings

def verify_api_key(x_api_key: str | None = Header(default=None), x_tenant_id: str | None = Header(default=None)) -> str:
    if not x_tenant_id:
        raise HTTPException(status_code=400, detail="Missing X-Tenant-ID header")
    expected = settings.api_keys.get(x_tenant_id)
    if not expected or x_api_key != expected:
        raise HTTPException(status_code=401, detail="Invalid API key or tenant")
    return x_tenant_id

def create_tenant_jwt(tenant_id: str) -> str:
    return jwt.encode({"tenant_id": tenant_id, "iat": int(time.time())}, settings.jwt_secret, algorithm="HS256")

def sign_payload(tenant_id: str, payload: dict) -> str:
    secret = settings.tenant_hmac_secrets.get(tenant_id)
    if not secret:
        raise ValueError("Missing HMAC secret for tenant")
    body = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
