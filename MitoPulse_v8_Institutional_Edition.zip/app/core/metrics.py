from prometheus_client import Counter, Gauge, generate_latest, CONTENT_TYPE_LATEST

REQUEST_COUNTER = Counter("mitopulse_requests_total", "Total API requests", ["endpoint"])
TENANT_GAUGE = Gauge("mitopulse_active_tenants", "Tenants seen by system")
RISK_GAUGE = Gauge("mitopulse_last_risk_score", "Last computed risk score", ["tenant"])

def prometheus_payload():
    return generate_latest(), CONTENT_TYPE_LATEST
