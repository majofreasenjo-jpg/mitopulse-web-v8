import requests

class MitoPulseMobileSDK:
    def __init__(self, base_url: str, tenant_id: str, api_key: str):
        self.base_url = base_url.rstrip("/")
        self.headers = {"Content-Type": "application/json", "X-Tenant-ID": tenant_id, "X-API-Key": api_key}

    def verify_contact(self, source: str, target: str, context: str = "financial_request") -> dict:
        r = requests.post(f"{self.base_url}/api/mobile/verify", headers=self.headers, json={"source": source, "target": target, "context": context, "device_hash": "sdk-device"}, timeout=10)
        r.raise_for_status()
        return r.json()
