from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
import os, time, sqlite3
from pydantic import BaseModel

API_KEY = os.getenv("MITOPULSE_API_KEY", "")
ALLOWED_SKEW = int(os.getenv("MITOPULSE_ALLOWED_SKEW_SECONDS", "86400"))
DB_PATH = os.getenv("MITOPULSE_DB_PATH", "/data/mitopulse.db")

app = FastAPI(title="MitoPulse Pilot API", version="0.1.0")

def db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.execute("CREATE TABLE IF NOT EXISTS identity_events ("
                 "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                 "user_id TEXT NOT NULL,"
                 "device_id TEXT NOT NULL,"
                 "ts INTEGER NOT NULL,"
                 "tier TEXT NOT NULL,"
                 "index_value REAL NOT NULL,"
                 "slope REAL NOT NULL,"
                 "dynamic_id TEXT NOT NULL,"
                 "risk_score INTEGER NOT NULL,"
                 "coercion INTEGER NOT NULL,"
                 "request_id TEXT NOT NULL UNIQUE,"
                 "created_at INTEGER NOT NULL"
                 ");")
    conn.execute("CREATE TABLE IF NOT EXISTS audit_logs ("
                 "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                 "ts INTEGER NOT NULL,"
                 "action TEXT NOT NULL,"
                 "user_id TEXT,"
                 "device_id TEXT,"
                 "request_id TEXT,"
                 "ok INTEGER NOT NULL,"
                 "reason TEXT"
                 ");")
    conn.commit()
    conn.close()

init_db()

def require_key(x_api_key: str | None):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="invalid_api_key")

def audit(action: str, ok: bool, reason: str="", user_id=None, device_id=None, request_id=None):
    conn = db()
    conn.execute(
        "INSERT INTO audit_logs(ts, action, user_id, device_id, request_id, ok, reason) VALUES (?,?,?,?,?,?,?)",
        (int(time.time()), action, user_id, device_id, request_id, 1 if ok else 0, reason),
    )
    conn.commit()
    conn.close()

class IdentityEvent(BaseModel):
    user_id: str
    device_id: str
    ts: int
    tier: str
    index_value: float
    slope: float
    dynamic_id: str
    risk_score: int = 0
    coercion: bool = False
    request_id: str

class VerifyRequest(BaseModel):
    user_id: str
    device_id: str
    ts: int
    dynamic_id: str
    request_id: str

@app.post("/v1/identity-events")
def post_identity_event(payload: IdentityEvent, x_api_key: str | None = Header(default=None, alias="X-API-Key")):
    require_key(x_api_key)
    now = int(time.time())
    if abs(payload.ts - now) > ALLOWED_SKEW:
        audit("identity_event", False, "timestamp_skew", payload.user_id, payload.device_id, payload.request_id)
        raise HTTPException(status_code=400, detail="timestamp_skew")

    conn = db()
    try:
        conn.execute(
            "INSERT INTO identity_events(user_id, device_id, ts, tier, index_value, slope, dynamic_id, risk_score, coercion, request_id, created_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (payload.user_id, payload.device_id, payload.ts, payload.tier, payload.index_value, payload.slope, payload.dynamic_id,
             int(payload.risk_score), 1 if payload.coercion else 0, payload.request_id, now),
        )
        conn.commit()
    except sqlite3.IntegrityError:
        audit("identity_event", False, "replay_request_id", payload.user_id, payload.device_id, payload.request_id)
        raise HTTPException(status_code=409, detail="replay_request_id")
    finally:
        conn.close()

    audit("identity_event", True, "ok", payload.user_id, payload.device_id, payload.request_id)
    return {"ok": True}

@app.post("/v1/verify")
def verify(payload: VerifyRequest, x_api_key: str | None = Header(default=None, alias="X-API-Key")):
    require_key(x_api_key)
    conn = db()
    row = conn.execute(
        "SELECT dynamic_id FROM identity_events WHERE user_id=? AND device_id=? ORDER BY ts DESC LIMIT 1",
        (payload.user_id, payload.device_id),
    ).fetchone()
    conn.close()

    if not row:
        audit("verify", False, "no_events", payload.user_id, payload.device_id, payload.request_id)
        return {"verified": False, "reason": "no_events"}

    if row["dynamic_id"] != payload.dynamic_id:
        audit("verify", False, "mismatch", payload.user_id, payload.device_id, payload.request_id)
        return {"verified": False, "reason": "mismatch"}

    audit("verify", True, "ok", payload.user_id, payload.device_id, payload.request_id)
    return {"verified": True, "reason": "ok"}

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard():
    conn = db()
    events = conn.execute(
        "SELECT user_id, device_id, ts, tier, index_value, slope, risk_score, coercion, dynamic_id FROM identity_events "
        "ORDER BY ts DESC LIMIT 200"
    ).fetchall()
    audits = conn.execute(
        "SELECT ts, action, user_id, device_id, request_id, ok, reason FROM audit_logs ORDER BY ts DESC LIMIT 200"
    ).fetchall()
    conn.close()

    def tr_event(r):
        status = "COERCION" if r["coercion"] else "OK"
        return f"<tr><td>{r['ts']}</td><td>{r['user_id']}</td><td>{r['device_id']}</td><td>{r['tier']}</td><td>{r['index_value']:.3f}</td><td>{r['slope']:.3f}</td><td>{r['risk_score']}</td><td>{status}</td><td><code>{r['dynamic_id'][:18]}...</code></td></tr>"

    def tr_audit(r):
        ok = "OK" if r["ok"] else "FAIL"
        rid = (r["request_id"] or "")[:12]
        return f"<tr><td>{r['ts']}</td><td>{r['action']}</td><td>{r['user_id'] or ''}</td><td>{r['device_id'] or ''}</td><td><code>{rid}</code></td><td>{ok}</td><td>{r['reason']}</td></tr>"

    html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'/>"            "<style>body{font-family:system-ui;margin:20px}table{border-collapse:collapse;width:100%}"            "td,th{border:1px solid #ddd;padding:6px;font-size:12px}th{background:#f4f4f4}</style></head><body>"            "<h2>MitoPulse Dashboard</h2><p><a href='/docs'>/docs</a> · <a href='/app'>/app</a></p>"            "<h3>Eventos</h3><table><tr><th>ts</th><th>user</th><th>device</th><th>tier</th><th>index</th><th>slope</th><th>risk</th><th>status</th><th>dyn</th></tr>"            + "".join(tr_event(r) for r in events) + "</table>"            "<h3>Audit</h3><table><tr><th>ts</th><th>action</th><th>user</th><th>device</th><th>req</th><th>ok</th><th>reason</th></tr>"            + "".join(tr_audit(r) for r in audits) + "</table></body></html>"
    return HTMLResponse(html)

app.mount("/app", StaticFiles(directory="/pwa", html=True), name="pwa")
