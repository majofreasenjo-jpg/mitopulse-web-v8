# Deploy rápido (VPS + HTTPS)
1) Edita `Caddyfile` y cambia `api.tudominio.com` por tu dominio.
2) `docker compose up -d --build`
3) Abre:
- https://api.tudominio.com/docs
- https://api.tudominio.com/dashboard
- https://api.tudominio.com/app
