window.API_BASE_URL = window.location.origin;
window.MITOPULSE_API_KEY = '';
