function rid(){return Math.random().toString(16).slice(2,14);}
function headers(){const h={'Content-Type':'application/json'}; if(window.MITOPULSE_API_KEY) h['X-API-Key']=window.MITOPULSE_API_KEY; return h;}
const out=(x)=>document.getElementById('out').textContent=typeof x==='string'?x:JSON.stringify(x,null,2);
document.getElementById('b').textContent = window.API_BASE_URL;
let last=null;

document.getElementById('send').onclick = async ()=>{
  const ts = Math.floor(Date.now()/1000);
  const payload = {user_id:'manuel',device_id:'shared-demo',ts,tier:'tier2',index_value:0.62,slope:0.0,dynamic_id:btoa(String(ts)).slice(0,16),risk_score:0,coercion:false,request_id:rid()};
  last = payload.dynamic_id;
  const r = await fetch(window.API_BASE_URL+'/v1/identity-events',{method:'POST',headers:headers(),body:JSON.stringify(payload)});
  out({http:r.status, body: await r.json().catch(()=>({}))});
};

document.getElementById('verify').onclick = async ()=>{
  if(!last) return out('Primero Send DEMO Event');
  const ts = Math.floor(Date.now()/1000);
  const payload = {user_id:'manuel',device_id:'shared-demo',ts,dynamic_id:last,request_id:rid()};
  const r = await fetch(window.API_BASE_URL+'/v1/verify',{method:'POST',headers:headers(),body:JSON.stringify(payload)});
  out({http:r.status, body: await r.json().catch(()=>({}))});
};
