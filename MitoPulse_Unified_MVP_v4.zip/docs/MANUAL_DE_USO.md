
# Manual de uso — MitoPulse Unified MVP v4

## Objetivo
Concentrar en una sola app ejecutable la arquitectura productiva de MitoPulse, manteniendo la capa piloto de 4 nodos.

## Flujo rápido
1. Abrir `/pilot/onboarding`.
2. Vincular un dispositivo con uno de los códigos:
   - ALPHA-MANUEL
   - ALPHA-ANA
   - ALPHA-BRUNO
   - ALPHA-CARLA
3. Abrir `/mobile`.
4. Emitir pulse.
5. Registrar interacciones reales por tipo:
   - message
   - call
   - financial
   - in_person
   - marketplace
6. Revisar `/pilot/dashboard`.
7. Ejecutar `/attack-theater`.

## Módulos clave
### Fast Legitimacy Engine
Evalúa legitimidad inicial.

### Relational Anchor Engine
Evalúa continuidad relacional sin depender de identidad fija.

### Fraud Spread + Trust Waves
Propagación de riesgo y confianza en la red.

### Guardian Layer
Guardianes institucionales para revisión o bloqueo.

## Casos de demo
- cambio de número
- fraude marketplace
- solicitud financiera urgente
