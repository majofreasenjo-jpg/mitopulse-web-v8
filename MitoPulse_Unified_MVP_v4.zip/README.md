
# MitoPulse Unified MVP v4

Versión unificada ejecutable.

## Incluye
- Fast Legitimacy Engine
- Relational Anchor Engine
- Deep Analysis workers
- Fraud Spread + Trust Waves
- Guardian Layer
- Attack Theater
- Pilot Ring de 4 nodos
- Mobile y onboarding

## Ejecutar
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

## Rutas
- /
- /pilot/dashboard
- /attack-theater
- /pilot/onboarding
- /mobile
