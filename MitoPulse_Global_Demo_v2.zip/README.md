
# MitoPulse Global Demo v2

Demo visual para mostrar MitoPulse como infraestructura de confianza.

## Ejecutar

pip install fastapi uvicorn jinja2

uvicorn main:app --reload

Abrir:

http://127.0.0.1:8000

## Incluye

- Trust Graph demo
- Attack simulator
- Guardian decision engine demo

Diseñado para presentaciones a:
- bancos
- telcos
- marketplaces
- inversionistas
