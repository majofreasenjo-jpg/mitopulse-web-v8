
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import random

app = FastAPI(title="MitoPulse Global Demo v2")
templates = Jinja2Templates(directory="templates")

demo_nodes = [
    {"id":"Manuel","cluster":"family"},
    {"id":"Ana","cluster":"family"},
    {"id":"Bruno","cluster":"market"},
    {"id":"Carla","cluster":"market"},
]

attacks = [
    {"id":"bank_fraud","name":"Fraude bancario"},
    {"id":"wallet_phishing","name":"Phishing wallet"},
    {"id":"marketplace_scam","name":"Estafa marketplace"},
    {"id":"number_change","name":"Cambio de número telco"}
]

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request":request})

@app.get("/api/nodes")
def nodes():
    return demo_nodes

@app.get("/api/attacks")
def get_attacks():
    return attacks

@app.post("/api/run_attack/{attack_id}")
def run_attack(attack_id:str):
    legitimacy = round(random.uniform(0.2,0.9),3)
    risk = round(1-legitimacy,3)
    decision = "BLOCK" if risk>0.65 else "REVIEW" if risk>0.4 else "ALLOW"
    return {
        "attack":attack_id,
        "legitimacy_score":legitimacy,
        "risk_score":risk,
        "guardian_decision":decision
    }
