
MitoPulse v6 – Industry Simulation

Large‑scale simulation layer for demonstrating:

- Fraud campaigns
- Network trust propagation
- Cluster analysis
- Guardian response across multiple sectors
