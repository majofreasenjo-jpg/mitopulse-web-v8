
MitoPulse v5 – Industry Demo Layer

Adds industry‑specific overlays:

1. Banking fraud scenario
2. Marketplace fraud scenario
3. Crypto wallet phishing scenario

Each demo shows:
interaction → evaluation → guardian decision.
