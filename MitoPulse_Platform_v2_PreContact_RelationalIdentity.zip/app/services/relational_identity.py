
from sqlalchemy.orm import Session
from app.models.schema import Node, Edge

def relational_identity(db: Session, node_id: str):
    node = db.get(Node, node_id)
    if not node:
        return {
            "node_id": node_id,
            "exists": False,
            "relational_strength": 0.05,
            "identity_confidence": "low",
            "signals": ["unknown_identity"]
        }

    edges = db.query(Edge).filter((Edge.source == node_id) | (Edge.target == node_id)).all()
    degree = len(edges)
    contexts = len(set(e.context for e in edges))
    interaction_types = len(set(e.interaction_type for e in edges))
    age_bonus = 0.15
    score = 0.25 + min(0.35, degree * 0.07) + min(0.20, contexts * 0.05) + min(0.15, interaction_types * 0.04) + age_bonus
    score = round(max(0.05, min(0.98, score - (0.10 if node.node_type == "external" else 0.0))), 3)

    confidence = "high" if score >= 0.78 else "medium" if score >= 0.48 else "low"
    signals = []
    if degree >= 3: signals.append("multi_edge_history")
    if contexts >= 2: signals.append("context_diversity")
    if interaction_types >= 2: signals.append("channel_diversity")
    if node.node_type == "pilot": signals.append("trusted_pilot_identity")
    if not signals: signals.append("weak_relational_history")

    return {
        "node_id": node_id,
        "exists": True,
        "relational_strength": score,
        "identity_confidence": confidence,
        "signals": signals,
        "trust_score": node.trust_score,
        "risk_score": node.risk_score
    }
