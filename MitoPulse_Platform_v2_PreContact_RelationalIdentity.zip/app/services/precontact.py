
from sqlalchemy.orm import Session
from app.models.schema import Node, Edge

def pre_contact_risk(db: Session, target: str, context: str = "message"):
    node = db.get(Node, target)
    if not node:
        return {
            "target": target,
            "exists": False,
            "risk_score": 0.92,
            "signal": "unknown_node",
            "guardian_decision": "REVIEW"
        }

    degree = db.query(Edge).filter((Edge.source == target) | (Edge.target == target)).count()
    contexts = db.query(Edge).filter((Edge.source == target) | (Edge.target == target)).all()
    diverse_contexts = len(set(e.context for e in contexts))
    base_risk = 0.55 if node.node_type == "external" else 0.18
    base_risk += max(0.0, 0.18 - min(0.18, degree * 0.03))
    base_risk += max(0.0, 0.12 - min(0.12, diverse_contexts * 0.03))
    base_risk += min(0.20, node.risk_score * 0.45)

    if context in ("financial_request", "urgent_transfer", "signature_request"):
        base_risk += 0.10

    risk = round(max(0.02, min(0.98, base_risk)), 3)
    decision = "BLOCK" if risk >= 0.82 else "REVIEW" if risk >= 0.48 else "ALLOW"
    signal = "fraud_cluster" if node.risk_score >= 0.40 else "limited_relational_history" if degree <= 1 else "stable_relational_presence"

    return {
        "target": target,
        "exists": True,
        "risk_score": risk,
        "signal": signal,
        "degree": degree,
        "identity_confidence": node.identity_confidence,
        "guardian_decision": decision
    }
