
from pydantic import BaseModel

class BootstrapIn(BaseModel):
    cluster: str = "pilot_seed"

class InteractionIn(BaseModel):
    source: str
    target: str
    interaction_type: str = "whatsapp_message"
    context: str = "general"

class CrossPulseIn(BaseModel):
    source: str
    target: str
    reason: str = "validate_interaction"

class AttackIn(BaseModel):
    attack_type: str = "number_change"

class PreContactIn(BaseModel):
    target: str
    context: str = "message"

class RelationalIdentityIn(BaseModel):
    node_id: str
