
# Implementation Notes

## Pre-Contact Risk
Endpoint:
- `POST /api/precontact`

Entrada:
- `target`
- `context`

Evalúa:
- existencia del nodo
- historial relacional
- diversidad contextual
- riesgo previo del nodo
- contexto sensible

## Relational Identity
Endpoint:
- `POST /api/relational-identity`

Entrada:
- `node_id`

Evalúa:
- fuerza relacional
- diversidad de contextos
- diversidad de canales
- confianza e historial

## Integración futura sugerida
1. Reemplazar SQLite por PostgreSQL.
2. Añadir Redis para caché de evaluación.
3. Introducir tabla de canales por identidad persistente.
4. Añadir Guardian Nodes institucionales.
5. Agregar API keys y rate limiting.
