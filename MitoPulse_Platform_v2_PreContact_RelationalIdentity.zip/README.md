
# MitoPulse Platform v2 Extended

Versión completa para continuar el desarrollo actual, integrando:

- plataforma v2 modular
- piloto real
- captura de interacciones
- cross-pulse
- simulación de ataques
- módulo **Pre-Contact Risk**
- módulo **Relational Identity**

## Estructura
- `app/core`
- `app/models`
- `app/services`
- `app/api`
- `app/templates`

## Ejecutar
```bash
pip install -r requirements.txt
python run.py
```

o

```bash
uvicorn app.main:app --reload
```

## Abrir
`http://127.0.0.1:8000`
