from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field
import json

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    app_name: str = Field(default="MitoPulse v5 Productive Platform", alias="APP_NAME")
    database_url: str = Field(default="sqlite:///./mitopulse_v5.db", alias="DATABASE_URL")
    redis_url: str = Field(default="redis://localhost:6379/0", alias="REDIS_URL")
    default_tenant: str = Field(default="bank_demo", alias="DEFAULT_TENANT")
    api_keys_json: str = Field(default='{"bank_demo":"demo-bank-key"}', alias="API_KEYS_JSON")

    @property
    def api_keys(self) -> dict[str, str]:
        try:
            return json.loads(self.api_keys_json)
        except Exception:
            return {"bank_demo": "demo-bank-key"}

settings = Settings()
