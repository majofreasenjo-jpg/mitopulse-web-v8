from sqlalchemy import Column, String, Float, Integer, DateTime, Text
from datetime import datetime
from app.core.database import Base

def now():
    return datetime.utcnow()

class TenantMixin:
    tenant_id = Column(String, index=True, nullable=False)

class Node(Base, TenantMixin):
    __tablename__ = "nodes"
    id = Column(Integer, primary_key=True, autoincrement=True)
    node_id = Column(String, index=True, nullable=False)
    label = Column(String, nullable=False)
    node_type = Column(String, default="customer")
    cluster = Column(String, default="default")
    trust_score = Column(Float, default=0.50)
    risk_score = Column(Float, default=0.0)
    identity_confidence = Column(Float, default=0.50)
    is_guardian = Column(Integer, default=0)
    status = Column(String, default="active")
    created_at = Column(DateTime, default=now)

class Edge(Base, TenantMixin):
    __tablename__ = "edges"
    id = Column(Integer, primary_key=True, autoincrement=True)
    source = Column(String, index=True, nullable=False)
    target = Column(String, index=True, nullable=False)
    interaction_type = Column(String, default="bank_transfer")
    context = Column(String, default="general")
    weight = Column(Float, default=1.0)
    created_at = Column(DateTime, default=now)

class Alert(Base, TenantMixin):
    __tablename__ = "alerts"
    id = Column(Integer, primary_key=True, autoincrement=True)
    source = Column(String, nullable=False)
    target = Column(String, nullable=False)
    attack_type = Column(String, default="unknown")
    risk_score = Column(Float, default=0.0)
    cluster_risk = Column(Float, default=0.0)
    guardian_decision = Column(String, default="REVIEW")
    message = Column(Text, default="")
    created_at = Column(DateTime, default=now)

class Event(Base, TenantMixin):
    __tablename__ = "events"
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_type = Column(String, nullable=False)
    payload_json = Column(Text, default="{}")
    created_at = Column(DateTime, default=now)

class CrossPulse(Base, TenantMixin):
    __tablename__ = "cross_pulses"
    pulse_id = Column(String, primary_key=True)
    source = Column(String, nullable=False)
    target = Column(String, nullable=False)
    reason = Column(String, default="validate_interaction")
    status = Column(String, default="confirmed")
    created_at = Column(DateTime, default=now)
