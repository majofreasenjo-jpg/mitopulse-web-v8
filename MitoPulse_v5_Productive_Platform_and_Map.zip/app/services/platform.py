import json, random, uuid
from sqlalchemy.orm import Session
from app.models.schema import Node, Edge, Alert, Event, CrossPulse

PILOT_USERS = [
    ("user_manuel", "Manuel", 1),
    ("user_natalie", "Natalie", 1),
    ("user_paulina", "Paulina", 0),
    ("user_ricardo", "Ricardo", 0),
]

def add_event(db: Session, tenant_id: str, event_type: str, payload: dict):
    db.add(Event(tenant_id=tenant_id, event_type=event_type, payload_json=json.dumps(payload)))
    db.commit()

def get_node(db: Session, tenant_id: str, node_id: str):
    return db.query(Node).filter(Node.tenant_id == tenant_id, Node.node_id == node_id).first()

def ensure_node(db: Session, tenant_id: str, node_id: str, label: str | None = None, node_type: str = "customer", cluster: str = "default", is_guardian: int = 0) -> Node:
    row = get_node(db, tenant_id, node_id)
    if not row:
        row = Node(
            tenant_id=tenant_id,
            node_id=node_id,
            label=label or node_id,
            node_type=node_type,
            cluster=cluster,
            is_guardian=is_guardian
        )
        db.add(row)
        db.commit()
        db.refresh(row)
    return row

def recompute_scores(db: Session, tenant_id: str):
    rows = db.query(Node).filter(Node.tenant_id == tenant_id).all()
    edges = db.query(Edge).filter(Edge.tenant_id == tenant_id).all()
    degree = {}
    contexts = {}
    kinds = {}
    for e in edges:
        degree[e.source] = degree.get(e.source, 0) + 1
        degree[e.target] = degree.get(e.target, 0) + 1
        contexts.setdefault(e.source, set()).add(e.context)
        contexts.setdefault(e.target, set()).add(e.context)
        kinds.setdefault(e.source, set()).add(e.interaction_type)
        kinds.setdefault(e.target, set()).add(e.interaction_type)
    for n in rows:
        d = degree.get(n.node_id, 0)
        trust = 0.36 + min(0.42, d * 0.06) - min(0.30, n.risk_score * 0.35)
        if n.is_guardian:
            trust += 0.07
        ident = 0.24 + min(0.26, d * 0.05) + min(0.16, len(contexts.get(n.node_id, set())) * 0.05) + min(0.14, len(kinds.get(n.node_id, set())) * 0.04)
        if n.is_guardian:
            ident += 0.10
        n.trust_score = round(max(0.05, min(0.98, trust)), 3)
        n.identity_confidence = round(max(0.05, min(0.98, ident)), 3)
    db.commit()

def bootstrap_pilot(db: Session, tenant_id: str, cluster: str = "pilot_seed"):
    for model in (Alert, Event, CrossPulse, Edge, Node):
        db.query(model).filter(model.tenant_id == tenant_id).delete()
    db.commit()

    for nid, label, guardian in PILOT_USERS:
        ensure_node(db, tenant_id, nid, label, "customer", cluster, guardian)

    base_edges = [
        ("user_manuel", "user_natalie", "bank_transfer", "general", 0.95),
        ("user_manuel", "user_ricardo", "call", "general", 0.90),
        ("user_natalie", "user_paulina", "message", "general", 0.88),
        ("user_ricardo", "user_paulina", "in_person", "general", 0.97),
        ("user_natalie", "user_manuel", "bank_transfer", "general", 0.92),
    ]
    for s, t, it, ctx, weight in base_edges:
        db.add(Edge(tenant_id=tenant_id, source=s, target=t, interaction_type=it, context=ctx, weight=weight))
    db.commit()
    recompute_scores(db, tenant_id)
    add_event(db, tenant_id, "bootstrap", {"cluster": cluster, "users": [x[0] for x in PILOT_USERS]})

def capture_interaction(db: Session, tenant_id: str, source: str, target: str, interaction_type: str, context: str, weight: float):
    ensure_node(db, tenant_id, source, source)
    ensure_node(db, tenant_id, target, target)
    db.add(Edge(tenant_id=tenant_id, source=source, target=target, interaction_type=interaction_type, context=context, weight=weight))
    db.commit()
    recompute_scores(db, tenant_id)
    add_event(db, tenant_id, "interaction", {"source": source, "target": target, "interaction_type": interaction_type, "context": context, "weight": weight})

def create_crosspulse(db: Session, tenant_id: str, source: str, target: str, reason: str):
    ensure_node(db, tenant_id, source, source)
    ensure_node(db, tenant_id, target, target)
    pulse_id = "cp_" + uuid.uuid4().hex[:10]
    db.add(CrossPulse(tenant_id=tenant_id, pulse_id=pulse_id, source=source, target=target, reason=reason, status="confirmed"))
    db.add(Edge(tenant_id=tenant_id, source=source, target=target, interaction_type="cross_pulse", context=reason, weight=0.99))
    db.commit()
    recompute_scores(db, tenant_id)
    add_event(db, tenant_id, "cross_pulse", {"pulse_id": pulse_id, "source": source, "target": target, "reason": reason})
    return pulse_id

def simulate_attack(db: Session, tenant_id: str, attack_type: str):
    attacker = ensure_node(db, tenant_id, "ext_attacker_01", "Attacker X", "external")
    attacker.risk_score = max(attacker.risk_score, 0.78)
    scenarios = {
        "number_change": (["user_natalie", "user_ricardo"], "Hola, cambié mi número. Necesito ayuda urgente."),
        "marketplace": (["user_ricardo"], "Ya transferí. Revisa el comprobante y envía el producto."),
        "wallet": (["user_paulina"], "Firma esta solicitud urgente ahora."),
    }
    targets, message = scenarios.get(attack_type, scenarios["number_change"])
    out = []
    for tgt in targets:
        node = ensure_node(db, tenant_id, tgt, tgt)
        risk = round(random.uniform(0.72, 0.95), 3)
        node.risk_score = max(node.risk_score, round(risk * 0.60, 3))
        cluster_risk = min(0.95, round(node.risk_score + 0.18, 3))
        decision = "BLOCK" if risk >= 0.80 else "REVIEW"
        alert = Alert(
            tenant_id=tenant_id,
            source=attacker.node_id,
            target=tgt,
            attack_type=attack_type,
            risk_score=risk,
            cluster_risk=cluster_risk,
            guardian_decision=decision,
            message=message
        )
        db.add(alert)
        out.append({"target": tgt, "risk_score": risk, "cluster_risk": cluster_risk, "guardian_decision": decision, "message": message})
    db.commit()
    recompute_scores(db, tenant_id)
    add_event(db, tenant_id, "attack", {"attack_type": attack_type, "targets": targets})
    return out

def seed_simulation(db: Session, tenant_id: str, nodes: int, fraud_ratio: float):
    bootstrap_pilot(db, tenant_id, "simulation")
    fraud_nodes = int(nodes * fraud_ratio)
    for i in range(nodes):
        nid = f"sim_{i:04d}"
        ensure_node(db, tenant_id, nid, nid, "customer", "simulation", 1 if i % 97 == 0 else 0)

    ids = [f"sim_{i:04d}" for i in range(nodes)]
    for i in range(nodes - 1):
        db.add(Edge(tenant_id=tenant_id, source=ids[i], target=ids[i+1], interaction_type="transfer", context="general", weight=0.80))
    # suspicious star/funnel
    for i in range(fraud_nodes):
        target = "fraud_sink_01"
        ensure_node(db, tenant_id, target, "Fraud Sink", "external", "fraud_cluster", 0)
        src = ids[i]
        db.add(Edge(tenant_id=tenant_id, source=src, target=target, interaction_type="transfer", context="urgent_transfer", weight=0.55))
        n = get_node(db, tenant_id, src)
        n.risk_score = max(n.risk_score, 0.42)
    db.commit()
    recompute_scores(db, tenant_id)
    add_event(db, tenant_id, "simulation_seed", {"nodes": nodes, "fraud_ratio": fraud_ratio})

def get_state(db: Session, tenant_id: str):
    nodes = db.query(Node).filter(Node.tenant_id == tenant_id).all()
    edges = db.query(Edge).filter(Edge.tenant_id == tenant_id).all()
    alerts = db.query(Alert).filter(Alert.tenant_id == tenant_id).order_by(Alert.id.desc()).limit(20).all()
    events = db.query(Event).filter(Event.tenant_id == tenant_id).order_by(Event.id.desc()).limit(30).all()
    pulses = db.query(CrossPulse).filter(CrossPulse.tenant_id == tenant_id).order_by(CrossPulse.created_at.desc()).limit(20).all()
    return {
        "nodes": [{
            "id": n.node_id, "label": n.label, "type": n.node_type, "cluster": n.cluster,
            "trust_score": n.trust_score, "risk_score": n.risk_score,
            "identity_confidence": n.identity_confidence, "is_guardian": n.is_guardian,
            "status": n.status
        } for n in nodes],
        "edges": [{
            "source": e.source, "target": e.target, "interaction_type": e.interaction_type,
            "context": e.context, "weight": e.weight
        } for e in edges],
        "alerts": [{
            "source": a.source, "target": a.target, "attack_type": a.attack_type,
            "risk_score": a.risk_score, "cluster_risk": a.cluster_risk,
            "guardian_decision": a.guardian_decision, "message": a.message
        } for a in alerts],
        "events": [{
            "event_type": e.event_type, "payload": json.loads(e.payload_json),
            "created_at": e.created_at.isoformat() + "Z"
        } for e in events],
        "cross_pulses": [{
            "pulse_id": p.pulse_id, "source": p.source, "target": p.target,
            "reason": p.reason, "status": p.status
        } for p in pulses]
    }
