from pydantic import BaseModel, Field

class BootstrapIn(BaseModel):
    cluster: str = "pilot_seed"

class InteractionIn(BaseModel):
    source: str
    target: str
    interaction_type: str = "bank_transfer"
    context: str = "general"
    weight: float = 0.90

class CrossPulseIn(BaseModel):
    source: str
    target: str
    reason: str = "validate_interaction"

class AttackIn(BaseModel):
    attack_type: str = "number_change"

class PreContactIn(BaseModel):
    source: str = "user_natalie"
    target: str
    context: str = "financial_request"

class IdentityIn(BaseModel):
    node_id: str

class SeedSimulationIn(BaseModel):
    nodes: int = Field(default=1000, ge=10, le=5000)
    fraud_ratio: float = Field(default=0.03, ge=0.0, le=0.20)
