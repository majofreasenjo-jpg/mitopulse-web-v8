# MitoPulse v5 Productive Platform

Base de desarrollo productiva para continuar el proyecto.

## Incluye
- PostgreSQL por Docker
- Redis por Docker
- Fast Risk Engine
- Deep Graph Worker
- multi-tenant
- API keys por tenant
- bootstrap del piloto real
- seed de simulación institucional (1000 nodos)
- trust propagation
- relational identity
- pre-contact risk
- cluster risk / fraud spread
- dashboard institucional web

## Ejecución local rápida
```bash
cp .env.example .env
pip install -r requirements.txt
python run.py
```

## Ejecución con Docker
```bash
cp .env.example .env
docker compose up --build
```

## Demo por defecto
Tenant:
`bank_demo`

API key:
`demo-bank-key`

Abrir:
`http://127.0.0.1:8000`
