# Implementación v5

## Decisión rápida
Score final aproximado:
risk = f(
  propagated_trust,
  relational_identity,
  own_node_risk,
  cluster_risk,
  sensitive_context
)

## Tenant isolation
Todo dato se guarda con `tenant_id`.
Esto permite operar con:
- bank_demo
- marketplace_demo
- wallet_demo

## Próximos pasos recomendados
1. mover el worker a cola real (RQ/Celery)
2. agregar JWT o HMAC además de API key
3. agregar rate limiting
4. pasar a PostgreSQL en local y tests
5. crear conectores institucionales
6. diseñar el SDK móvil
