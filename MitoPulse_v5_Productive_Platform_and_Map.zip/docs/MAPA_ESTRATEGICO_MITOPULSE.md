# Mapa estratégico de MitoPulse

## Capa 1 — Canales de entrada
- bancos
- fintech
- marketplaces
- telcos
- wallets
- apps móviles con SDK

## Capa 2 — MitoPulse API
- `/api/precontact`
- `/api/identity`
- `/api/trust/{node_id}`
- `/api/cluster-risk/{node_id}`
- `/api/interaction`
- `/api/crosspulse`

## Capa 3 — Fast Risk Engine
Responde en milisegundos con:
- pre-contact risk
- identity score
- cluster risk
- guardian decision

## Capa 4 — Deep Graph Engine
Procesa de forma asíncrona:
- trust propagation
- fraud spread
- patrones topológicos
- recomputación de scores

## Capa 5 — Shared Reality Layer
Permite que múltiples instituciones consulten señales relacionales sin compartir datos personales.
Cada institución aporta:
- hashes de nodos
- hashes de relaciones
- contextos codificados

## Capa 6 — Guardian Network
Guardian nodes:
- bancos
- telcos
- nodos verificados
- usuarios con relaciones sólidas

## Capa 7 — Productos
- Fraud Social Detection Layer
- Pre-Contact Risk API
- Relational Identity API
- Institutional Dashboard
- Mobile SDK
- Shared Reality Consortium

## Secuencia de expansión
1. piloto real
2. fintech / app / marketplace
3. telco
4. primer banco
5. consorcio interinstitucional
6. red global de confianza digital

## Narrativa institucional
Cloudflare protege servidores.
MitoPulse protege relaciones humanas digitales.
