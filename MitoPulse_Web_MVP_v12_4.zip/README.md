
# MitoPulse v12.4

Independent release focused on both:
- B2B pilot readiness
- premium demo / partner mode

Includes:
- real persistence
- enterprise UI
- guided demo
- partner mode
- mobile companion
- optional API key requirement outside demo mode
