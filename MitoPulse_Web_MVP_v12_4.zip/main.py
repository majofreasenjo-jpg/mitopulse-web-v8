
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from datetime import datetime
import os, json, hashlib, random

from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, DateTime, Text
from sqlalchemy.orm import declarative_base, sessionmaker

app = FastAPI(title="MitoPulse v12.4")
templates = Jinja2Templates(directory="templates")

APP_MODE = os.getenv("APP_MODE", "cloud")
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./mitopulse_v12_4.db")
DEMO_MODE = os.getenv("DEMO_MODE", "true").lower() == "true"
API_KEY = os.getenv("MITOPULSE_API_KEY", "demo-key")

engine = create_engine(DATABASE_URL, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

def now_dt():
    return datetime.utcnow()

class Node(Base):
    __tablename__ = "nodes"
    node_id = Column(String, primary_key=True)
    trust_rank = Column(Float, default=50.0)
    nodal_mass = Column(Float, default=25.0)
    guardian = Column(Boolean, default=False)
    status = Column(String, default="healthy")
    fraud_exposure = Column(Float, default=0.0)
    pulse_count = Column(Integer, default=0)
    cross_pulse_count = Column(Integer, default=0)
    last_seen = Column(DateTime, nullable=True)

class Edge(Base):
    __tablename__ = "edges"
    id = Column(Integer, primary_key=True, autoincrement=True)
    source = Column(String, index=True)
    target = Column(String, index=True)
    weight = Column(Float, default=20.0)

class Evaluation(Base):
    __tablename__ = "evaluations"
    id = Column(Integer, primary_key=True, autoincrement=True)
    evaluation_id = Column(String, unique=True, index=True)
    source_node_id = Column(String)
    target_node_id = Column(String)
    industry = Column(String)
    decision = Column(String)
    trust_score = Column(Float)
    reason = Column(String)
    receipt = Column(String)
    breakdown_json = Column(Text)
    created_at = Column(DateTime, default=now_dt)

class RelaySession(Base):
    __tablename__ = "relay_sessions"
    code = Column(String, primary_key=True)
    initiator = Column(String)
    created_at = Column(DateTime, default=now_dt)

Base.metadata.create_all(bind=engine)

def seed():
    db = SessionLocal()
    try:
        if db.query(Node).count() > 0:
            return
        guardians = {1,2,7,11}
        high_risk = {9,15}
        quarantined = {10}
        for i in range(1, 19):
            nid = f"node_{i}"
            status = "quarantined" if i in quarantined else "high_risk" if i in high_risk else "healthy"
            exposure = 85 if i in quarantined else 55 if i in high_risk else random.randint(0, 35)
            db.add(Node(
                node_id=nid,
                trust_rank=random.randint(35, 95),
                nodal_mass=random.randint(20, 95),
                guardian=i in guardians,
                status=status,
                fraud_exposure=exposure,
                pulse_count=random.randint(1, 18),
                cross_pulse_count=random.randint(1, 12),
            ))
        rels = [
            ("node_1","node_2",82),("node_1","node_3",76),("node_2","node_4",61),("node_3","node_5",55),
            ("node_4","node_6",52),("node_6","node_7",71),("node_7","node_8",63),("node_8","node_9",44),
            ("node_9","node_10",88),("node_11","node_12",78),("node_12","node_13",66),("node_13","node_14",54),
            ("node_14","node_15",41),("node_15","node_16",47),("node_16","node_17",59),("node_17","node_18",64),
            ("node_2","node_11",38),("node_5","node_12",33)
        ]
        for a,b,w in rels:
            db.add(Edge(source=a, target=b, weight=w))
        db.commit()
    finally:
        db.close()

seed()

DEMO_CASES = {
    "whatsapp_fake_relative": {"source_node_id":"node_1","target_node_id":"node_10","industry":"banking","amount_anomaly":0.9,"routine_break":0.8},
    "legit_qr_payment": {"source_node_id":"node_2","target_node_id":"node_4","industry":"marketplace","amount_anomaly":0.1,"routine_break":0.1},
    "used_car_false_positive": {"source_node_id":"node_3","target_node_id":"node_14","industry":"banking","amount_anomaly":0.98,"routine_break":0.7},
    "wallet_drainer": {"source_node_id":"node_5","target_node_id":"node_9","industry":"crypto","amount_anomaly":0.92,"routine_break":0.85},
}

def get_node(db, node_id: str) -> Node:
    n = db.query(Node).filter(Node.node_id == node_id).first()
    if not n:
        n = Node(node_id=node_id)
        db.add(n)
        db.commit()
        db.refresh(n)
    return n

def get_edge(db, a: str, b: str):
    return db.query(Edge).filter(
        ((Edge.source == a) & (Edge.target == b)) | ((Edge.source == b) & (Edge.target == a))
    ).first()

def compute_eval(db, src, tgt, industry, amount_anomaly, routine_break):
    t = get_node(db, tgt)
    rel = get_edge(db, src, tgt)
    rds = rel.weight if rel else 10
    ass = int((t.trust_rank + t.nodal_mass) / 2)
    srs = 30 + (10 if rel else 0) + min(20, t.cross_pulse_count)
    sc = max(0, int(100 - ((amount_anomaly*100 + routine_break*100)/2)))
    fe = t.fraud_exposure
    trust_score = round((rds + ass + srs + sc)/4 - fe, 2)
    decision = "VERIFY" if trust_score >= 80 else "REVIEW" if trust_score >= 60 else "BLOCK"
    reason = "supportive relationship and low exposure" if decision == "VERIFY" else "moderate support or moderate exposure" if decision == "REVIEW" else "low support and/or high fraud exposure"
    return {
        "source_node_id": src,
        "target_node_id": tgt,
        "industry": industry,
        "decision": decision,
        "trust_score": trust_score,
        "recommended_action": "allow" if decision == "VERIFY" else "step_up_authentication",
        "reason": reason,
        "breakdown": {"RDS":rds,"ASS":ass,"SRS":srs,"SC":sc,"FE":fe}
    }

def require_api_key(x_api_key):
    if x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="invalid_api_key")

class EvalIn(BaseModel):
    source_node_id: str
    target_node_id: str
    industry: str = "banking"
    amount_anomaly: float = 0.9
    routine_break: float = 0.8

class PulseIn(BaseModel):
    node_id: str

class RelayCreateIn(BaseModel):
    node_id: str

class RelayConfirmIn(BaseModel):
    node_id: str
    code: str

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("home.html", {"request": request, "app_mode": APP_MODE, "database_url_set": bool(DATABASE_URL), "demo_mode": DEMO_MODE})

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.get("/demo", response_class=HTMLResponse)
def demo(request: Request):
    return templates.TemplateResponse("demo.html", {"request": request})

@app.get("/partner", response_class=HTMLResponse)
def partner(request: Request):
    return templates.TemplateResponse("partner.html", {"request": request})

@app.get("/graph", response_class=HTMLResponse)
def graph(request: Request):
    return templates.TemplateResponse("graph.html", {"request": request})

@app.get("/sdk", response_class=HTMLResponse)
def sdk(request: Request):
    return templates.TemplateResponse("sdk.html", {"request": request})

@app.get("/deploy", response_class=HTMLResponse)
def deploy(request: Request):
    return templates.TemplateResponse("deploy.html", {"request": request, "database_url_set": bool(DATABASE_URL), "app_mode": APP_MODE})

@app.get("/mobile", response_class=HTMLResponse)
def mobile(request: Request):
    return templates.TemplateResponse("mobile_home.html", {"request": request})

@app.get("/mobile/relay", response_class=HTMLResponse)
def mobile_relay(request: Request):
    return templates.TemplateResponse("mobile_relay.html", {"request": request})

@app.get("/mobile/eval", response_class=HTMLResponse)
def mobile_eval(request: Request):
    return templates.TemplateResponse("mobile_eval.html", {"request": request})

@app.get("/mobile/audit", response_class=HTMLResponse)
def mobile_audit(request: Request):
    return templates.TemplateResponse("mobile_audit.html", {"request": request})

@app.get("/api/summary")
def api_summary():
    db = SessionLocal()
    try:
        nodes = db.query(Node).all()
        return {
            "nodes": len(nodes),
            "guardians": sum(1 for n in nodes if n.guardian),
            "high_risk": sum(1 for n in nodes if n.status == "high_risk"),
            "quarantined": sum(1 for n in nodes if n.status == "quarantined"),
            "evaluations": db.query(Evaluation).count()
        }
    finally:
        db.close()

@app.get("/api/graph")
def api_graph():
    db = SessionLocal()
    try:
        nodes = db.query(Node).all()
        edges = db.query(Edge).all()
        return {
            "nodes": [{"node_id": n.node_id, "trust_rank": n.trust_rank, "nodal_mass": n.nodal_mass, "guardian": n.guardian, "status": n.status, "fraud_exposure": n.fraud_exposure} for n in nodes],
            "edges": [{"source": e.source, "target": e.target, "weight": e.weight} for e in edges]
        }
    finally:
        db.close()

@app.get("/api/node/{node_id}")
def api_node(node_id: str):
    db = SessionLocal()
    try:
        n = get_node(db, node_id)
        return {"node_id": n.node_id, "trust_rank": n.trust_rank, "nodal_mass": n.nodal_mass, "guardian": n.guardian, "status": n.status, "fraud_exposure": n.fraud_exposure, "pulse_count": n.pulse_count, "cross_pulse_count": n.cross_pulse_count, "last_seen": n.last_seen.isoformat() if n.last_seen else None}
    finally:
        db.close()

@app.post("/api/pulse")
def api_pulse(payload: PulseIn):
    db = SessionLocal()
    try:
        n = get_node(db, payload.node_id)
        n.pulse_count += 1
        n.nodal_mass = min(100, n.nodal_mass + 1)
        n.last_seen = now_dt()
        db.commit()
        db.refresh(n)
        return {"node_id": n.node_id, "pulse_count": n.pulse_count, "last_seen": n.last_seen.isoformat(), "nodal_mass": n.nodal_mass}
    finally:
        db.close()

@app.post("/api/evaluate")
def api_evaluate(payload: EvalIn, x_api_key: str | None = Header(default=None)):
    if not DEMO_MODE:
        require_api_key(x_api_key)
    db = SessionLocal()
    try:
        result = compute_eval(db, payload.source_node_id, payload.target_node_id, payload.industry, payload.amount_anomaly, payload.routine_break)
        evaluation_id = f"ev_{db.query(Evaluation).count()+1}"
        receipt = hashlib.sha256(json.dumps(result, sort_keys=True).encode()).hexdigest()[:24]
        ev = Evaluation(
            evaluation_id=evaluation_id,
            source_node_id=payload.source_node_id,
            target_node_id=payload.target_node_id,
            industry=payload.industry,
            decision=result["decision"],
            trust_score=result["trust_score"],
            reason=result["reason"],
            receipt=receipt,
            breakdown_json=json.dumps(result["breakdown"])
        )
        db.add(ev)
        db.commit()
        result["evaluation_id"] = evaluation_id
        result["receipt"] = receipt
        return result
    finally:
        db.close()

@app.get("/api/evaluation/{evaluation_id}")
def api_get_evaluation(evaluation_id: str):
    db = SessionLocal()
    try:
        ev = db.query(Evaluation).filter(Evaluation.evaluation_id == evaluation_id).first()
        if not ev:
            raise HTTPException(status_code=404, detail="not_found")
        return {"evaluation_id": ev.evaluation_id, "source_node_id": ev.source_node_id, "target_node_id": ev.target_node_id, "industry": ev.industry, "decision": ev.decision, "trust_score": ev.trust_score, "reason": ev.reason, "receipt": ev.receipt, "breakdown": json.loads(ev.breakdown_json), "timestamp": ev.created_at.isoformat() if ev.created_at else None}
    finally:
        db.close()

@app.post("/api/relay/create")
def api_relay_create(payload: RelayCreateIn):
    db = SessionLocal()
    try:
        get_node(db, payload.node_id)
        code = str(random.randint(1000, 9999))
        db.merge(RelaySession(code=code, initiator=payload.node_id))
        db.commit()
        return {"code": code, "initiator": payload.node_id}
    finally:
        db.close()

@app.post("/api/relay/confirm")
def api_relay_confirm(payload: RelayConfirmIn):
    db = SessionLocal()
    try:
        get_node(db, payload.node_id)
        session = db.query(RelaySession).filter(RelaySession.code == payload.code).first()
        if not session:
            raise HTTPException(status_code=404, detail="invalid_code")
        a = session.initiator
        b = payload.node_id
        if a == b:
            raise HTTPException(status_code=400, detail="same_node")
        edge = get_edge(db, a, b)
        before = edge.weight if edge else 0
        if not edge:
            edge = Edge(source=a, target=b, weight=25)
            db.add(edge)
        edge.weight = min(100, edge.weight + 8)
        get_node(db, a).cross_pulse_count += 1
        get_node(db, b).cross_pulse_count += 1
        db.commit()
        return {"status": "confirmed", "node_a": a, "node_b": b, "relationship_weight_before": before, "relationship_weight_after": edge.weight, "source": "relay_code"}
    finally:
        db.close()

@app.get("/api/demo_cases")
def api_demo_cases():
    return DEMO_CASES

@app.post("/api/demo/run/{case_name}")
def api_demo_run(case_name: str):
    if case_name not in DEMO_CASES:
        raise HTTPException(status_code=404, detail="unknown_case")
    payload = DEMO_CASES[case_name]
    return api_evaluate(EvalIn(**payload), None)

@app.get("/api/platform_profile")
def api_platform_profile():
    return {"hosting": "cloud-only", "database": "real persistence via SQLAlchemy / PostgreSQL-ready DATABASE_URL", "sdk": ["Web SDK", "Mobile SDK", "Backend API"], "clients": ["banks", "fintech", "wallets", "marketplaces"], "auth": "x-api-key for non-demo mode"}
