
# v12.4 notes

This version combines both directions:
1. Pilot B2B real:
   - SQLAlchemy persistence
   - x-api-key support when DEMO_MODE=false
   - deployment guidance
2. Demo premium:
   - guided demo
   - partner mode
   - executive dashboard
