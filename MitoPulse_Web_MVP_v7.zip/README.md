# MitoPulse Web MVP v7

Cierre de etapa: versión web con onboarding guiado, modo presentación y almacenamiento **solo en la nube**.

## Importante
Esta versión **no usa almacenamiento local por defecto**.
Si no defines `DATABASE_URL`, la app no inicia.
Así evitas que el historial quede alojado en tu PC.

## Incluye
- dashboard web
- app web
- onboarding guiado para familiares y amigos
- trust graph visual
- clusters por color
- nodos guardianes
- simulador manual
- simulación automática
- historial por usuario
- guardian mode anti-estafa telefónica
- modo presentación
- almacenamiento cloud-only

## Requisitos
1. Crear una base en Neon
2. Definir `DATABASE_URL`
3. Desplegar en Railway / Render / Fly / tu servidor
4. Opcional: conectar dominio con Cloudflare

## Variables
```bash
DATABASE_URL=postgresql+psycopg2://USER:PASSWORD@HOST/DB?sslmode=require
```

## Ejecutar
```bash
pip install -r requirements.txt
export DATABASE_URL='postgresql+psycopg2://USER:PASSWORD@HOST/DB?sslmode=require'
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

## URLs
- Dashboard: /
- App: /app
- Onboarding: /onboarding
- Presentación: /present
