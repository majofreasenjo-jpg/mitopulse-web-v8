import os, json, time, uuid, math, random, asyncio
from collections import defaultdict, deque
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect, Form
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, Column, String, Integer, Float, Text
from sqlalchemy.orm import declarative_base, sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL")
if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL is required. This version is cloud-only and will not run with local storage.")

BASE_DIR=os.path.dirname(os.path.dirname(__file__))
engine=create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal=sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base=declarative_base()

def now(): return int(time.time())
def make_id(p): return f"{p}_{uuid.uuid4().hex[:10]}"
def clamp(v,a,b): return max(a,min(b,v))
def decay(score,last_ts,lam=0.0008):
    if not last_ts: return score
    return round(score*math.exp(-lam*max(0,now()-int(last_ts))),2)

class User(Base):
    __tablename__="users"; id=Column(String, primary_key=True); name=Column(String); email=Column(String)
    created_at=Column(Integer); nodal_mass=Column(Float, default=10.0); last_active_at=Column(Integer); status=Column(String, default="active")

class Relationship(Base):
    __tablename__="relationships"; id=Column(String, primary_key=True); user_a=Column(String); user_b=Column(String)
    weight=Column(Float, default=20.0); interactions=Column(Integer, default=0); last_interaction_at=Column(Integer); created_at=Column(Integer)

class Evaluation(Base):
    __tablename__="evaluations"; id=Column(String, primary_key=True); event_id=Column(String); user_id=Column(String); target_id=Column(String)
    scenario=Column(String); source=Column(String); human_presence=Column(Float); freedom_score=Column(Float); relational_trust=Column(Float)
    shared_reality=Column(Float); mitopulse_score=Column(Float); decision=Column(String); guardian_alert=Column(Integer, default=0); created_at=Column(Integer)

Base.metadata.create_all(bind=engine)

app=FastAPI(title="MitoPulse Web MVP v7")
templates=Jinja2Templates(directory=os.path.join(BASE_DIR,"templates"))
app.mount("/app", StaticFiles(directory=os.path.join(BASE_DIR,"webapp"), html=True), name="webapp")

class WSManager:
    def __init__(self): self.connections=[]
    async def connect(self,ws): await ws.accept(); self.connections.append(ws)
    def disconnect(self,ws):
        if ws in self.connections: self.connections.remove(ws)
    async def broadcast(self,payload):
        dead=[]
        for ws in self.connections:
            try: await ws.send_json(payload)
            except: dead.append(ws)
        for ws in dead: self.disconnect(ws)

manager=WSManager()
SIM={"running":False,"tick":0,"task":None}

def get_user(db,uid): return db.query(User).filter(User.id==uid).first()
def get_rel(db,a,b):
    rel=db.query(Relationship).filter(((Relationship.user_a==a)&(Relationship.user_b==b))|((Relationship.user_a==b)&(Relationship.user_b==a))).first()
    if not rel:
        rel=Relationship(id=make_id("rel"), user_a=a, user_b=b, weight=20.0, interactions=0, created_at=now())
        db.add(rel); db.flush()
    return rel
def neighbors(db,uid):
    rels=db.query(Relationship).filter((Relationship.user_a==uid)|(Relationship.user_b==uid)).all()
    return [(r.user_b if r.user_a==uid else r.user_a, r.weight) for r in rels]

def human_presence(p):
    dur=max(0.1,(time.time()*1000-int(p.get("started_at",int(time.time()*1000))))/1000.0)
    s=20+min(20,(int(p.get("click_count",0))+int(p.get("key_count",0)))*2.2)+min(15,int(p.get("move_count",0))*0.08)+min(15,dur*2.8)+min(20,float(p.get("interaction_entropy",0))*35)+min(10,float(p.get("hesitation",0))*20)
    return round(clamp(s,0,100),2)
def freedom(p):
    s=100-(float(p.get("urgency",0))*30+float(p.get("dictation_risk",0))*35+float(p.get("routine_break",0))*20-float(p.get("hesitation",0))*8)
    return round(clamp(s,0,100),2)
def shared_reality(p):
    s=(float(p.get("social_overlap",0))+float(p.get("temporal_alignment",0))+float(p.get("context_fit",0))+float(p.get("interaction_coherence",0)))*25
    return round(clamp(s,0,100),2)
def relational(db,a,b,scenario,amount):
    u=get_user(db,a); t=get_user(db,b) if b else None
    if not t: return 25.0
    rel=get_rel(db,a,b)
    direct=decay(rel.weight, rel.last_interaction_at)
    nu,nt=neighbors(db,a),neighbors(db,b)
    cross=0
    if nu or nt:
        cross=((sum(w for _,w in nu)/max(1,len(nu)))+(sum(w for _,w in nt)/max(1,len(nt))))/2
    social=100 if rel.interactions>3 else (65 if rel.interactions>0 else 25)
    nodal=clamp(math.sqrt(max(u.nodal_mass,1)*max(t.nodal_mass,1)),0,100)
    scen=35 if scenario in ("pass_transfer","marketplace","identity_spoof") and rel.interactions==0 and amount>0 else 80
    return round(clamp(0.30*direct+0.20*cross+0.20*social+0.15*nodal+0.15*scen,0,100),2)

def evaluate(db,p,source="manual"):
    hp=human_presence(p); fr=freedom(p); sr=shared_reality(p); rt=relational(db,p["user_id"],p.get("target_id"),p.get("scenario","generic"),float(p.get("amount",0) or 0))
    risk={"phone_scam":15,"identity_spoof":12,"pass_transfer":8,"marketplace":7,"legit_transfer":4}.get(p.get("scenario","generic"),5)
    score=round(clamp(0.15*hp+0.30*rt+0.20*sr+0.20*fr+0.10*float(p.get("device_reality",70))-0.05*risk,0,100),2)
    dec="VERIFY" if score>=80 else ("REVIEW" if score>=60 else "BLOCK")
    galert=1 if p.get("scenario") in ("phone_scam","identity_spoof") and (fr<45 or sr<40 or rt<35) else 0
    db.add(Evaluation(id=make_id("eval"), event_id=make_id("evt"), user_id=p["user_id"], target_id=p.get("target_id"), scenario=p.get("scenario","generic"), source=source,
        human_presence=hp, freedom_score=fr, relational_trust=rt, shared_reality=sr, mitopulse_score=score, decision=dec, guardian_alert=galert, created_at=now()))
    u=get_user(db,p["user_id"]); u.last_active_at=now(); u.nodal_mass=clamp(u.nodal_mass+(2 if dec=="VERIFY" else (-1 if dec=="BLOCK" else 0.2)),1,100)
    if p.get("target_id"):
        t=get_user(db,p["target_id"]); t.last_active_at=now(); t.nodal_mass=clamp(t.nodal_mass+(0.6 if dec=="VERIFY" else (-0.3 if dec=="BLOCK" else 0.1)),1,100)
        rel=get_rel(db,p["user_id"],p["target_id"]); rel.interactions+=1; rel.last_interaction_at=now(); rel.weight=round(clamp(rel.weight+(4 if dec=="VERIFY" else (-2 if dec=="BLOCK" else 0.5)),1,100),2)
    return {"decision":dec,"mitopulse_score":score,"human_presence":hp,"freedom_score":fr,"relational_trust":rt,"shared_reality":sr,"guardian_alert":galert}

def auto_payload(db,scenario):
    users=db.query(User).all()
    if len(users)<2: return None
    a=random.choice(users); b=random.choice([u for u in users if u.id!=a.id])
    cfg={
      "phone_scam":((100,900),(0.7,1.0),(0.5,1.0),(0.5,1.0),(0.0,0.3),(0.1,0.4),(0.1,0.4),(0.2,0.5)),
      "identity_spoof":((0,300),(0.5,0.9),(0.2,0.7),(0.6,1.0),(0.0,0.2),(0.2,0.5),(0.2,0.5),(0.2,0.6)),
      "marketplace":((100,1200),(0.3,0.7),(0.0,0.2),(0.4,0.8),(0.1,0.5),(0.4,0.8),(0.3,0.7),(0.4,0.8)),
      "pass_transfer":((50,700),(0.1,0.5),(0.0,0.2),(0.1,0.6),(0.4,0.9),(0.5,0.9),(0.5,0.9),(0.5,0.9)),
      "legit_transfer":((20,300),(0.0,0.2),(0.0,0.1),(0.0,0.2),(0.6,1.0),(0.7,1.0),(0.7,1.0),(0.7,1.0))
    }[scenario]
    amt,u,d,rb,so,ta,cf,ic = cfg
    return {"user_id":a.id,"target_id":b.id,"scenario":scenario,"amount":random.randint(*amt),"started_at":int(time.time()*1000)-random.randint(1200,7000),
            "click_count":random.randint(3,15),"key_count":random.randint(0,12),"move_count":random.randint(20,120),"interaction_entropy":round(random.uniform(0.2,0.9),2),
            "hesitation":round(random.uniform(0.05,0.6),2),"device_reality":random.randint(60,90),"urgency":round(random.uniform(*u),2),"dictation_risk":round(random.uniform(*d),2),
            "routine_break":round(random.uniform(*rb),2),"social_overlap":round(random.uniform(*so),2),"temporal_alignment":round(random.uniform(*ta),2),"context_fit":round(random.uniform(*cf),2),"interaction_coherence":round(random.uniform(*ic),2)}

async def sim_loop():
    while SIM["running"]:
        db=SessionLocal()
        try:
            sc=random.choices(["legit_transfer","pass_transfer","phone_scam","marketplace","identity_spoof"], weights=[5,4,2,3,2])[0]
            p=auto_payload(db,sc)
            if p: evaluate(db,p,"auto"); db.commit(); SIM["tick"]+=1
        finally: db.close()
        await manager.broadcast({"type":"refresh","tick":SIM["tick"]})
        await asyncio.sleep(2.2)

def graph_data(db):
    users=db.query(User).all(); rels=db.query(Relationship).all()
    adj=defaultdict(list)
    for r in rels: adj[r.user_a].append(r.user_b); adj[r.user_b].append(r.user_a)
    comp={}; cid=0
    for u in users:
        if u.id in comp: continue
        cid+=1; q=deque([u.id]); comp[u.id]=cid
        while q:
            cur=q.popleft()
            for nxt in adj[cur]:
                if nxt not in comp: comp[nxt]=cid; q.append(nxt)
    masses=sorted([u.nodal_mass for u in users], reverse=True)
    cut=masses[max(0, min(len(masses)-1, max(0, len(masses)//5 - 1)))] if masses else 999
    return {"nodes":[{"id":u.id,"label":u.name,"mass":round(u.nodal_mass,2),"cluster":comp.get(u.id,0),"guardian":u.nodal_mass>=cut and len(users)>=5} for u in users],
            "links":[{"source":r.user_a,"target":r.user_b,"weight":round(r.weight,2)} for r in rels]}

@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    db=SessionLocal()
    metrics={"users":db.query(User).count(),"relationships":db.query(Relationship).count(),"evaluations":db.query(Evaluation).count(),
             "verify":db.query(Evaluation).filter(Evaluation.decision=="VERIFY").count(),"review":db.query(Evaluation).filter(Evaluation.decision=="REVIEW").count(),
             "block":db.query(Evaluation).filter(Evaluation.decision=="BLOCK").count(),"guardian_alerts":db.query(Evaluation).filter(Evaluation.guardian_alert==1).count(),"auto_running":SIM["running"]}
    users=db.query(User).order_by(User.created_at.asc()).all()
    evals=db.query(Evaluation).order_by(Evaluation.created_at.desc()).limit(80).all()
    db.close()
    return templates.TemplateResponse("dashboard.html", {"request":request,"metrics":metrics,"users":users,"evaluations":evals})

@app.get("/onboarding", response_class=HTMLResponse)
def onboarding(request: Request):
    return templates.TemplateResponse("onboarding.html", {"request": request})

@app.get("/present", response_class=HTMLResponse)
def present(request: Request):
    return templates.TemplateResponse("present.html", {"request": request})

@app.get("/healthz")
def healthz():
    return PlainTextResponse("ok")

@app.post("/create_user")
async def create_user(name: str = Form(...), email: str = Form("")):
    db=SessionLocal(); db.add(User(id=make_id("usr"), name=name.strip(), email=email.strip(), created_at=now(), last_active_at=now(), nodal_mass=10.0, status="active")); db.commit(); db.close()
    await manager.broadcast({"type":"refresh"}); return RedirectResponse("/", status_code=303)

@app.post("/create_relationship")
async def create_relationship(user_a: str = Form(...), user_b: str = Form(...)):
    db=SessionLocal()
    if user_a!=user_b:
        rel=get_rel(db,user_a,user_b); rel.weight=clamp(rel.weight+5,1,100); db.commit()
    db.close(); await manager.broadcast({"type":"refresh"}); return RedirectResponse("/", status_code=303)

@app.post("/seed_demo_network")
async def seed_demo_network():
    db=SessionLocal(); names=["Manuel","Sofia","Carlos","Ana","Pedro","Lucia","Javier","Elena","Rocio","Tomas","Camila","Diego"]
    if db.query(User).count()<8:
        for n in names: db.add(User(id=make_id("usr"), name=n, email="", created_at=now(), last_active_at=now(), nodal_mass=random.randint(8,18), status="active")); db.flush()
    db.commit(); ids=[u.id for u in db.query(User).all()]
    for _ in range(min(30,max(12,len(ids)*2))):
        a,b=random.sample(ids,2); rel=get_rel(db,a,b); rel.weight=clamp(rel.weight+random.randint(2,12),1,100); rel.interactions+=random.randint(0,4); rel.last_interaction_at=now()-random.randint(0,60000)
    db.commit(); db.close(); await manager.broadcast({"type":"refresh"}); return RedirectResponse("/", status_code=303)

@app.post("/sim/start")
async def sim_start():
    if not SIM["running"]:
        SIM["running"]=True; SIM["task"]=asyncio.create_task(sim_loop())
    await manager.broadcast({"type":"refresh"}); return RedirectResponse("/", status_code=303)

@app.post("/sim/stop")
async def sim_stop():
    SIM["running"]=False; await manager.broadcast({"type":"refresh"}); return RedirectResponse("/", status_code=303)

@app.get("/api/users")
def api_users():
    db=SessionLocal(); out=[{"id":u.id,"name":u.name,"nodal_mass":u.nodal_mass} for u in db.query(User).order_by(User.created_at.asc()).all()]; db.close(); return out

@app.get("/api/user_history/{uid}")
def api_user_history(uid: str):
    db=SessionLocal(); rows=db.query(Evaluation).filter((Evaluation.user_id==uid)|(Evaluation.target_id==uid)).order_by(Evaluation.created_at.desc()).limit(80).all()
    out=[{"scenario":e.scenario,"source":e.source,"user_id":e.user_id,"target_id":e.target_id,"mps":e.mitopulse_score,"decision":e.decision,"guardian_alert":e.guardian_alert} for e in rows]; db.close(); return out

@app.get("/api/graph")
def api_graph():
    db=SessionLocal(); data=graph_data(db); db.close(); return data

@app.post("/api/evaluate")
async def api_evaluate(payload: dict):
    db=SessionLocal(); res=evaluate(db,payload,"manual"); db.commit(); db.close(); await manager.broadcast({"type":"refresh"}); return JSONResponse(res)

@app.post("/api/guardian_check")
async def api_guardian_check(payload: dict):
    payload["scenario"]="phone_scam"; db=SessionLocal(); res=evaluate(db,payload,"guardian_mode"); db.commit(); db.close(); await manager.broadcast({"type":"refresh"}); return JSONResponse(res)

@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await manager.connect(ws)
    try:
        while True: await ws.receive_text()
    except WebSocketDisconnect: manager.disconnect(ws)
