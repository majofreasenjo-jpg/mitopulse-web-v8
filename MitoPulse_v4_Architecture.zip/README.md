
# MitoPulse v4 Architecture

Runnable minimal architecture prototype.

Components:
- FastAPI API
- Identity Engine placeholder
- Redis state layer
- Postgres storage
- Docker deployment
