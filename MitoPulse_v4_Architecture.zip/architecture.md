
MitoPulse v4 Architecture

Devices
 ├ Mobile Apps
 ├ PWA
 └ Wearables

Edge
 ├ CDN
 ├ WAF
 └ TLS

API Gateway
 ├ /identity/event
 ├ /identity/state
 ├ /identity/verify
 └ /identity/human-proof

Engine
 ├ Baseline Engine
 ├ Stability Engine
 ├ Risk Engine
 └ Human Confidence Engine

Storage
 ├ Redis (realtime)
 └ Postgres (history)

Dashboard
 └ Enterprise Monitoring
