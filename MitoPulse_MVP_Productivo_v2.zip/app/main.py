
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi import Request

app = FastAPI(title="MitoPulse MVP Productivo v2")
templates = Jinja2Templates(directory="templates")

pilot_nodes = [
    {"id":"nd_manu_01","name":"Manuel"},
    {"id":"nd_ana_01","name":"Ana"},
    {"id":"nd_bruno_01","name":"Bruno"},
    {"id":"nd_carla_01","name":"Carla"}
]

guardians = [
    {"id":"guardian_bank_01","type":"bank"},
    {"id":"guardian_telco_01","type":"telco"},
    {"id":"guardian_marketplace_01","type":"marketplace"}
]

@app.get("/")
def home():
    return {"platform":"MitoPulse MVP Productivo v2","pilot_nodes":pilot_nodes,"guardians":guardians}

@app.get("/pilot")
def pilot():
    return {"pilot_nodes":pilot_nodes}

@app.get("/guardians")
def guardian_layer():
    return {"guardians":guardians}

@app.get("/health")
def health():
    return {"status":"running"}
