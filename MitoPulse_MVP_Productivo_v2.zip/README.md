
# MitoPulse MVP Productivo v2

Este paquete representa el MVP orientado a socios (bancos, marketplaces, telcos).

Incluye:
- arquitectura base
- red piloto de 4 nodos
- guardian layer
- manual de uso

Ejecutar:

pip install fastapi uvicorn jinja2
uvicorn app.main:app --reload

Abrir:
http://127.0.0.1:8000
