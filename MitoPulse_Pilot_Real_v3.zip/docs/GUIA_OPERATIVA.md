
# Guía operativa — piloto real v3

## Personas reales
- Manuel
- Natalie
- Paulina
- Ricardo

## Flujos
1. Inicializa el piloto real.
2. Captura interacciones reales:
   - whatsapp_message
   - call
   - bank_transfer
   - in_person
   - link
3. Usa cross-pulse para validar una interacción sospechosa.
4. Simula ataques y revisa alertas.
5. Observa trust score, risk y timeline.

## Objetivo
Construir una red humana real observable y demostrar:
- continuidad relacional
- radio de confianza
- detección de anomalías
- reacción del guardian
