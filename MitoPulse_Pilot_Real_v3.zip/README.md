
# MitoPulse Pilot Real v3

Versión operativa del piloto real con:
- captura de interacciones reales
- timeline
- cross-pulse
- guardian decisions vía alertas
- trust graph visual

## Ejecutar
```bash
pip install fastapi uvicorn jinja2
uvicorn server:app --reload
```

Abrir:
http://127.0.0.1:8000
