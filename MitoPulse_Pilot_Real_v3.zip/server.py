
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from datetime import datetime
import random, uuid

app = FastAPI(title="MitoPulse Pilot Real v3")
templates = Jinja2Templates(directory="templates")

nodes = {}
edges = []
alerts = []
events = []
cross_pulses = []

REAL_PILOT = [
    ("nd_manuel_01", "Manuel"),
    ("nd_natalie_01", "Natalie"),
    ("nd_paulina_01", "Paulina"),
    ("nd_ricardo_01", "Ricardo"),
]

INVITE_CODES = {
    "ALPHA-MANUEL": "nd_manuel_01",
    "ALPHA-NATALIE": "nd_natalie_01",
    "ALPHA-PAULINA": "nd_paulina_01",
    "ALPHA-RICARDO": "nd_ricardo_01",
}

class InviteResolve(BaseModel):
    invite_code: str

class NodeRegister(BaseModel):
    node_id: str
    label: str | None = None

class Interaction(BaseModel):
    source: str
    target: str
    interaction_type: str = "whatsapp_message"
    context: str = "general"

class AttackSim(BaseModel):
    attack_type: str = "number_change"

class CrossPulseCreate(BaseModel):
    source: str
    target: str
    reason: str = "validate_interaction"

class CrossPulseConfirm(BaseModel):
    pulse_id: str
    confirmer: str

def now():
    return datetime.utcnow().isoformat() + "Z"

def ensure_node(node_id: str, label: str | None = None):
    if node_id not in nodes:
        nodes[node_id] = {
            "id": node_id,
            "label": label or node_id,
            "risk": 0.0,
            "trust_score": 0.5,
            "type": "pilot" if node_id.startswith("nd_") else "external"
        }

def edge_weight(a: str, b: str):
    score = 0.15
    for e in edges:
        if {e["source"], e["target"]} == {a, b}:
            score += 0.12
    return min(0.95, round(score, 3))

def compute_trust_score(node_id: str):
    related = [e for e in edges if e["source"] == node_id or e["target"] == node_id]
    if not related:
        return 0.35
    score = 0.45 + min(0.40, len(related) * 0.06)
    if nodes[node_id]["risk"] > 0:
        score -= min(0.30, nodes[node_id]["risk"] * 0.35)
    return max(0.05, min(0.98, round(score, 3)))

def recompute_scores():
    for nid in nodes.keys():
        nodes[nid]["trust_score"] = compute_trust_score(nid)

@app.post("/api/pilot/resolve-invite")
def resolve_invite(payload: InviteResolve):
    nid = INVITE_CODES.get(payload.invite_code)
    if not nid:
        return {"ok": False, "error": "invalid_invite_code"}
    label = dict(REAL_PILOT).get(nid, nid)
    ensure_node(nid, label)
    return {"ok": True, "node_id": nid, "display_name": label}

@app.post("/api/node/register")
def register_node(payload: NodeRegister):
    ensure_node(payload.node_id, payload.label)
    recompute_scores()
    return {"status": "registered", "node": nodes[payload.node_id]}

@app.post("/api/interaction/capture")
def capture_interaction(payload: Interaction):
    if payload.source not in nodes or payload.target not in nodes:
        return {"error": "nodes must exist first"}
    edge = {
        "source": payload.source,
        "target": payload.target,
        "interaction_type": payload.interaction_type,
        "context": payload.context,
        "created_at": now()
    }
    edges.append(edge)
    events.append({
        "type": "interaction",
        "source": payload.source,
        "target": payload.target,
        "interaction_type": payload.interaction_type,
        "context": payload.context,
        "timestamp": now()
    })
    recompute_scores()
    return {
        "status": "captured",
        "edge_weight": edge_weight(payload.source, payload.target),
        "source_trust": nodes[payload.source]["trust_score"],
        "target_trust": nodes[payload.target]["trust_score"]
    }

@app.post("/api/crosspulse/create")
def crosspulse_create(payload: CrossPulseCreate):
    if payload.source not in nodes or payload.target not in nodes:
        return {"error": "nodes must exist first"}
    pulse_id = "cp_" + uuid.uuid4().hex[:10]
    row = {
        "pulse_id": pulse_id,
        "source": payload.source,
        "target": payload.target,
        "reason": payload.reason,
        "status": "pending",
        "created_at": now(),
        "confirmed_by": None
    }
    cross_pulses.append(row)
    events.append({
        "type": "cross_pulse_created",
        "source": payload.source,
        "target": payload.target,
        "pulse_id": pulse_id,
        "timestamp": now()
    })
    return row

@app.post("/api/crosspulse/confirm")
def crosspulse_confirm(payload: CrossPulseConfirm):
    row = next((p for p in cross_pulses if p["pulse_id"] == payload.pulse_id), None)
    if not row:
        return {"error": "pulse_not_found"}
    row["status"] = "confirmed"
    row["confirmed_by"] = payload.confirmer
    row["confirmed_at"] = now()

    edges.append({
        "source": row["source"],
        "target": row["target"],
        "interaction_type": "cross_pulse",
        "context": row["reason"],
        "created_at": now()
    })
    events.append({
        "type": "cross_pulse_confirmed",
        "source": row["source"],
        "target": row["target"],
        "pulse_id": row["pulse_id"],
        "timestamp": now()
    })
    recompute_scores()
    return {"status": "confirmed", "pulse": row}

@app.post("/api/pilot/bootstrap")
def bootstrap():
    nodes.clear()
    edges.clear()
    alerts.clear()
    events.clear()
    cross_pulses.clear()

    for nid, label in REAL_PILOT:
        ensure_node(nid, label)

    base_edges = [
        ("nd_manuel_01", "nd_natalie_01", "whatsapp_message", "general"),
        ("nd_manuel_01", "nd_ricardo_01", "call", "general"),
        ("nd_natalie_01", "nd_paulina_01", "whatsapp_message", "general"),
        ("nd_ricardo_01", "nd_paulina_01", "in_person", "general"),
    ]
    for s, t, itype, ctx in base_edges:
        edges.append({
            "source": s,
            "target": t,
            "interaction_type": itype,
            "context": ctx,
            "created_at": now()
        })

    events.append({
        "type": "bootstrap",
        "message": "Pilot ring initialized with Manuel, Natalie, Paulina and Ricardo",
        "timestamp": now()
    })
    recompute_scores()
    return {"status": "pilot_initialized", "nodes": list(nodes.values()), "edges": edges}

@app.post("/api/attack/simulate")
def simulate_attack(payload: AttackSim):
    ext_id = "ext_attack_01"
    ensure_node(ext_id, "Attacker X")
    nodes[ext_id]["risk"] = 0.95

    if payload.attack_type == "number_change":
        targets = ["nd_natalie_01", "nd_ricardo_01"]
        message = "Hola, cambié mi número. Necesito ayuda urgente."
        context = "number_change"
    elif payload.attack_type == "marketplace":
        targets = ["nd_ricardo_01"]
        message = "Ya transferí. Revisa el comprobante y envía el producto."
        context = "fake_receipt"
    else:
        targets = ["nd_paulina_01"]
        message = "Firma esta solicitud urgente ahora."
        context = "wallet_phishing"

    created = []
    for tgt in targets:
        risk_score = round(random.uniform(0.70, 0.95), 3)
        nodes[tgt]["risk"] = max(nodes[tgt]["risk"], min(1.0, risk_score * 0.55))
        guardian = "BLOCK" if risk_score >= 0.80 else "REVIEW"
        alert = {
            "attack_type": payload.attack_type,
            "source": ext_id,
            "target": tgt,
            "risk_score": risk_score,
            "guardian_decision": guardian,
            "message": message,
            "context": context,
            "timestamp": now()
        }
        alerts.append(alert)
        created.append(alert)
        events.append({
            "type": "attack",
            "attack_type": payload.attack_type,
            "source": ext_id,
            "target": tgt,
            "message": message,
            "timestamp": now()
        })
    recompute_scores()
    return {"status": "simulated", "alerts": created}

@app.get("/api/graph")
def graph():
    return {"nodes": list(nodes.values()), "edges": edges}

@app.get("/api/alerts")
def get_alerts():
    return list(reversed(alerts[-20:]))

@app.get("/api/events")
def get_events():
    return list(reversed(events[-30:]))

@app.get("/api/pilot/users")
def get_pilot_users():
    return [{"node_id": nid, "display_name": label, "invite_code": code} for code, nid in INVITE_CODES.items() for nid2, label in REAL_PILOT if nid2 == nid]

@app.get("/api/crosspulse")
def get_crosspulses():
    return list(reversed(cross_pulses[-20:]))

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
