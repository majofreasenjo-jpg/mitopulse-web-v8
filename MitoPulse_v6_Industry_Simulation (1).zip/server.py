
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from datetime import datetime
import random

app = FastAPI(title="MitoPulse v6 Industry Simulation")
templates = Jinja2Templates(directory="templates")

sectors = ["banking","marketplace","crypto","telco"]
campaigns = []
stats = {"evaluated":0,"detected":0,"blocked":0,"reviewed":0}

class SimIn(BaseModel):
    sector: str = "banking"
    size: int = 10

def now():
    return datetime.utcnow().isoformat()+"Z"

@app.post("/api/simulate")
def simulate(payload: SimIn):
    run = {"sector": payload.sector, "size": payload.size, "events": [], "timestamp": now()}
    for i in range(payload.size):
        risk = round(random.uniform(0.2, 0.95), 3)
        decision = "BLOCK" if risk > 0.78 else "REVIEW" if risk > 0.48 else "ALLOW"
        run["events"].append({"id": i+1, "risk_score": risk, "decision": decision})
        stats["evaluated"] += 1
        if risk > 0.48: stats["detected"] += 1
        if decision == "BLOCK": stats["blocked"] += 1
        if decision == "REVIEW": stats["reviewed"] += 1
    campaigns.append(run)
    return run

@app.get("/api/state")
def state():
    return {"sectors": sectors, "campaigns": list(reversed(campaigns[-10:])), "stats": stats}

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
