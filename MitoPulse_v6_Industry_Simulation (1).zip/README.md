
# MitoPulse v6 Industry Simulation

Simulación ejecutable de campañas por sector:
- banking
- marketplace
- crypto
- telco

## Ejecutar
```bash
pip install fastapi uvicorn jinja2
uvicorn server:app --reload
```
