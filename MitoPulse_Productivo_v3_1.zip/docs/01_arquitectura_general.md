
# Arquitectura general — MitoPulse Productivo v3.1

## Propósito
MitoPulse evalúa la legitimidad de una interacción humana antes de que ocurra una acción crítica.

Ejemplos:
- transferencia bancaria
- recuperación de cuenta
- envío de producto
- firma de transacción crypto
- interacción de alto riesgo en mensajería

## Capas principales

### 1. User Layer
Usuarios, dispositivos, wallets, cuentas, sesiones.

### 2. Application Layer
Bancos, marketplaces, telcos, mensajería, exchanges y plataformas externas.

### 3. Relay Layer
Capa de registro/confirmación de interacción.

### 4. Fast Legitimacy Engine
Motor rápido en tiempo real.
Evalúa:
- historial relacional
- distancia en grafo
- trust radius
- señales básicas de anomalía

Output:
- Legitimacy Score
- Risk Level
- decisión inicial

### 5. Relational Anchor Engine (RAE)
Evalúa continuidad relacional sin depender totalmente de identidad fija.

Output:
- AnchorMatchScore

### 6. Deep Analysis Engine
Motor pesado asincrónico.
Analiza:
- patrones complejos
- campañas coordinadas
- fraude relacional
- entropía relacional

### 7. Fraud Spread Engine
Modela la propagación de riesgo a través del grafo.

### 8. Trust Waves Engine
Modela la propagación de señales positivas y negativas en la red.

### 9. Guardian Node Layer
Nodos institucionales con capacidades de supervisión:
- bancos
- marketplaces
- telecom
- wallets / exchanges

### 10. Attack Theater
Modo demostración para visualizar campañas de fraude y respuesta del sistema.

## Flujo de decisión

Interacción detectada
→ Relay Layer
→ Fast Legitimacy Engine
→ Relational Anchor Engine
→ decisión preliminar
→ Deep Analysis Engine
→ Fraud Spread / Trust Waves
→ Guardian Nodes
→ decisión consolidada
