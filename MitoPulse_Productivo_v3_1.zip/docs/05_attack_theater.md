
# Attack Theater — demo para bancos e inversionistas

## Objetivo
Mostrar visualmente cómo entra un atacante, cómo se propaga el riesgo y cómo MitoPulse lo detecta.

## Secuencia
1. Red normal
2. Aparece nodo atacante X
3. X contacta a Ana
4. X contacta a Bruno
5. Fraud Spread Engine detecta campaña
6. Trust Wave negativa se propaga
7. Nodo X queda marcado HIGH RISK
8. La interacción se bloquea o revisa

## Métricas visuales recomendadas
- Network Integrity Score
- Fraud Activity Level
- Active Risk Nodes
- Guardian Interventions

## Casos
1. Cambio de número
2. Fraude marketplace
3. Solicitud financiera urgente
