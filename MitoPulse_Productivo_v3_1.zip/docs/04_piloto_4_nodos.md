
# Guía operativa — piloto de 4 nodos reales

## Nodos
- nd_manu_01 — Manuel
- nd_ana_01 — Ana
- nd_bruno_01 — Bruno
- nd_carla_01 — Carla

## Flujo básico
1. Vincular dispositivo mediante onboarding.
2. Emitir primer pulse desde /mobile.
3. Crear relaciones con relay / QR / confirmación mutua.
4. Repetir interacciones durante varios días.
5. Revisar behavior memory en dashboard.
6. Ejecutar pruebas anómalas.
7. Visualizar alertas y propagación.

## Anchors de realidad posibles
- mensaje
- llamada
- transferencia
- encuentro presencial
- transacción marketplace

## Prueba recomendada
### Día 1
Manuel ↔ Ana
Manuel ↔ Bruno
Ana ↔ Carla

### Día 2
Repetición de interacciones
Construcción de baseline

### Día 3
Aparece nodo X
X → Ana
Mensaje: "Cambié mi número. Necesito dinero urgente."

### Resultado esperado
- legitimacy score bajo
- anchor match bajo
- trust radius violation
- fraud spread alert
