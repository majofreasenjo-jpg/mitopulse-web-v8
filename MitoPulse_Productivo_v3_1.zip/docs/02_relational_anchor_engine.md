
# Relational Anchor Engine (RAE)

## Definición
Módulo para evaluar si una entidad actual se comporta como el mismo actor relacional visto anteriormente,
sin depender exclusivamente de número, email, cuenta o identidad declarada.

## Pregunta central
¿La entidad actual conserva continuidad relacional con el actor histórico?

## Output
AnchorMatchScore (0–1)

Interpretación:
- 0.90 = continuidad casi segura
- 0.70 = continuidad probable
- 0.50 = incierto
- 0.30 = comportamiento diferente
- 0.10 = actor probablemente distinto

## Vectores del ancla

### A. Relational Pattern Vector (RPV)
- targets frecuentes
- frecuencia relativa
- estabilidad de vínculos
- cluster principal

### B. Temporal Behavior Vector (TBV)
- horas típicas
- distribución semanal
- ritmo entre eventos

### C. Interaction Context Vector (ICV)
- tipo de interacción
- intensidad
- secuencia de acciones

### D. Graph Topology Vector (GTV)
- distancia a nodos clave
- centralidad
- estabilidad de cluster

## Fórmula conceptual

AnchorMatch =
0.30 * similarity(RPV)
+0.25 * similarity(TBV)
+0.25 * similarity(ICV)
+0.20 * similarity(GTV)

## Integración al score final

LegitimityScore =
0.35 * RDS
+0.25 * SRS
+0.20 * BehaviorScore
+0.20 * AnchorMatch
- FraudExposure

## Casos de uso
- cambio de número
- cambio de dispositivo
- recuperación de cuenta
- prevención de suplantación
- validación contextual en wallets crypto
