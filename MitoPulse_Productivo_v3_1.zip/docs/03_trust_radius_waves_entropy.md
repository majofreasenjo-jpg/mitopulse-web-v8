
# Trust Radius, Trust Waves y Relational Entropy Barrier

## Trust Radius
Mide qué tan cerca está un nodo respecto de la red de confianza del usuario.

Distancias:
- 1 = contacto directo
- 2 = contacto indirecto
- 3+ = contacto lejano
- infinito = nodo externo / desconocido

Uso:
A mayor distancia, mayor penalización de legitimidad.

## Trust Waves
Las señales de confianza o riesgo no se quedan entre dos nodos.
Se propagan a través del grafo.

Ejemplo:
- una interacción legítima fuerte mejora levemente nodos vecinos
- una campaña de fraude genera una onda negativa de riesgo

## Relational Entropy Barrier
Mientras más madura se vuelve la red, más difícil es engañarla.
Un atacante debe imitar patrones sociales complejos:
- targets correctos
- horarios plausibles
- secuencia adecuada
- contexto compatible
- posición topológica coherente

Esto crea una barrera natural contra fraude masivo.
