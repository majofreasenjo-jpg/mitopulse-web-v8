
MitoPulse Pilot Mode v1

This patch enables:
- dynamic node registration
- relation creation
- pilot bootstrap for 4 real users

Run server:

pip install fastapi uvicorn

uvicorn server:app --reload

Initialize pilot:

POST /api/pilot/bootstrap

View graph:

GET /api/graph
