
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="MitoPulse Pilot Mode v1")

# In‑memory node store
nodes = {}
edges = []

class NodeRegister(BaseModel):
    node_id: str

class Relation(BaseModel):
    source: str
    target: str

@app.post("/api/node/register")
def register_node(data: NodeRegister):
    if data.node_id in nodes:
        return {"status":"exists","node_id":data.node_id}

    nodes[data.node_id] = {
        "neighbors":[],
        "created":True
    }
    return {"status":"registered","node_id":data.node_id}

@app.post("/api/relation/add")
def add_relation(rel: Relation):
    if rel.source not in nodes or rel.target not in nodes:
        return {"error":"nodes must exist first"}

    nodes[rel.source]["neighbors"].append(rel.target)
    nodes[rel.target]["neighbors"].append(rel.source)

    edges.append({"source":rel.source,"target":rel.target})

    return {"status":"relation_added","source":rel.source,"target":rel.target}

@app.get("/api/graph")
def get_graph():
    return {
        "nodes":[{"id":n} for n in nodes],
        "edges":edges
    }

@app.post("/api/pilot/bootstrap")
def bootstrap():
    pilot_nodes = [
        "nd_manu_01",
        "nd_ana_01",
        "nd_bruno_01",
        "nd_carla_01"
    ]

    for n in pilot_nodes:
        nodes[n]={"neighbors":[],"created":True}

    rels=[
        ("nd_manu_01","nd_ana_01"),
        ("nd_manu_01","nd_bruno_01"),
        ("nd_ana_01","nd_carla_01"),
        ("nd_bruno_01","nd_carla_01")
    ]

    for s,t in rels:
        nodes[s]["neighbors"].append(t)
        nodes[t]["neighbors"].append(s)
        edges.append({"source":s,"target":t})

    return {
        "status":"pilot_initialized",
        "nodes":pilot_nodes,
        "relations":rels
    }
