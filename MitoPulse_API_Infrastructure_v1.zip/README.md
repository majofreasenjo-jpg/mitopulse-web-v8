
# MitoPulse API Infrastructure v1

Base B2B partner-ready para vender MitoPulse como infraestructura de confianza.

## Productos
- Interaction Legitimacy API
- Pre-Contact Risk API
- Relational Continuity API

## Ejecutar
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

## Rutas
- /
- /sandbox
- /partner-dashboard
- /docs
