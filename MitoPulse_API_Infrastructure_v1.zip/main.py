
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
import hashlib, json, math

app = FastAPI(title="MitoPulse API Infrastructure v1")
templates = Jinja2Templates(directory="templates")

PARTNER_CONFIGS = {
    "banking": {"base_risk": 0.25, "high_risk_contexts": {"financial_transfer", "urgent_transfer", "account_recovery"}},
    "marketplace": {"base_risk": 0.18, "high_risk_contexts": {"product_release", "fake_receipt", "new_buyer"}},
    "telco": {"base_risk": 0.20, "high_risk_contexts": {"number_change", "new_contact", "sms_campaign"}},
    "crypto": {"base_risk": 0.30, "high_risk_contexts": {"signature_request", "wallet_recovery", "seed_phrase"}},
}

GUARDIAN_THRESHOLDS = {
    "banking": {"review": 0.45, "block": 0.70},
    "marketplace": {"review": 0.40, "block": 0.65},
    "telco": {"review": 0.42, "block": 0.68},
    "crypto": {"review": 0.38, "block": 0.60},
}

DEMO_NODES = {
    "nd_manu_01": {
        "frequent_targets": ["nd_ana_01", "nd_bruno_01"],
        "active_hours": [9, 10, 11, 18, 19, 20],
        "contexts": ["general", "message", "call", "financial_transfer"],
        "cluster": "family_a",
        "neighbors": ["nd_ana_01", "nd_bruno_01", "guardian_market_01"],
    },
    "nd_ana_01": {
        "frequent_targets": ["nd_manu_01", "nd_carla_01"],
        "active_hours": [8, 9, 10, 19, 20, 21],
        "contexts": ["general", "message", "call"],
        "cluster": "family_a",
        "neighbors": ["nd_manu_01", "nd_carla_01", "guardian_telco_01"],
    },
    "nd_bruno_01": {
        "frequent_targets": ["nd_manu_01", "nd_carla_01"],
        "active_hours": [10, 11, 12, 17, 18, 19],
        "contexts": ["general", "marketplace", "call"],
        "cluster": "family_b",
        "neighbors": ["nd_manu_01", "nd_carla_01", "guardian_bank_01"],
    },
    "nd_carla_01": {
        "frequent_targets": ["nd_ana_01", "nd_bruno_01"],
        "active_hours": [9, 12, 13, 18, 20],
        "contexts": ["general", "message", "marketplace"],
        "cluster": "family_b",
        "neighbors": ["nd_ana_01", "nd_bruno_01", "guardian_bank_01"],
    },
}

DEMO_ATTACKS = [
    {
        "attack_id": "atk_001",
        "name": "Cambio de número",
        "industry": "telco",
        "payload": {
            "partner_id": "partner_telco_demo",
            "industry": "telco",
            "source_node_id": "ext_unknown_01",
            "target_node_id": "nd_ana_01",
            "claimed_node_id": "nd_manu_01",
            "channel": "message",
            "context": "number_change",
            "event_hour": 3,
            "multi_target_count_1h": 2,
            "anchor_signals": {
                "frequent_targets": ["nd_ana_01"],
                "active_hours": [3],
                "contexts": ["number_change", "message"],
                "cluster": "unknown"
            }
        }
    },
    {
        "attack_id": "atk_002",
        "name": "Marketplace recibo falso",
        "industry": "marketplace",
        "payload": {
            "partner_id": "partner_market_demo",
            "industry": "marketplace",
            "source_node_id": "ext_buyer_01",
            "target_node_id": "nd_bruno_01",
            "claimed_node_id": "ext_buyer_01",
            "channel": "marketplace",
            "context": "fake_receipt",
            "event_hour": 11,
            "multi_target_count_1h": 3,
            "anchor_signals": {
                "frequent_targets": ["nd_bruno_01", "nd_carla_01"],
                "active_hours": [11],
                "contexts": ["fake_receipt", "marketplace"],
                "cluster": "unknown"
            }
        }
    },
    {
        "attack_id": "atk_003",
        "name": "Wallet phishing",
        "industry": "crypto",
        "payload": {
            "partner_id": "partner_wallet_demo",
            "industry": "crypto",
            "source_node_id": "ext_wallet_01",
            "target_node_id": "nd_manu_01",
            "claimed_node_id": "ext_wallet_01",
            "channel": "crypto",
            "context": "signature_request",
            "event_hour": 10,
            "multi_target_count_1h": 4,
            "anchor_signals": {
                "frequent_targets": ["nd_manu_01", "nd_ana_01"],
                "active_hours": [10],
                "contexts": ["signature_request", "crypto"],
                "cluster": "unknown"
            }
        }
    },
]

class AnchorSignals(BaseModel):
    frequent_targets: list[str] = []
    active_hours: list[int] = []
    contexts: list[str] = []
    cluster: Optional[str] = None

class EvaluateRequest(BaseModel):
    partner_id: str
    industry: str = "banking"
    source_node_id: str
    target_node_id: str
    claimed_node_id: Optional[str] = None
    channel: str = "message"
    context: str = "general"
    event_hour: Optional[int] = None
    multi_target_count_1h: int = 0
    anchor_signals: AnchorSignals = AnchorSignals()

class AnchorMatchRequest(BaseModel):
    candidate_node_id: str
    claimed_node_id: str
    event_hour: Optional[int] = None
    context: str = "general"
    anchor_signals: AnchorSignals = AnchorSignals()

class PrecontactRequest(BaseModel):
    partner_id: str
    industry: str = "telco"
    source_node_id: str
    target_node_id: str
    event_count_1h: int = 1
    unique_targets_1h: int = 1
    channel: str = "message"

def overlap_score(a, b):
    sa, sb = set(a), set(b)
    if not sa and not sb:
        return 1.0
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / max(1, len(sa | sb))

def anchor_match(payload: AnchorMatchRequest):
    claimed = DEMO_NODES.get(payload.claimed_node_id)
    if not claimed:
        return {
            "anchor_match_score": 0.10,
            "components": {"RPV": 0.0, "TBV": 0.0, "ICV": 0.0, "GTV": 0.0, "CAV": 0.5},
            "classification": "unknown_claimed_identity"
        }

    rpv = overlap_score(payload.anchor_signals.frequent_targets, claimed["frequent_targets"])
    tbv = overlap_score(payload.anchor_signals.active_hours + ([payload.event_hour] if payload.event_hour is not None else []), claimed["active_hours"])
    icv = overlap_score(payload.anchor_signals.contexts + [payload.context], claimed["contexts"])
    gtv = 1.0 if payload.anchor_signals.cluster and payload.anchor_signals.cluster == claimed["cluster"] else 0.15
    cav = 0.8 if payload.context in claimed["contexts"] else 0.2

    score = round((0.25*rpv)+(0.20*tbv)+(0.20*icv)+(0.20*gtv)+(0.15*cav), 4)
    classification = "high_continuity" if score >= 0.75 else "probable_continuity" if score >= 0.55 else "uncertain" if score >= 0.35 else "low_continuity"
    return {
        "anchor_match_score": score,
        "components": {"RPV": round(rpv,4), "TBV": round(tbv,4), "ICV": round(icv,4), "GTV": round(gtv,4), "CAV": round(cav,4)},
        "classification": classification
    }

def evaluate(payload: EvaluateRequest):
    config = PARTNER_CONFIGS.get(payload.industry, PARTNER_CONFIGS["banking"])
    thresholds = GUARDIAN_THRESHOLDS.get(payload.industry, GUARDIAN_THRESHOLDS["banking"])
    target_profile = DEMO_NODES.get(payload.target_node_id)
    dist = math.inf
    if target_profile:
        if payload.source_node_id in target_profile["neighbors"]:
            dist = 1
        elif payload.claimed_node_id in target_profile["neighbors"] if payload.claimed_node_id else False:
            dist = 2

    anchor = anchor_match(AnchorMatchRequest(
        candidate_node_id=payload.source_node_id,
        claimed_node_id=payload.claimed_node_id or payload.target_node_id,
        event_hour=payload.event_hour,
        context=payload.context,
        anchor_signals=payload.anchor_signals
    ))
    anchor_score = anchor["anchor_match_score"]

    behavior_penalty = 0.0
    if target_profile:
        if payload.event_hour is not None and payload.event_hour not in target_profile["active_hours"]:
            behavior_penalty += 0.18
        if payload.context not in target_profile["contexts"]:
            behavior_penalty += 0.10
    else:
        behavior_penalty += 0.20

    radius_penalty = 0.35 if dist == math.inf else 0.24 if dist == 3 else 0.12 if dist == 2 else 0.0
    spread_penalty = min(0.25, payload.multi_target_count_1h * 0.06)
    context_penalty = 0.15 if payload.context in config["high_risk_contexts"] else 0.04

    legitimacy = round(max(0.0, min(1.0, 1.0 - config["base_risk"] - behavior_penalty - radius_penalty - spread_penalty - context_penalty + (anchor_score*0.35))), 4)
    risk_score = round(1.0 - legitimacy, 4)

    decision = "VERIFY"
    if risk_score >= thresholds["block"]:
        decision = "BLOCK"
    elif risk_score >= thresholds["review"]:
        decision = "REVIEW"

    eval_id = "ev_" + hashlib.sha256(json.dumps(payload.model_dump(), sort_keys=True).encode()).hexdigest()[:12]
    reasons = []
    if radius_penalty >= 0.24:
        reasons.append("trust radius violation")
    if anchor_score < 0.35:
        reasons.append("low relational anchor match")
    if behavior_penalty > 0:
        reasons.append("behavioral deviation")
    if payload.multi_target_count_1h >= 2:
        reasons.append("possible campaign or multi-target contact")
    if payload.context in config["high_risk_contexts"]:
        reasons.append("high-risk context")

    return {
        "evaluation_id": eval_id,
        "partner_id": payload.partner_id,
        "industry": payload.industry,
        "decision": decision,
        "legitimacy_score": legitimacy,
        "risk_score": risk_score,
        "anchor_match_score": anchor_score,
        "graph_distance": "infinite" if dist == math.inf else dist,
        "explainability": reasons or ["interaction consistent with known pattern"],
        "breakdown": {
            "base_risk": config["base_risk"],
            "behavior_penalty": round(behavior_penalty,4),
            "trust_radius_penalty": round(radius_penalty,4),
            "spread_penalty": round(spread_penalty,4),
            "context_penalty": round(context_penalty,4),
            "anchor_components": anchor["components"]
        },
        "guardian_decision": decision if decision in ("REVIEW", "BLOCK") else "ALLOW",
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }

def precontact_check(payload: PrecontactRequest):
    base_risk = PARTNER_CONFIGS.get(payload.industry, PARTNER_CONFIGS["telco"])["base_risk"]
    risk = base_risk + min(0.30, payload.unique_targets_1h*0.08) + min(0.20, payload.event_count_1h*0.04)
    if payload.source_node_id.startswith("ext_"):
        risk += 0.15
    severity = "LOW" if risk < 0.45 else "MEDIUM" if risk < 0.70 else "HIGH"
    return {
        "partner_id": payload.partner_id,
        "source_node_id": payload.source_node_id,
        "target_node_id": payload.target_node_id,
        "channel": payload.channel,
        "risk_score": round(min(1.0, risk), 4),
        "severity": severity,
        "recommended_action": "monitor" if severity == "LOW" else "alert_and_review" if severity == "MEDIUM" else "block_or_challenge"
    }

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("home.html", {"request": request})

@app.get("/sandbox", response_class=HTMLResponse)
def sandbox(request: Request):
    return templates.TemplateResponse("sandbox.html", {"request": request})

@app.get("/partner-dashboard", response_class=HTMLResponse)
def partner_dashboard(request: Request):
    return templates.TemplateResponse("partner_dashboard.html", {"request": request})

@app.get("/api/openapi-profile")
def openapi_profile():
    return {
        "version": "MitoPulse_API_Infrastructure_v1",
        "products": ["interaction_legitimacy_api", "precontact_risk_api", "relational_continuity_api"],
        "industries": ["banking", "marketplace", "telco", "crypto"]
    }

@app.post("/api/evaluate")
def api_evaluate(payload: EvaluateRequest):
    return evaluate(payload)

@app.post("/api/anchor/match")
def api_anchor_match(payload: AnchorMatchRequest):
    return anchor_match(payload)

@app.post("/api/precontact/check")
def api_precontact_check(payload: PrecontactRequest):
    return precontact_check(payload)

@app.get("/api/demo/attacks")
def api_demo_attacks():
    return DEMO_ATTACKS

@app.post("/api/demo/run/{attack_id}")
def api_demo_run(attack_id: str):
    attack = next((a for a in DEMO_ATTACKS if a["attack_id"] == attack_id), None)
    if not attack:
        return {"error": "unknown_attack"}
    payload = EvaluateRequest(**attack["payload"])
    result = evaluate(payload)
    return {
        "attack_id": attack_id,
        "name": attack["name"],
        "industry": attack["industry"],
        "result": result
    }
