
# Integration Guide

## 1. Interaction Legitimacy API
Endpoint:
`POST /api/evaluate`

Uso:
Consultar antes de una acción crítica:
- transferencia
- liberación de producto
- firma de transacción
- cambio de número
- recuperación de cuenta

## 2. Relational Continuity API
Endpoint:
`POST /api/anchor/match`

Uso:
Detectar si un actor nuevo se comporta como continuidad de uno previo.

## 3. Pre-Contact Risk API
Endpoint:
`POST /api/precontact/check`

Uso:
Detectar campañas o contactos riesgosos antes de que escalen.

## Industrias
- banking
- marketplace
- telco
- crypto
