Demo de 10 minutos

1. Mostrar los 4 nodos piloto reales.
2. Mostrar las 3 instituciones simuladas.
3. Explicar Shared Signal Protocol.
4. Ejecutar el pre-contact risk sobre Fraud Cluster.
5. Mostrar que la relación legítima da ALLOW y la fraudulenta da REVIEW/BLOCK.
6. Cerrar con la tesis:
   MitoPulse detecta relaciones fraudulentas antes de la transacción.
