from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates

app = FastAPI(title="MitoPulse v14 Visual Pilot Demo")
templates = Jinja2Templates(directory="app/templates")

PILOT_NODES = [
    {"id": "manuel", "label": "Manuel", "group": "pilot", "x": 180, "y": 180},
    {"id": "natalie", "label": "Natalie", "group": "pilot", "x": 380, "y": 120},
    {"id": "paulina", "label": "Paulina", "group": "pilot", "x": 580, "y": 220},
    {"id": "ricardo", "label": "Ricardo", "group": "pilot", "x": 360, "y": 320},
    {"id": "marketplace_a", "label": "Marketplace A", "group": "institution", "x": 820, "y": 120},
    {"id": "bank_b", "label": "Bank B", "group": "institution", "x": 980, "y": 260},
    {"id": "telco_c", "label": "Telco C", "group": "institution", "x": 780, "y": 360},
    {"id": "fraud_sink", "label": "Fraud Cluster", "group": "fraud", "x": 1100, "y": 120},
]

BASE_EDGES = [
    {"source": "manuel", "target": "natalie", "type": "trusted_relation", "weight": 0.93},
    {"source": "natalie", "target": "paulina", "type": "trusted_relation", "weight": 0.89},
    {"source": "ricardo", "target": "paulina", "type": "trusted_relation", "weight": 0.91},
    {"source": "manuel", "target": "ricardo", "type": "trusted_relation", "weight": 0.87},
    {"source": "natalie", "target": "marketplace_a", "type": "buyer_seller", "weight": 0.58},
    {"source": "marketplace_a", "target": "bank_b", "type": "shared_signal", "weight": 0.77},
    {"source": "telco_c", "target": "bank_b", "type": "shared_signal", "weight": 0.81},
    {"source": "marketplace_a", "target": "fraud_sink", "type": "fraud_cluster", "weight": 0.92},
    {"source": "bank_b", "target": "fraud_sink", "type": "fraud_cluster", "weight": 0.86},
]

def precontact(source: str, target: str):
    known_pairs = {("manuel","natalie"),("natalie","paulina"),("ricardo","paulina"),("manuel","ricardo")}
    direct = (source, target) in known_pairs or (target, source) in known_pairs
    if target == "fraud_sink":
        return {"risk_score": 0.94, "decision": "BLOCK", "reason": "shared_reality_alert"}
    if target in {"marketplace_a", "bank_b", "telco_c"}:
        return {"risk_score": 0.66, "decision": "REVIEW", "reason": "institutional_unknown_relation"}
    if direct:
        return {"risk_score": 0.18, "decision": "ALLOW", "reason": "trusted_relation"}
    return {"risk_score": 0.78, "decision": "REVIEW", "reason": "unknown_relationship"}

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/api/graph")
def graph():
    return {"nodes": PILOT_NODES, "edges": BASE_EDGES}

@app.get("/api/scenarios")
def scenarios():
    return {
        "scenarios": [
            {
                "id": "pilot_real",
                "title": "4 nodos piloto reales",
                "description": "Manuel, Natalie, Paulina y Ricardo con relaciones de confianza."
            },
            {
                "id": "multi_institution",
                "title": "3 instituciones simuladas",
                "description": "Marketplace, banco y telco compartiendo señales."
            },
            {
                "id": "social_fraud",
                "title": "Fraude social",
                "description": "Señales compartidas elevan riesgo antes de la transferencia."
            }
        ]
    }

@app.get("/api/demo/precontact")
def demo_precontact(source: str = "natalie", target: str = "fraud_sink"):
    return precontact(source, target)

@app.get("/api/demo/summary")
def summary():
    return {
        "pilot_nodes": ["Manuel", "Natalie", "Paulina", "Ricardo"],
        "institutions": ["Marketplace A", "Bank B", "Telco C"],
        "shared_signals": 2,
        "fraud_cluster_detected": True,
        "global_trust_network": True
    }
