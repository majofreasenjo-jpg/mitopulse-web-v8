MitoPulse v14 Visual Pilot Demo

Ejecutar:
pip install -r requirements.txt
python run.py

Abrir:
http://127.0.0.1:8000

Incluye:
- visualización de grafo
- 4 nodos piloto reales
- 3 instituciones simuladas
- cluster de fraude
- demo pre-contact
