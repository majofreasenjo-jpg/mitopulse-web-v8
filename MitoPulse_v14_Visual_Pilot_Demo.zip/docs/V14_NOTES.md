MitoPulse v14 Visual Pilot Demo

Esta versión agrega:
- visualización del grafo
- 4 nodos piloto reales: Manuel, Natalie, Paulina y Ricardo
- 3 instituciones simuladas: Marketplace A, Bank B y Telco C
- cluster de fraude visible
- demo de pre-contact risk
- resumen para presentaciones institucionales
