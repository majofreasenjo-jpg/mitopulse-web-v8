
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Text, Boolean
from sqlalchemy.orm import declarative_base, sessionmaker
from datetime import datetime, timedelta
import os, json, hashlib, random

app = FastAPI(title="MitoPulse v15 Attack Simulation Engine")
templates = Jinja2Templates(directory="templates")

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./mitopulse_v15_attack_simulation.db")
engine = create_engine(DATABASE_URL, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

def now_dt():
    return datetime.utcnow()

# ---------- data model ----------
class Node(Base):
    __tablename__ = "nodes"
    node_id = Column(String, primary_key=True)
    label = Column(String, nullable=True)
    tenant = Column(String, default="demo")
    node_type = Column(String, default="internal")
    industry = Column(String, default="banking")
    trust_rank = Column(Float, default=50.0)
    nodal_mass = Column(Float, default=20.0)
    guardian_score = Column(Float, default=0.0)
    fraud_exposure = Column(Float, default=0.0)
    pulse_count = Column(Integer, default=0)
    cross_pulse_count = Column(Integer, default=0)
    status = Column(String, default="healthy")
    last_seen = Column(DateTime, nullable=True)

class PilotUser(Base):
    __tablename__ = "pilot_users"
    pilot_user_id = Column(String, primary_key=True)
    display_name = Column(String, nullable=False)
    node_id = Column(String, unique=True, nullable=False)
    tenant = Column(String, default="pilot_alpha4")
    invite_code = Column(String, unique=True, nullable=False)
    active = Column(Boolean, default=True)
    linked_device_label = Column(String, nullable=True)
    created_at = Column(DateTime, default=now_dt)

class PilotBehaviorMemory(Base):
    __tablename__ = "pilot_behavior_memory"
    node_id = Column(String, primary_key=True)
    tenant = Column(String, default="pilot_alpha4")
    avg_daily_pulses = Column(Float, default=0.0)
    avg_weekly_relays = Column(Float, default=0.0)
    frequent_targets_json = Column(Text, default="[]")
    active_hours_json = Column(Text, default="[]")
    last_7d_interactions = Column(Integer, default=0)
    last_30d_interactions = Column(Integer, default=0)
    baseline_score = Column(Float, default=50.0)
    updated_at = Column(DateTime, default=now_dt)

class Edge(Base):
    __tablename__ = "edges"
    id = Column(Integer, primary_key=True, autoincrement=True)
    source = Column(String, index=True)
    target = Column(String, index=True)
    tenant = Column(String, default="demo")
    weight = Column(Float, default=20.0)
    shared_reality = Column(Float, default=0.0)
    interaction_count = Column(Integer, default=0)

class Evaluation(Base):
    __tablename__ = "evaluations"
    id = Column(Integer, primary_key=True, autoincrement=True)
    evaluation_id = Column(String, unique=True, index=True)
    source_node_id = Column(String)
    target_node_id = Column(String)
    tenant = Column(String)
    decision = Column(String)
    trust_score = Column(Float)
    breakdown_json = Column(Text)
    created_at = Column(DateTime, default=now_dt)

class RelaySession(Base):
    __tablename__ = "relay_sessions"
    code = Column(String, primary_key=True)
    initiator = Column(String)
    tenant = Column(String, default="pilot_alpha4")

class ContactEvent(Base):
    __tablename__ = "contact_events"
    id = Column(Integer, primary_key=True, autoincrement=True)
    source_node_id = Column(String, index=True)
    target_node_id = Column(String, index=True)
    tenant = Column(String, default="pilot_alpha4")
    event_type = Column(String, default="contact_attempt")
    metadata_json = Column(Text, default="{}")
    timestamp = Column(DateTime, default=now_dt)

class PreContactAlert(Base):
    __tablename__ = "precontact_alerts"
    id = Column(Integer, primary_key=True, autoincrement=True)
    alert_id = Column(String, unique=True, index=True)
    source_node_id = Column(String)
    target_node_id = Column(String)
    tenant = Column(String)
    risk_score = Column(Float)
    severity = Column(String)
    reasons_json = Column(Text)
    created_at = Column(DateTime, default=now_dt)

class SimulationRun(Base):
    __tablename__ = "simulation_runs"
    run_id = Column(String, primary_key=True)
    scenario = Column(String)
    tenant = Column(String, default="sim_lab")
    status = Column(String, default="completed")
    config_json = Column(Text, default="{}")
    results_json = Column(Text, default="{}")
    created_at = Column(DateTime, default=now_dt)

Base.metadata.create_all(bind=engine)

INDUSTRY_OVERLAYS = {
    "banking": {"amount_weight": 1.2, "routine_weight": 1.1, "fraud_weight": 1.2, "shared_reality_boost": 1.0},
    "marketplace": {"amount_weight": 0.8, "routine_weight": 0.7, "fraud_weight": 1.1, "shared_reality_boost": 1.2},
    "crypto": {"amount_weight": 1.0, "routine_weight": 0.9, "fraud_weight": 1.5, "shared_reality_boost": 0.8},
    "messaging": {"amount_weight": 0.7, "routine_weight": 1.3, "fraud_weight": 1.0, "shared_reality_boost": 1.1},
}

# ---------- helpers ----------
def get_node(db, node_id, tenant="demo", node_type="internal", label=None):
    n = db.query(Node).filter(Node.node_id == node_id).first()
    if not n:
        n = Node(node_id=node_id, tenant=tenant, node_type=node_type, label=label or node_id)
        db.add(n)
        db.commit()
        db.refresh(n)
    return n

def get_edge(db, a, b, tenant=None):
    q = db.query(Edge).filter(((Edge.source == a) & (Edge.target == b)) | ((Edge.source == b) & (Edge.target == a)))
    if tenant:
        q = q.filter(Edge.tenant == tenant)
    return q.first()

def neighbors(db, node_id, tenant=None):
    q = db.query(Edge).filter((Edge.source == node_id) | (Edge.target == node_id))
    if tenant:
        q = q.filter(Edge.tenant == tenant)
    return q.all()

def ensure_behavior_row(db, node_id, tenant="pilot_alpha4"):
    row = db.query(PilotBehaviorMemory).filter(PilotBehaviorMemory.node_id == node_id).first()
    if not row:
        row = PilotBehaviorMemory(node_id=node_id, tenant=tenant)
        db.add(row)
        db.commit()
        db.refresh(row)
    return row

# ---------- fast decision plane ----------
def recompute_guardians(db, tenant):
    rows = db.query(Node).filter(Node.tenant == tenant).all()
    for n in rows:
        rels = neighbors(db, n.node_id, tenant)
        deg = len(rels)
        avgw = sum(r.weight for r in rels) / deg if deg else 0
        avgs = sum(r.shared_reality for r in rels) / deg if deg else 0
        score = 0.25 * min(100, deg * 15) + 0.25 * n.trust_rank + 0.15 * n.nodal_mass + 0.15 * min(100, n.pulse_count * 5) + 0.10 * avgs + 0.10 * avgw - 0.20 * n.fraud_exposure
        n.guardian_score = round(max(0, min(100, score)), 2)
    db.commit()

def recompute_spread(db, tenant):
    rows = db.query(Node).filter(Node.tenant == tenant).all()
    exposure = {n.node_id: max(0, n.fraud_exposure * 0.4) for n in rows}
    for _ in range(2):
        nxt = exposure.copy()
        for n in rows:
            spread = 0
            for r in neighbors(db, n.node_id, tenant):
                other = r.target if r.source == n.node_id else r.source
                spread += exposure.get(other, 0) * (r.weight / 100.0) * 0.18
            nxt[n.node_id] = min(100, max(nxt[n.node_id], round(spread, 2)))
        exposure = nxt
    for n in rows:
        n.fraud_exposure = exposure[n.node_id]
    db.commit()

def shared_reality(db, src, tgt, tenant):
    e = get_edge(db, src, tgt, tenant)
    if e:
        return min(100, 30 + e.shared_reality * 0.7 + e.weight * 0.2)
    s = get_node(db, src, tenant=tenant)
    t = get_node(db, tgt, tenant=tenant)
    return min(100, 20 + (15 if s.industry == t.industry else 0) + min(s.cross_pulse_count, t.cross_pulse_count))

def evaluate(db, src, tgt, tenant, industry, amount_anomaly, routine_break):
    target = get_node(db, tgt, tenant=tenant)
    edge = get_edge(db, src, tgt, tenant)
    overlay = INDUSTRY_OVERLAYS[industry]
    rds = edge.weight if edge else 10
    ass = int((target.trust_rank * 0.5) + (target.nodal_mass * 0.2) + (target.guardian_score * 0.3))
    srs = min(100, round(shared_reality(db, src, tgt, tenant) * overlay["shared_reality_boost"], 2))
    sc = max(0, int(100 - (((amount_anomaly * 100) * overlay["amount_weight"] + (routine_break * 100) * overlay["routine_weight"]) / 2)))
    fe = min(100, round(target.fraud_exposure * overlay["fraud_weight"], 2))
    score = round((rds + ass + srs + sc) / 4 - fe, 2)
    decision = "VERIFY" if score >= 80 else "REVIEW" if score >= 60 else "BLOCK"
    return {
        "source_node_id": src, "target_node_id": tgt, "tenant": tenant, "industry": industry,
        "decision": decision, "trust_score": score,
        "breakdown": {"RDS": rds, "ASS": ass, "SRS": srs, "SC": sc, "FE": fe}
    }

def recent_stats(db, source_node_id, tenant, minutes=60):
    cutoff = now_dt() - timedelta(minutes=minutes)
    rows = db.query(ContactEvent).filter(ContactEvent.source_node_id == source_node_id, ContactEvent.tenant == tenant, ContactEvent.timestamp >= cutoff).all()
    return len(rows), len(set(r.target_node_id for r in rows))

def precontact_eval(db, source_node_id, target_node_id, tenant="pilot_alpha4"):
    get_node(db, source_node_id, tenant=tenant, node_type="external", label=source_node_id)
    get_node(db, target_node_id, tenant=tenant, node_type="mobile", label=target_node_id)
    attempts, uniq = recent_stats(db, source_node_id, tenant)
    score = 20
    reasons = ["source is external to the trusted pilot ring"]
    if uniq >= 2:
        score += min(30, uniq * 8)
        reasons.append(f"source contacted {uniq} unique targets in the last 60 minutes")
    if attempts >= 3:
        score += min(20, attempts * 3)
        reasons.append(f"source attempted {attempts} contacts in the last 60 minutes")
    if get_edge(db, source_node_id, target_node_id, tenant) is None:
        score += 20
        reasons.append("no prior trusted edge exists between source and target")
    severity = "LOW"
    if score >= 70:
        severity = "HIGH"
    elif score >= 45:
        severity = "MEDIUM"
    result = {
        "source_node_id": source_node_id, "target_node_id": target_node_id, "tenant": tenant,
        "risk_score": round(min(100, score), 2), "severity": severity,
        "reasons": reasons, "recommended_action": "alert_and_review" if severity in ("MEDIUM", "HIGH") else "monitor"
    }
    alert_id = "pc_" + hashlib.sha256(json.dumps(result, sort_keys=True).encode()).hexdigest()[:12]
    db.add(PreContactAlert(alert_id=alert_id, source_node_id=source_node_id, target_node_id=target_node_id, tenant=tenant, risk_score=result["risk_score"], severity=severity, reasons_json=json.dumps(reasons)))
    db.commit()
    result["alert_id"] = alert_id
    return result

def recompute_behavior_memory(db, tenant="pilot_alpha4"):
    pilots = db.query(PilotUser).filter(PilotUser.tenant == tenant, PilotUser.active == True).all()
    for u in pilots:
        n = get_node(db, u.node_id, tenant=tenant)
        rels = neighbors(db, u.node_id, tenant)
        frequent_targets = []
        for r in rels:
            other = r.target if r.source == u.node_id else r.source
            frequent_targets.append({"node_id": other, "weight": r.weight})
        frequent_targets = sorted(frequent_targets, key=lambda x: x["weight"], reverse=True)[:5]
        base_hour = 9 + (abs(hash(u.node_id)) % 8)
        hours = sorted(list({base_hour, min(23, base_hour + 1), min(23, base_hour + 2), 19, 20}))
        row = ensure_behavior_row(db, u.node_id, tenant)
        row.avg_daily_pulses = round(max(1.0, n.pulse_count / 7.0), 2)
        row.avg_weekly_relays = round(sum(r.interaction_count for r in rels) / 2.0 if rels else 0.0, 2)
        row.frequent_targets_json = json.dumps(frequent_targets)
        row.active_hours_json = json.dumps(hours)
        row.last_7d_interactions = sum(r.interaction_count for r in rels)
        row.last_30d_interactions = sum(r.interaction_count for r in rels) * 2
        row.baseline_score = round(max(0, min(100, 40 + row.avg_daily_pulses * 5 + len(frequent_targets) * 4 + min(20, row.avg_weekly_relays * 1.5))), 2)
        row.updated_at = now_dt()
    db.commit()

def anomaly_check(db, node_id, hour_of_day, target_node_id, burst_events, tenant="pilot_alpha4"):
    row = ensure_behavior_row(db, node_id, tenant)
    active_hours = json.loads(row.active_hours_json or "[]")
    frequent_targets = [x["node_id"] for x in json.loads(row.frequent_targets_json or "[]")]
    hour_deviation = 0 if hour_of_day in active_hours else 100
    target_novelty = 0 if target_node_id in frequent_targets else 100
    expected = max(1.0, row.avg_daily_pulses)
    intensity_deviation = min(100, abs(burst_events - expected) / expected * 100)
    sequence_break = 70 if target_node_id not in frequent_targets and burst_events >= 3 else 20
    anomaly_score = round(0.35 * hour_deviation + 0.35 * target_novelty + 0.20 * intensity_deviation + 0.10 * sequence_break, 2)
    level = "NORMAL"
    if anomaly_score >= 60:
        level = "HIGH"
    elif anomaly_score >= 30:
        level = "MEDIUM"
    return {
        "node_id": node_id, "tenant": tenant, "hour_of_day": hour_of_day, "target_node_id": target_node_id,
        "burst_events": burst_events, "anomaly_score": anomaly_score, "level": level,
        "components": {
            "hour_deviation": hour_deviation,
            "target_novelty": target_novelty,
            "intensity_deviation": round(intensity_deviation, 2),
            "sequence_break": sequence_break
        }
    }

# ---------- heavy simulation plane ----------
SIM_SCENARIOS = {
    "family_scam_burst": {"attackers": 3, "targets": 24, "edge_probability": 0.05, "industry": "banking"},
    "marketplace_fraud_cluster": {"attackers": 5, "targets": 40, "edge_probability": 0.08, "industry": "marketplace"},
    "phishing_swarm": {"attackers": 8, "targets": 80, "edge_probability": 0.03, "industry": "messaging"},
    "deepfake_coercion_path": {"attackers": 2, "targets": 18, "edge_probability": 0.07, "industry": "banking"},
}

def simulate_attack(scenario_name: str):
    cfg = SIM_SCENARIOS[scenario_name]
    attackers = cfg["attackers"]
    targets = cfg["targets"]
    industry = cfg["industry"]

    # synthetic graph state
    compromised_targets = 0
    blocked = 0
    review = 0
    allowed = 0
    alerts = 0
    propagation_score = 0.0

    for t in range(targets):
        # create synthetic scores
        attacker_pressure = random.uniform(0.55, 0.98)
        shared_reality = random.uniform(5, 35)
        authority = random.uniform(20, 65)
        fraud_exposure = min(100, attackers * random.uniform(6, 10))
        behavior_risk = random.uniform(0.4, 0.95)

        rds = random.uniform(5, 35)
        ass = authority
        srs = shared_reality
        sc = max(0, 100 - ((attacker_pressure * 100 + behavior_risk * 100) / 2))
        fe = fraud_exposure

        trust_score = round((rds + ass + srs + sc) / 4 - fe, 2)
        if trust_score >= 80:
            decision = "VERIFY"
            allowed += 1
        elif trust_score >= 60:
            decision = "REVIEW"
            review += 1
            alerts += 1
        else:
            decision = "BLOCK"
            blocked += 1
            alerts += 1

        if decision == "VERIFY" and attacker_pressure > 0.8:
            compromised_targets += 1

        propagation_score += max(0, (100 - trust_score) * 0.1)

    detection_rate = round(((blocked + review) / max(1, targets)) * 100, 2)
    false_negative_rate = round((compromised_targets / max(1, targets)) * 100, 2)
    propagation_score = round(propagation_score, 2)

    return {
        "scenario": scenario_name,
        "config": cfg,
        "metrics": {
            "total_targets": targets,
            "attackers": attackers,
            "blocked": blocked,
            "review": review,
            "allowed": allowed,
            "alerts": alerts,
            "compromised_targets": compromised_targets,
            "detection_rate": detection_rate,
            "false_negative_rate": false_negative_rate,
            "propagation_score": propagation_score
        },
        "interpretation": {
            "summary": f"{scenario_name} produced {alerts} defensive signals across {targets} targets.",
            "note": "This engine runs in the heavy simulation plane and does not block the fast decision plane."
        }
    }

# ---------- seed ----------
def seed():
    db = SessionLocal()
    try:
        if db.query(Node).count():
            return
        # demo graph
        for nid, label in [("demo_1", "Demo A"), ("demo_2", "Demo B"), ("demo_3", "Demo C"), ("demo_4", "Demo D")]:
            db.add(Node(node_id=nid, label=label, tenant="demo", node_type="internal", trust_rank=random.randint(45, 80), nodal_mass=random.randint(15, 40)))
        for a, b, w, sr, c in [("demo_1", "demo_2", 70, 62, 5), ("demo_2", "demo_3", 58, 48, 4), ("demo_3", "demo_4", 46, 30, 3)]:
            db.add(Edge(source=a, target=b, tenant="demo", weight=w, shared_reality=sr, interaction_count=c))
        # pilot users
        pilots = [
            ("pu_001", "Manuel", "nd_manu_01", "ALPHA-MANUEL"),
            ("pu_002", "Ana", "nd_ana_01", "ALPHA-ANA"),
            ("pu_003", "Bruno", "nd_bruno_01", "ALPHA-BRUNO"),
            ("pu_004", "Carla", "nd_carla_01", "ALPHA-CARLA"),
        ]
        for pilot_user_id, display_name, node_id, invite_code in pilots:
            db.add(PilotUser(pilot_user_id=pilot_user_id, display_name=display_name, node_id=node_id, tenant="pilot_alpha4", invite_code=invite_code, active=True))
            db.add(Node(node_id=node_id, label=display_name, tenant="pilot_alpha4", node_type="mobile", trust_rank=random.randint(45, 80), nodal_mass=random.randint(15, 40), pulse_count=random.randint(3, 12), cross_pulse_count=random.randint(1, 5)))
        for a, b, w, sr, c in [("nd_manu_01", "nd_ana_01", 68, 60, 6), ("nd_manu_01", "nd_bruno_01", 56, 44, 4), ("nd_ana_01", "nd_bruno_01", 61, 49, 5), ("nd_bruno_01", "nd_carla_01", 52, 41, 3)]:
            db.add(Edge(source=a, target=b, tenant="pilot_alpha4", weight=w, shared_reality=sr, interaction_count=c))
        db.commit()
        recompute_guardians(db, "demo")
        recompute_guardians(db, "pilot_alpha4")
        recompute_spread(db, "demo")
        recompute_spread(db, "pilot_alpha4")
        recompute_behavior_memory(db, "pilot_alpha4")
    finally:
        db.close()

seed()

# ---------- request models ----------
class EvalIn(BaseModel):
    source_node_id: str
    target_node_id: str
    tenant: str = "demo"
    industry: str = "banking"
    amount_anomaly: float = 0.9
    routine_break: float = 0.8

class PulseIn(BaseModel):
    node_id: str
    tenant: str = "pilot_alpha4"

class RelayCreateIn(BaseModel):
    node_id: str
    tenant: str = "pilot_alpha4"

class RelayConfirmIn(BaseModel):
    node_id: str
    code: str
    tenant: str = "pilot_alpha4"
    shared_reality_boost: float = 8.0

class PreIn(BaseModel):
    source_node_id: str
    target_node_id: str
    tenant: str = "pilot_alpha4"
    source_type: str = "external"
    event_type: str = "contact_attempt"
    metadata: dict = {}

class InviteIn(BaseModel):
    invite_code: str

class RegisterDeviceIn(BaseModel):
    node_id: str
    device_label: str

class AnomalyIn(BaseModel):
    node_id: str
    tenant: str = "pilot_alpha4"
    hour_of_day: int
    target_node_id: str
    burst_events: int = 1

class SimulationIn(BaseModel):
    scenario: str

# ---------- pages ----------
@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("home.html", {"request": request})

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.get("/graph", response_class=HTMLResponse)
def graph_page(request: Request):
    return templates.TemplateResponse("graph.html", {"request": request})

@app.get("/demo", response_class=HTMLResponse)
def demo(request: Request):
    return templates.TemplateResponse("demo.html", {"request": request})

@app.get("/pilot", response_class=HTMLResponse)
def pilot(request: Request):
    return templates.TemplateResponse("pilot.html", {"request": request})

@app.get("/pilot/dashboard", response_class=HTMLResponse)
def pilot_dashboard(request: Request):
    return templates.TemplateResponse("pilot_dashboard.html", {"request": request})

@app.get("/pilot/onboarding", response_class=HTMLResponse)
def pilot_onboarding(request: Request):
    return templates.TemplateResponse("pilot_onboarding.html", {"request": request})

@app.get("/simulations", response_class=HTMLResponse)
def simulations(request: Request):
    return templates.TemplateResponse("simulations.html", {"request": request})

@app.get("/partner", response_class=HTMLResponse)
def partner(request: Request):
    return templates.TemplateResponse("partner.html", {"request": request})

@app.get("/sdk", response_class=HTMLResponse)
def sdk(request: Request):
    return templates.TemplateResponse("sdk.html", {"request": request})

@app.get("/deploy", response_class=HTMLResponse)
def deploy(request: Request):
    return templates.TemplateResponse("deploy.html", {"request": request})

@app.get("/mobile", response_class=HTMLResponse)
def mobile(request: Request):
    return templates.TemplateResponse("mobile_home.html", {"request": request})

@app.get("/mobile/relay", response_class=HTMLResponse)
def mobile_relay(request: Request):
    return templates.TemplateResponse("mobile_relay.html", {"request": request})

@app.get("/mobile/eval", response_class=HTMLResponse)
def mobile_eval(request: Request):
    return templates.TemplateResponse("mobile_eval.html", {"request": request})

@app.get("/mobile/audit", response_class=HTMLResponse)
def mobile_audit(request: Request):
    return templates.TemplateResponse("mobile_audit.html", {"request": request})

# ---------- fast APIs ----------
@app.get("/api/summary")
def api_summary(tenant: str = "demo"):
    db = SessionLocal()
    try:
        return {"tenant": tenant, "nodes": db.query(Node).filter(Node.tenant == tenant).count(), "evaluations": db.query(Evaluation).filter(Evaluation.tenant == tenant).count(), "alerts": db.query(PreContactAlert).filter(PreContactAlert.tenant == tenant).count()}
    finally:
        db.close()

@app.get("/api/graph")
def api_graph(tenant: str = "demo"):
    db = SessionLocal()
    try:
        return {"nodes": [{"node_id": n.node_id, "label": n.label, "tenant": n.tenant, "node_type": n.node_type, "industry": n.industry, "trust_rank": n.trust_rank, "nodal_mass": n.nodal_mass, "guardian_score": n.guardian_score, "fraud_exposure": n.fraud_exposure, "pulse_count": n.pulse_count, "cross_pulse_count": n.cross_pulse_count, "status": n.status} for n in db.query(Node).filter(Node.tenant == tenant).all()], "edges": [{"source": e.source, "target": e.target, "weight": e.weight, "shared_reality": e.shared_reality, "interaction_count": e.interaction_count, "tenant": e.tenant} for e in db.query(Edge).filter(Edge.tenant == tenant).all()]}
    finally:
        db.close()

@app.get("/api/node/{node_id}")
def api_node(node_id: str):
    db = SessionLocal()
    try:
        n = get_node(db, node_id)
        return {"node_id": n.node_id, "label": n.label, "tenant": n.tenant, "node_type": n.node_type, "industry": n.industry, "trust_rank": n.trust_rank, "nodal_mass": n.nodal_mass, "guardian_score": n.guardian_score, "fraud_exposure": n.fraud_exposure, "pulse_count": n.pulse_count, "cross_pulse_count": n.cross_pulse_count, "status": n.status}
    finally:
        db.close()

@app.post("/api/pulse")
def api_pulse(payload: PulseIn):
    db = SessionLocal()
    try:
        n = get_node(db, payload.node_id, tenant=payload.tenant, node_type="mobile", label=payload.node_id)
        n.pulse_count += 1
        n.nodal_mass = min(100, n.nodal_mass + 1)
        n.last_seen = now_dt()
        db.commit()
        recompute_behavior_memory(db, payload.tenant)
        return {"node_id": n.node_id, "pulse_count": n.pulse_count, "nodal_mass": n.nodal_mass}
    finally:
        db.close()

@app.post("/api/evaluate")
def api_evaluate(payload: EvalIn):
    db = SessionLocal()
    try:
        result = evaluate(db, payload.source_node_id, payload.target_node_id, payload.tenant, payload.industry, payload.amount_anomaly, payload.routine_break)
        eid = f"ev_{db.query(Evaluation).count()+1}"
        db.add(Evaluation(evaluation_id=eid, source_node_id=payload.source_node_id, target_node_id=payload.target_node_id, tenant=payload.tenant, decision=result["decision"], trust_score=result["trust_score"], breakdown_json=json.dumps(result)))
        db.commit()
        result["evaluation_id"] = eid
        return result
    finally:
        db.close()

@app.get("/api/evaluation/{evaluation_id}")
def api_evaluation(evaluation_id: str):
    db = SessionLocal()
    try:
        ev = db.query(Evaluation).filter(Evaluation.evaluation_id == evaluation_id).first()
        if not ev:
            return {"error": "not_found"}
        data = json.loads(ev.breakdown_json)
        data["evaluation_id"] = ev.evaluation_id
        return data
    finally:
        db.close()

@app.post("/api/relay/create")
def api_relay_create(payload: RelayCreateIn):
    db = SessionLocal()
    try:
        get_node(db, payload.node_id, tenant=payload.tenant, node_type="mobile", label=payload.node_id)
        code = str(random.randint(1000, 9999))
        db.merge(RelaySession(code=code, initiator=payload.node_id, tenant=payload.tenant))
        db.commit()
        return {"code": code, "initiator": payload.node_id}
    finally:
        db.close()

@app.post("/api/relay/confirm")
def api_relay_confirm(payload: RelayConfirmIn):
    db = SessionLocal()
    try:
        sess = db.query(RelaySession).filter(RelaySession.code == payload.code, RelaySession.tenant == payload.tenant).first()
        if not sess:
            return {"error": "invalid_code"}
        a, b = sess.initiator, payload.node_id
        edge = get_edge(db, a, b, payload.tenant)
        before = edge.weight if edge else 0
        if not edge:
            edge = Edge(source=a, target=b, tenant=payload.tenant, weight=25, shared_reality=20, interaction_count=0)
            db.add(edge)
        edge.weight = min(100, edge.weight + 8)
        edge.shared_reality = min(100, edge.shared_reality + payload.shared_reality_boost)
        edge.interaction_count += 1
        get_node(db, a, tenant=payload.tenant).cross_pulse_count += 1
        get_node(db, b, tenant=payload.tenant).cross_pulse_count += 1
        db.commit()
        recompute_behavior_memory(db, payload.tenant)
        return {"status": "confirmed", "node_a": a, "node_b": b, "relationship_weight_before": before, "relationship_weight_after": edge.weight, "shared_reality_after": edge.shared_reality}
    finally:
        db.close()

@app.post("/api/workers/run")
def api_workers_run(tenant: str = "demo"):
    db = SessionLocal()
    try:
        recompute_guardians(db, tenant)
        recompute_spread(db, tenant)
        if tenant == "pilot_alpha4":
            recompute_behavior_memory(db, tenant)
        return {"status": "ok", "tenant": tenant}
    finally:
        db.close()

@app.get("/api/demo-cases")
def api_demo_cases():
    return {
        "whatsapp_fake_relative": {"source_node_id": "demo_1", "target_node_id": "demo_4", "tenant": "demo", "industry": "banking", "amount_anomaly": 0.9, "routine_break": 0.8},
        "legit_qr_payment": {"source_node_id": "demo_2", "target_node_id": "demo_3", "tenant": "demo", "industry": "marketplace", "amount_anomaly": 0.1, "routine_break": 0.1}
    }

@app.post("/api/demo/run/{case_name}")
def api_demo_run(case_name: str):
    cases = api_demo_cases()
    if case_name not in cases:
        return {"error": "unknown_case"}
    return api_evaluate(EvalIn(**cases[case_name]))

@app.get("/api/pilot/users")
def api_pilot_users():
    db = SessionLocal()
    try:
        rows = db.query(PilotUser).filter(PilotUser.tenant == "pilot_alpha4").all()
        return [{"pilot_user_id": r.pilot_user_id, "display_name": r.display_name, "node_id": r.node_id, "tenant": r.tenant, "invite_code": r.invite_code, "active": r.active, "linked_device_label": r.linked_device_label} for r in rows]
    finally:
        db.close()

@app.get("/api/pilot/behavior/{node_id}")
def api_pilot_behavior(node_id: str):
    db = SessionLocal()
    try:
        row = ensure_behavior_row(db, node_id, "pilot_alpha4")
        return {
            "node_id": row.node_id,
            "tenant": row.tenant,
            "avg_daily_pulses": row.avg_daily_pulses,
            "avg_weekly_relays": row.avg_weekly_relays,
            "frequent_targets": json.loads(row.frequent_targets_json or "[]"),
            "active_hours": json.loads(row.active_hours_json or "[]"),
            "last_7d_interactions": row.last_7d_interactions,
            "last_30d_interactions": row.last_30d_interactions,
            "baseline_score": row.baseline_score,
            "updated_at": row.updated_at.isoformat() if row.updated_at else None
        }
    finally:
        db.close()

@app.post("/api/pilot/behavior/recompute")
def api_behavior_recompute():
    db = SessionLocal()
    try:
        recompute_behavior_memory(db, "pilot_alpha4")
        return {"status": "ok", "tenant": "pilot_alpha4"}
    finally:
        db.close()

@app.post("/api/pilot/anomaly/check")
def api_anomaly_check(payload: AnomalyIn):
    db = SessionLocal()
    try:
        recompute_behavior_memory(db, payload.tenant)
        return anomaly_check(db, payload.node_id, payload.hour_of_day, payload.target_node_id, payload.burst_events, payload.tenant)
    finally:
        db.close()

@app.post("/api/pilot/resolve-invite")
def api_resolve_invite(payload: InviteIn):
    db = SessionLocal()
    try:
        u = db.query(PilotUser).filter(PilotUser.invite_code == payload.invite_code, PilotUser.active == True).first()
        if not u:
            return {"ok": False, "error": "invalid_invite_code"}
        return {"ok": True, "display_name": u.display_name, "node_id": u.node_id, "tenant": u.tenant}
    finally:
        db.close()

@app.post("/api/pilot/register-device")
def api_register_device(payload: RegisterDeviceIn):
    db = SessionLocal()
    try:
        u = db.query(PilotUser).filter(PilotUser.node_id == payload.node_id).first()
        if not u:
            return {"ok": False, "error": "unknown_node"}
        u.linked_device_label = payload.device_label
        db.commit()
        return {"ok": True, "display_name": u.display_name, "node_id": u.node_id, "linked_device_label": u.linked_device_label}
    finally:
        db.close()

@app.post("/api/pilot/precontact/attempt")
def api_precontact_attempt(payload: PreIn):
    db = SessionLocal()
    try:
        get_node(db, payload.source_node_id, tenant=payload.tenant, node_type=payload.source_type, label=payload.source_node_id)
        get_node(db, payload.target_node_id, tenant=payload.tenant, node_type="mobile", label=payload.target_node_id)
        db.add(ContactEvent(source_node_id=payload.source_node_id, target_node_id=payload.target_node_id, tenant=payload.tenant, event_type=payload.event_type, metadata_json=json.dumps(payload.metadata)))
        db.commit()
        return precontact_eval(db, payload.source_node_id, payload.target_node_id, payload.tenant)
    finally:
        db.close()

@app.get("/api/pilot/precontact/alerts")
def api_pilot_alerts(tenant: str = "pilot_alpha4"):
    db = SessionLocal()
    try:
        rows = db.query(PreContactAlert).filter(PreContactAlert.tenant == tenant).order_by(PreContactAlert.id.desc()).all()
        return [{"alert_id": r.alert_id, "source_node_id": r.source_node_id, "target_node_id": r.target_node_id, "risk_score": r.risk_score, "severity": r.severity, "reasons": json.loads(r.reasons_json), "created_at": r.created_at.isoformat()} for r in rows]
    finally:
        db.close()

@app.get("/api/pilot/precontact/summary")
def api_pilot_summary(tenant: str = "pilot_alpha4"):
    db = SessionLocal()
    try:
        return {"tenant": tenant, "nodes": db.query(Node).filter(Node.tenant == tenant).count(), "internal_nodes": db.query(Node).filter(Node.tenant == tenant, Node.node_type != "external").count(), "external_nodes": db.query(Node).filter(Node.tenant == tenant, Node.node_type == "external").count(), "contact_events": db.query(ContactEvent).filter(ContactEvent.tenant == tenant).count(), "alerts": db.query(PreContactAlert).filter(PreContactAlert.tenant == tenant).count()}
    finally:
        db.close()

@app.post("/api/pilot/reset")
def api_pilot_reset(tenant: str = "pilot_alpha4"):
    db = SessionLocal()
    try:
        db.query(ContactEvent).filter(ContactEvent.tenant == tenant).delete()
        db.query(PreContactAlert).filter(PreContactAlert.tenant == tenant).delete()
        db.commit()
        return {"status": "reset_ok"}
    finally:
        db.close()

# ---------- heavy simulation APIs ----------
@app.get("/api/simulations/scenarios")
def api_simulation_scenarios():
    return SIM_SCENARIOS

@app.post("/api/simulations/run")
def api_simulation_run(payload: SimulationIn):
    db = SessionLocal()
    try:
        if payload.scenario not in SIM_SCENARIOS:
            return {"error": "unknown_scenario"}
        result = simulate_attack(payload.scenario)
        run_id = "sim_" + hashlib.sha256((payload.scenario + str(now_dt())).encode()).hexdigest()[:12]
        db.add(SimulationRun(run_id=run_id, scenario=payload.scenario, tenant="sim_lab", status="completed", config_json=json.dumps(SIM_SCENARIOS[payload.scenario]), results_json=json.dumps(result)))
        db.commit()
        result["run_id"] = run_id
        result["plane"] = "heavy_simulation"
        return result
    finally:
        db.close()

@app.get("/api/simulations/results")
def api_simulation_results():
    db = SessionLocal()
    try:
        rows = db.query(SimulationRun).order_by(SimulationRun.created_at.desc()).all()
        return [{
            "run_id": r.run_id,
            "scenario": r.scenario,
            "status": r.status,
            "created_at": r.created_at.isoformat() if r.created_at else None,
            "results": json.loads(r.results_json)
        } for r in rows]
    finally:
        db.close()

@app.post("/api/simulations/reset")
def api_simulation_reset():
    db = SessionLocal()
    try:
        db.query(SimulationRun).delete()
        db.commit()
        return {"status": "reset_ok"}
    finally:
        db.close()

@app.get("/api/platform-profile")
def api_platform_profile():
    return {
        "version": "v15_attack_simulation",
        "fast_decision_plane": ["evaluate", "relay", "node", "precontact", "behavior", "anomaly check"],
        "heavy_simulation_plane": ["simulations/run", "simulations/results", "simulations/reset"],
        "pilot_tenant": "pilot_alpha4",
        "simulation_layer": True
    }
