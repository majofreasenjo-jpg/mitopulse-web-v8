
# MitoPulse v15 — Attack Simulation Engine

Esta versión separa explícitamente:

## Fast Decision Plane
- /api/evaluate
- /api/relay/create
- /api/relay/confirm
- /api/pilot/precontact/attempt
- /api/pilot/anomaly/check
- /api/pilot/behavior/{node_id}

## Heavy Simulation Plane
- /api/simulations/run
- /api/simulations/results
- /api/simulations/reset

## Ejecutar local
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```
