
# Manual de uso — MitoPulse v15

1. Vincula un piloto en /pilot/onboarding con uno de estos códigos:
   - ALPHA-MANUEL
   - ALPHA-ANA
   - ALPHA-BRUNO
   - ALPHA-CARLA

2. Usa /mobile para emitir pulses, relays y evaluaciones.

3. Usa /pilot/dashboard para revisar:
   - behavior memory
   - anomaly check
   - pre-contact alerts

4. Usa /simulations para correr ataques simulados en el plano pesado:
   - family_scam_burst
   - marketplace_fraud_cluster
   - phishing_swarm
   - deepfake_coercion_path

5. Verifica que la simulación no afecta el plano rápido. Ese es el objetivo de esta versión.
