
# MitoPulse v4 Institutional MVP

Actualización completa de desarrollo sobre la línea anterior.

## Incluye
- plataforma modular
- piloto real con Manuel, Natalie, Paulina y Ricardo
- guardian nodes
- trust propagation
- relational identity
- pre-contact risk
- fraud spread / cluster risk
- cross-pulse
- simulación de ataques
- dashboard web institucional

## Ejecutar
```bash
pip install -r requirements.txt
python run.py
```

o

```bash
uvicorn app.main:app --reload
```

## Abrir
http://127.0.0.1:8000
