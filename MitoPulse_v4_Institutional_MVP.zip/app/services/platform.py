
import json
import random
import uuid
from sqlalchemy.orm import Session
from app.models.schema import Node, Edge, Alert, Event, CrossPulse

PILOT_USERS = [
    ("nd_manuel_01", "Manuel", 1),
    ("nd_natalie_01", "Natalie", 1),
    ("nd_paulina_01", "Paulina", 0),
    ("nd_ricardo_01", "Ricardo", 0),
]

def ensure_node(db: Session, node_id: str, label: str | None = None, node_type: str = "pilot", cluster: str = "pilot_seed", is_guardian: int = 0) -> Node:
    row = db.get(Node, node_id)
    if not row:
        row = Node(
            node_id=node_id,
            label=label or node_id,
            node_type=node_type,
            cluster=cluster,
            is_guardian=is_guardian
        )
        db.add(row)
        db.commit()
        db.refresh(row)
    return row

def add_event(db: Session, event_type: str, payload: dict):
    db.add(Event(event_type=event_type, payload_json=json.dumps(payload)))
    db.commit()

def recompute_scores(db: Session):
    rows = db.query(Node).all()
    edges = db.query(Edge).all()
    degree = {}
    contexts = {}
    kinds = {}
    for e in edges:
        degree[e.source] = degree.get(e.source, 0) + 1
        degree[e.target] = degree.get(e.target, 0) + 1
        contexts.setdefault(e.source, set()).add(e.context)
        contexts.setdefault(e.target, set()).add(e.context)
        kinds.setdefault(e.source, set()).add(e.interaction_type)
        kinds.setdefault(e.target, set()).add(e.interaction_type)
    for n in rows:
        d = degree.get(n.node_id, 0)
        trust = 0.38 + min(0.40, d * 0.08) - min(0.30, n.risk_score * 0.35)
        if n.is_guardian:
            trust += 0.06
        ident = 0.25 + min(0.28, d * 0.06) + min(0.16, len(contexts.get(n.node_id, set())) * 0.05) + min(0.14, len(kinds.get(n.node_id, set())) * 0.04)
        if n.is_guardian:
            ident += 0.10
        n.trust_score = round(max(0.05, min(0.98, trust)), 3)
        n.identity_confidence = round(max(0.05, min(0.98, ident)), 3)
    db.commit()

def bootstrap_pilot(db: Session, cluster: str = "pilot_seed"):
    db.query(Alert).delete()
    db.query(Event).delete()
    db.query(CrossPulse).delete()
    db.query(Edge).delete()
    db.query(Node).delete()
    db.commit()

    for nid, label, guardian in PILOT_USERS:
        ensure_node(db, nid, label, "pilot", cluster, guardian)

    base_edges = [
        ("nd_manuel_01", "nd_natalie_01", "whatsapp_message", "general", 0.95),
        ("nd_manuel_01", "nd_ricardo_01", "call", "general", 0.90),
        ("nd_natalie_01", "nd_paulina_01", "whatsapp_message", "general", 0.88),
        ("nd_ricardo_01", "nd_paulina_01", "in_person", "general", 0.97),
        ("nd_manuel_01", "nd_natalie_01", "bank_transfer", "general", 0.92),
    ]
    for s, t, it, ctx, weight in base_edges:
        db.add(Edge(source=s, target=t, interaction_type=it, context=ctx, weight=weight))
    db.commit()
    recompute_scores(db)
    add_event(db, "bootstrap", {"cluster": cluster, "users": [x[0] for x in PILOT_USERS]})

def capture_interaction(db: Session, source: str, target: str, interaction_type: str, context: str, weight: float = 1.0):
    ensure_node(db, source, source, "pilot" if source.startswith("nd_") else "external")
    ensure_node(db, target, target, "pilot" if target.startswith("nd_") else "external")
    db.add(Edge(source=source, target=target, interaction_type=interaction_type, context=context, weight=weight))
    db.commit()
    recompute_scores(db)
    add_event(db, "interaction", {"source": source, "target": target, "interaction_type": interaction_type, "context": context, "weight": weight})

def create_crosspulse(db: Session, source: str, target: str, reason: str):
    ensure_node(db, source, source)
    ensure_node(db, target, target)
    pulse_id = "cp_" + uuid.uuid4().hex[:10]
    db.add(CrossPulse(pulse_id=pulse_id, source=source, target=target, reason=reason, status="confirmed"))
    db.add(Edge(source=source, target=target, interaction_type="cross_pulse", context=reason, weight=0.99))
    db.commit()
    recompute_scores(db)
    add_event(db, "cross_pulse", {"pulse_id": pulse_id, "source": source, "target": target, "reason": reason})
    return pulse_id

def simulate_attack(db: Session, attack_type: str):
    attacker = ensure_node(db, "ext_attacker_01", "Attacker X", "external")
    attacker.risk_score = max(attacker.risk_score, 0.78)
    scenarios = {
        "number_change": (["nd_natalie_01", "nd_ricardo_01"], "Hola, cambié mi número. Necesito ayuda urgente."),
        "marketplace": (["nd_ricardo_01"], "Ya transferí. Revisa el comprobante y envía el producto."),
        "wallet": (["nd_paulina_01"], "Firma esta solicitud urgente ahora."),
    }
    targets, message = scenarios.get(attack_type, scenarios["number_change"])
    out = []
    for tgt in targets:
        node = ensure_node(db, tgt, tgt)
        risk = round(random.uniform(0.72, 0.95), 3)
        node.risk_score = max(node.risk_score, round(risk * 0.60, 3))
        cluster_risk = min(0.95, round(node.risk_score + 0.18, 3))
        decision = "BLOCK" if risk >= 0.80 else "REVIEW"
        alert = Alert(source=attacker.node_id, target=tgt, attack_type=attack_type, risk_score=risk, cluster_risk=cluster_risk, guardian_decision=decision, message=message)
        db.add(alert)
        out.append({"target": tgt, "risk_score": risk, "cluster_risk": cluster_risk, "guardian_decision": decision, "message": message})
    db.commit()
    recompute_scores(db)
    add_event(db, "attack", {"attack_type": attack_type, "targets": targets})
    return out

def get_state(db: Session):
    nodes = db.query(Node).all()
    edges = db.query(Edge).all()
    alerts = db.query(Alert).order_by(Alert.id.desc()).limit(20).all()
    events = db.query(Event).order_by(Event.id.desc()).limit(30).all()
    pulses = db.query(CrossPulse).order_by(CrossPulse.created_at.desc()).limit(20).all()
    return {
        "nodes": [{
            "id": n.node_id, "label": n.label, "type": n.node_type, "cluster": n.cluster,
            "trust_score": n.trust_score, "risk_score": n.risk_score,
            "identity_confidence": n.identity_confidence, "is_guardian": n.is_guardian,
            "status": n.status
        } for n in nodes],
        "edges": [{
            "source": e.source, "target": e.target, "interaction_type": e.interaction_type,
            "context": e.context, "weight": e.weight
        } for e in edges],
        "alerts": [{
            "source": a.source, "target": a.target, "attack_type": a.attack_type,
            "risk_score": a.risk_score, "cluster_risk": a.cluster_risk,
            "guardian_decision": a.guardian_decision, "message": a.message
        } for a in alerts],
        "events": [{
            "event_type": e.event_type, "payload": json.loads(e.payload_json),
            "created_at": e.created_at.isoformat() + "Z"
        } for e in events],
        "cross_pulses": [{
            "pulse_id": p.pulse_id, "source": p.source, "target": p.target,
            "reason": p.reason, "status": p.status
        } for p in pulses]
    }
