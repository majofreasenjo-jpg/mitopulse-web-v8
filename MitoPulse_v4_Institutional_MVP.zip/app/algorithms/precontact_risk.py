
def precontact_risk(node_exists: bool, identity_score: float, propagated_trust: float, own_risk: float, context: str):
    risk = 0.68
    if node_exists:
        risk -= identity_score * 0.30
        risk -= propagated_trust * 0.26
        risk += own_risk * 0.34
    if context in ("financial_request", "urgent_transfer", "signature_request"):
        risk += 0.10
    return round(max(0.01, min(0.99, risk)), 3)
