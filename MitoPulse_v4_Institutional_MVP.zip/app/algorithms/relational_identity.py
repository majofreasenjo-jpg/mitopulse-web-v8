
import networkx as nx

def relational_identity_score(graph: nx.Graph, node: str):
    if node not in graph:
        return {"score": 0.0, "signals": ["unknown_identity"]}
    degree = graph.degree(node)
    neighbors = list(graph.neighbors(node))
    diversity = len(set(neighbors))
    types = set()
    contexts = set()
    for n in neighbors:
        data = graph[node][n]
        types.add(data.get("interaction_type", "unknown"))
        contexts.add(data.get("context", "general"))
    score = 0.22 + min(0.32, degree * 0.07) + min(0.18, len(types) * 0.05) + min(0.18, len(contexts) * 0.05)
    if graph.nodes[node].get("is_guardian"):
        score += 0.08
    score = round(max(0.0, min(0.98, score)), 3)
    confidence = "high" if score >= 0.78 else "medium" if score >= 0.48 else "low"
    signals = []
    if degree >= 3: signals.append("multi_edge_history")
    if len(types) >= 2: signals.append("channel_diversity")
    if len(contexts) >= 2: signals.append("context_diversity")
    if graph.nodes[node].get("is_guardian"): signals.append("guardian_anchor")
    if not signals: signals.append("weak_relational_history")
    return {"score": score, "confidence": confidence, "signals": signals}
