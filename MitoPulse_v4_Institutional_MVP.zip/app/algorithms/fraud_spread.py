
import networkx as nx

def cluster_risk(graph: nx.Graph, node: str):
    if node not in graph:
        return 0.95
    neighbors = list(graph.neighbors(node))
    degree = len(neighbors)
    external_links = 0
    suspicious_neighbors = 0
    for n in neighbors:
        if graph.nodes[n].get("risk_score", 0) >= 0.35:
            suspicious_neighbors += 1
        if graph.degree(n) <= 2:
            external_links += 1
    base = 0.18
    base += min(0.22, suspicious_neighbors * 0.08)
    base += min(0.18, external_links * 0.05)
    if degree <= 1:
        base += 0.20
    return round(max(0.02, min(0.99, base)), 3)
