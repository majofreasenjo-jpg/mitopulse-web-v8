
import networkx as nx

def build_graph(nodes, edges):
    g = nx.Graph()
    for n in nodes:
        g.add_node(
            n["id"],
            trust_score=n["trust_score"],
            risk_score=n["risk_score"],
            identity_confidence=n["identity_confidence"],
            is_guardian=n["is_guardian"],
            label=n["label"]
        )
    for e in edges:
        g.add_edge(
            e["source"],
            e["target"],
            weight=e["weight"],
            interaction_type=e["interaction_type"],
            context=e["context"]
        )
    return g
