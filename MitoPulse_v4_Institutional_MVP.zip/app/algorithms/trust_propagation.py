
import networkx as nx

def compute_trust(graph: nx.Graph, start_node: str, max_depth: int = 3):
    if start_node not in graph:
        return {}
    scores = {}
    for node in graph.nodes():
        try:
            path = nx.shortest_path(graph, start_node, node)
        except Exception:
            continue
        depth = len(path) - 1
        if depth > max_depth:
            continue
        trust = 1.0
        for i in range(len(path)-1):
            edge_data = graph[path[i]][path[i+1]]
            trust *= edge_data.get("weight", 1.0)
            trust *= 0.88
        scores[node] = round(max(0.0, min(1.0, trust)), 3)
    return scores
