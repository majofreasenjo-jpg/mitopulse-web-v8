
# MitoPulse v4 Architecture

## Core scoring
Decision score combines:

- propagated trust
- relational identity
- own node risk
- cluster risk
- sensitive context risk

## New modules
1. Trust Propagation
2. Relational Identity
3. Pre-Contact Risk
4. Fraud Spread / Cluster Risk
5. Guardian Nodes

## Recommended next steps
- PostgreSQL
- Redis cache
- API keys and auth
- tenant isolation
- institutional connectors
