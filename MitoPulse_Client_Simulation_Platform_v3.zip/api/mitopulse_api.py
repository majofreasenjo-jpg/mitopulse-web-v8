from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from simulator.client_dataset_builder import make_dataset
from ingestion.client_data_loader import load_client_folder, dataset_profile
from engine.graph_builder import build_graph
from engine.cluster_detector import suspicious_clusters
from engine.risk_engine import decision_projection

app = FastAPI(title="MitoPulse Client Simulation Platform v3")
templates = Jinja2Templates(directory="templates")
LAST = {}

def run_pipeline(folder: str):
    customers, devices, events, signals = load_client_folder(folder)
    profile = dataset_profile(customers, devices, events, signals)
    G = build_graph(customers, devices, events, signals)
    clusters = suspicious_clusters(G)
    decisions = decision_projection(G)

    nodes = []
    for i, (n, attrs) in enumerate(G.nodes(data=True)):
        if i >= 90: break
        nodes.append({"id": n, "group": attrs.get("node_type", "unknown")})
    edges = []
    for i, (a, b, data) in enumerate(G.edges(data=True)):
        if i >= 180: break
        edges.append({"source": a, "target": b, "type": data.get("label", data.get("edge_type", "edge")), "context": data.get("context", "general")})

    return {
        "dataset_profile": profile,
        "graph_stats": {"nodes": G.number_of_nodes(), "edges": G.number_of_edges()},
        "clusters": clusters[:10],
        "decision_projection": decisions,
        "graph_preview": {"nodes": nodes, "edges": edges}
    }

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.get("/api/generate")
def generate(client_type: str = "bank"):
    out = f"data/generated_{client_type}"
    generation = make_dataset(out, client_type)
    result = run_pipeline(out)
    result["generation"] = generation
    result["storage_model"] = {
        "web_ui": "solo interfaz y API",
        "uploaded_data": out,
        "processing": "backend local o cloud privado",
        "database_recommendation": "PostgreSQL para producción; CSV/Parquet para demo"
    }
    global LAST
    LAST = result
    return result

@app.get("/api/load-sample")
def load_sample(client_type: str = "bank"):
    folder = f"data/sample_{client_type}"
    result = run_pipeline(folder)
    result["sample_folder"] = folder
    global LAST
    LAST = result
    return result

@app.get("/api/last")
def last():
    return LAST

@app.get("/api/how-client-data-is-built")
def how_built():
    return {
        "bank": {
            "files": ["customers.csv", "devices.csv", "events.csv", "signals.csv"],
            "minimal_columns": {
                "customers.csv": ["customer_id"],
                "devices.csv": ["device_id", "customer_id"],
                "events.csv": ["event_id", "source_id", "target_id", "event_type", "context", "amount"],
                "signals.csv": ["signal_id", "entity_id", "signal_type", "severity"]
            }
        },
        "principle": "No cargar nombre, teléfono o email en claro. Usar hashes o IDs internos."
    }
