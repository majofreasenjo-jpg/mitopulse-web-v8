# MitoPulse Client Simulation Platform v3

Esta versión responde dos preguntas clave:
1. ¿Todo queda en la web?
2. ¿Cómo se arma la base de datos tipo cliente?

## Respuesta corta
- La web es solo la interfaz.
- La ingesta, el procesamiento y la base viven en el backend.
- Para demo usamos carpetas CSV por cliente.
- Para producción conviene PostgreSQL + almacenamiento seguro.

## Estructura tipo cliente
Cada cliente entrega una carpeta con:
- customers.csv
- devices.csv
- events.csv
- signals.csv

## Principio de privacidad
No cargar nombre, teléfono o email en claro.
Usar hashes o IDs internos.

## Ejecutar
```bash
pip install -r requirements.txt
python run.py
```

Abrir:
`http://127.0.0.1:8000`
