# Cómo se arma la base tipo cliente

## Banco
### customers.csv
- customer_id
- name_hash
- phone_hash
- email_hash
- segment
- region
- created_at

### devices.csv
- device_id
- customer_id
- device_hash
- channel
- risk_hint

### events.csv
- event_id
- source_id
- target_id
- event_type
- context
- amount
- label
- timestamp

### signals.csv
- signal_id
- entity_id
- signal_type
- severity
- source
- timestamp

## Regla general
La base no se piensa primero como tabla transaccional clásica.
Se piensa como:
- identidades
- dispositivos
- eventos
- señales
para luego construir el grafo relacional.
