MitoPulse v13 Global Trust Prototype

Run:

pip install -r requirements.txt
python run.py

Demo endpoint:

http://127.0.0.1:8000/demo
