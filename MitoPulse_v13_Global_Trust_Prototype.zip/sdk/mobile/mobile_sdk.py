class MitoPulseSDK:

    def verify_interaction(self,user_a,user_b):

        return {
            "interaction":f"{user_a}->{user_b}",
            "risk_score":0.42,
            "decision":"REVIEW"
        }
