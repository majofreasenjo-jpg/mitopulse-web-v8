signals = []

def publish_signal(actor_hash, counterparty_hash, signal_type, severity):

    signal = {
        "actor": actor_hash,
        "counterparty": counterparty_hash,
        "type": signal_type,
        "severity": severity
    }

    signals.append(signal)
    return signal


def query_signals(hash_value):

    related = [s for s in signals if s["actor"] == hash_value or s["counterparty"] == hash_value]

    if not related:
        return {"shared_signals":0,"max_severity":0}

    max_severity = max([s["severity"] for s in related])

    return {
        "shared_signals": len(related),
        "max_severity": max_severity
    }
