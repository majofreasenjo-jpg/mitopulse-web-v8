import networkx as nx

class TrustGraph:

    def __init__(self):
        self.G = nx.Graph()

    def add_interaction(self,a,b):
        self.G.add_edge(a,b)

    def cluster(self,node):

        neighbors=list(self.G.neighbors(node))

        return {
            "node":node,
            "connections":len(neighbors),
            "neighbors":neighbors
        }
