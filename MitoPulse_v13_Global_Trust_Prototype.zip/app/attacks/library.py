ATTACKS = [
"social_engineering",
"fake_receipt",
"mule_network",
"identity_takeover",
"romance_scam",
"wallet_drainer",
"supplier_account_change"
]
