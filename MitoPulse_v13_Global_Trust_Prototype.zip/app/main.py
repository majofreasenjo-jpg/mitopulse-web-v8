from fastapi import FastAPI
from app.api.routes import router

app = FastAPI(title="MitoPulse v13 Global Trust Prototype")
app.include_router(router)
