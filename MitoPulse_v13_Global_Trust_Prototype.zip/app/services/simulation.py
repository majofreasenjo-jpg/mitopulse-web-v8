from app.network.shared_signal import publish_signal, query_signals

def simulate_demo():

    publish_signal("hash_a","hash_b","social_engineering",0.82)
    publish_signal("hash_c","hash_b","fake_receipt",0.63)

    result = query_signals("hash_b")

    return {
        "demo":"multi-institution signal propagation",
        "query_hash":"hash_b",
        "signals_detected": result
    }
