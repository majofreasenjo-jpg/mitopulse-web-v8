def risk_score(identity, cluster, shared):

    score = 0.2

    score += identity * 0.3
    score += cluster * 0.2
    score += shared * 0.5

    if score > 1:
        score = 1

    return score
