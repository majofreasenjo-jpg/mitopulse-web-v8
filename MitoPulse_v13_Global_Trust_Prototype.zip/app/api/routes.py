from fastapi import APIRouter
from app.services.simulation import simulate_demo

router = APIRouter()

@router.get("/demo")
def demo():
    return simulate_demo()
