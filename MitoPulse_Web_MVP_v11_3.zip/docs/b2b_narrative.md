
# B2B narrative

MitoPulse integrates as:
client app -> MitoPulse SDK -> client backend -> MitoPulse API -> decision response

Target customers:
- banks
- fintech
- marketplaces
- wallets
