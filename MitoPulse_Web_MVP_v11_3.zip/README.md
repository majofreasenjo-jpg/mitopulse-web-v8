
# MitoPulse v11.3

Independent release focused on:
- guided demo for partners/investors
- clearer B2B positioning
- cloud-only deployment path

## Recommended deployment
- Render / Railway / Fly.io
- Managed PostgreSQL (Neon / Supabase)
- Cloudflare for domain and DNS
