
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from datetime import datetime
import hashlib, json, os, random

app = FastAPI(title="MitoPulse v11.3 Cloud-Ready")
templates = Jinja2Templates(directory="templates")

APP_MODE = os.getenv("APP_MODE", "cloud")
DATABASE_URL = os.getenv("DATABASE_URL", "")
DEMO_MODE = os.getenv("DEMO_MODE", "true").lower() == "true"

nodes = {}
relationships = {}
evaluations = []
cross_pulses = []
fraud_flags = set()
guardian_log = []

def now():
    return datetime.utcnow().isoformat()

def rel_key(a,b):
    return "::".join(sorted([a,b]))

def ensure_node(node_id, user_id=None):
    if node_id not in nodes:
        nodes[node_id] = {
            "node_id": node_id,
            "user_id": user_id or node_id.replace("node_", "usr_"),
            "pulse_count": 0,
            "cross_pulse_count": 0,
            "last_seen_at": None,
            "nodal_mass": 10.0,
            "trust_rank": 50.0,
            "status": "healthy",
            "guardian_score": 0.0,
            "is_guardian": False,
            "fraud_exposure": 0.0,
            "created_at": now(),
        }
    return nodes[node_id]

def ensure_relationship(a,b):
    k = rel_key(a,b)
    if k not in relationships:
        relationships[k] = {
            "a": a, "b": b, "weight": 20.0, "interactions": 0,
            "shared_reality_avg": 0.0, "last_interaction_at": None
        }
    return relationships[k]

def calculate_guardian_score(node_id):
    node = nodes[node_id]
    rels = [r for r in relationships.values() if node_id in (r["a"], r["b"])]
    degree = len(rels)
    avg_weight = sum(r["weight"] for r in rels) / degree if degree else 0
    pulse_factor = min(100, node["pulse_count"]*2)
    cross_factor = min(100, node["cross_pulse_count"]*4)
    stability = min(100, degree*8 + avg_weight*0.4)
    score = (
        0.18*stability +
        0.18*node["trust_rank"] +
        0.15*min(100, node["nodal_mass"]) +
        0.12*pulse_factor +
        0.17*cross_factor +
        0.20*(100-node["fraud_exposure"])
    )
    node["guardian_score"] = round(score,2)
    node["is_guardian"] = score >= 72 and node["fraud_exposure"] < 25 and degree >= 2
    return node["guardian_score"]

def update_all_guardians():
    for node_id in list(nodes.keys()):
        before = nodes[node_id]["is_guardian"]
        score = calculate_guardian_score(node_id)
        after = nodes[node_id]["is_guardian"]
        if before != after:
            guardian_log.append({"node_id": node_id, "guardian": after, "score": score, "time": now()})

def calculate_fraud_exposure(node_id):
    base = 0.0
    for r in relationships.values():
        if node_id in (r["a"], r["b"]):
            other = r["b"] if r["a"] == node_id else r["a"]
            if other in fraud_flags:
                base += min(25, r["weight"] * 0.4)
            base += nodes.get(other, {}).get("fraud_exposure", 0) * 0.05
    nodes[node_id]["fraud_exposure"] = round(min(100, base), 2)
    return nodes[node_id]["fraud_exposure"]

def update_status(node_id):
    e = nodes[node_id]["fraud_exposure"]
    nodes[node_id]["status"] = "quarantined" if e >= 70 else "high_risk" if e >= 45 else "monitored" if e >= 20 else "healthy"

def compute_breakdown(source, target, amount_anomaly, routine_break, industry):
    rel = relationships.get(rel_key(source,target))
    tgt = ensure_node(target)
    rds = min(100, rel["weight"]) if rel else 0
    ass = round((tgt["guardian_score"]*0.5) + (min(100,tgt["nodal_mass"])*0.25) + (min(100,tgt["trust_rank"])*0.25), 2)
    srs = round(min(100, 30 + tgt["cross_pulse_count"]*5 + (15 if rel else 0)), 2)
    novelty = 100 if not rel else max(0, 100-rel["weight"])
    sc = round(max(0, 100 - ((amount_anomaly*100 + routine_break*100 + novelty)/3)), 2)
    fe = round(tgt["fraud_exposure"],2)
    trust = round(0.25*rds + 0.25*ass + 0.25*srs + 0.25*sc - fe, 2)
    decision = "VERIFY" if trust >= 80 else "REVIEW" if trust >= 60 else "BLOCK"
    action = "allow" if decision=="VERIFY" else "step_up_authentication"
    reason = "supportive relationship and low exposure" if decision=="VERIFY" else "moderate support or moderate exposure" if decision=="REVIEW" else "low support and/or high fraud exposure"
    return {
        "rds": round(rds,2), "ass": round(ass,2), "srs": round(srs,2), "sc": round(sc,2), "fe": round(fe,2),
        "trust_score": trust, "decision": decision, "recommended_action": action, "industry": industry,
        "reason": reason
    }

def receipt(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True).encode()).hexdigest()[:24]

def seed():
    if nodes: return
    for i in range(1,18):
        ensure_node(f"node_{i}")
        nodes[f"node_{i}"]["pulse_count"] = random.randint(3,18)
        nodes[f"node_{i}"]["cross_pulse_count"] = random.randint(1,14)
        nodes[f"node_{i}"]["nodal_mass"] = random.randint(20,95)
        nodes[f"node_{i}"]["trust_rank"] = random.randint(35,92)
    edges = [
        ("node_1","node_2",80),("node_1","node_3",72),("node_2","node_4",55),("node_3","node_5",48),
        ("node_5","node_10",35),("node_9","node_10",88),("node_8","node_9",61),("node_4","node_6",58),
        ("node_6","node_7",64),("node_7","node_8",51),("node_11","node_12",77),("node_12","node_13",69),
        ("node_13","node_14",44),("node_11","node_14",57),("node_15","node_16",62),("node_16","node_17",53)
    ]
    for a,b,w in edges:
        r = ensure_relationship(a,b)
        r["weight"] = w
        r["interactions"] = random.randint(2,20)
        r["shared_reality_avg"] = random.randint(30,90)
        r["last_interaction_at"] = now()
    fraud_flags.update(["node_9","node_10"])
    for nid in list(nodes):
        calculate_fraud_exposure(nid)
        update_status(nid)
    update_all_guardians()

seed()

DEMO_CASES = {
    "whatsapp_fake_relative": {"source_node_id":"node_1","target_node_id":"node_10","industry":"banking","amount_anomaly":0.9,"routine_break":0.8},
    "legit_qr_payment": {"source_node_id":"node_2","target_node_id":"node_4","industry":"marketplace","amount_anomaly":0.1,"routine_break":0.1},
    "used_car_false_positive": {"source_node_id":"node_3","target_node_id":"node_14","industry":"banking","amount_anomaly":0.98,"routine_break":0.7},
    "wallet_drainer": {"source_node_id":"node_5","target_node_id":"node_9","industry":"crypto","amount_anomaly":0.92,"routine_break":0.85},
}

class RegisterNode(BaseModel):
    node_id: str
    user_id: str | None = None

class PulseIn(BaseModel):
    node_id: str

class CrossIn(BaseModel):
    node_a: str
    node_b: str
    shared_context_score: float = 82
    temporal_delta_ms: int = 35
    source: str = "relay_handshake"

class EvalIn(BaseModel):
    source_node_id: str
    target_node_id: str
    industry: str = "banking"
    amount_anomaly: float = 0.0
    routine_break: float = 0.0

@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request, "app_mode": APP_MODE, "database_url_set": bool(DATABASE_URL), "demo_mode": DEMO_MODE})

@app.get("/network", response_class=HTMLResponse)
def network(request: Request):
    return templates.TemplateResponse("network.html", {"request": request})

@app.get("/node", response_class=HTMLResponse)
def node(request: Request):
    return templates.TemplateResponse("node.html", {"request": request})

@app.get("/simulator", response_class=HTMLResponse)
def simulator(request: Request):
    return templates.TemplateResponse("simulator.html", {"request": request})

@app.get("/deploy", response_class=HTMLResponse)
def deploy_page(request: Request):
    return templates.TemplateResponse("deploy.html", {"request": request, "database_url_set": bool(DATABASE_URL), "app_mode": APP_MODE})

@app.get("/demo", response_class=HTMLResponse)
def demo_page(request: Request):
    return templates.TemplateResponse("demo.html", {"request": request})

@app.post("/api/register_node")
def register(payload: RegisterNode):
    node = ensure_node(payload.node_id, payload.user_id)
    update_all_guardians()
    return node

@app.post("/api/pulse")
def pulse(payload: PulseIn):
    node = ensure_node(payload.node_id)
    node["pulse_count"] += 1
    node["last_seen_at"] = now()
    node["nodal_mass"] = round(min(100, node["nodal_mass"] + 1.0), 2)
    calculate_guardian_score(payload.node_id)
    return {"node_id": payload.node_id, "pulse_count": node["pulse_count"], "last_seen_at": node["last_seen_at"], "guardian_score": node["guardian_score"], "is_guardian": node["is_guardian"]}

@app.get("/api/nodes")
def get_nodes():
    return list(nodes.values())

@app.post("/api/crosspulse")
def crosspulse(payload: CrossIn):
    ensure_node(payload.node_a); ensure_node(payload.node_b)
    rel = ensure_relationship(payload.node_a, payload.node_b)
    before = rel["weight"]
    rel["interactions"] += 1
    rel["weight"] = round(min(100, rel["weight"] + max(1.0, payload.shared_context_score/25)), 2)
    rel["shared_reality_avg"] = round((rel["shared_reality_avg"] + payload.shared_context_score)/2, 2)
    rel["last_interaction_at"] = now()
    nodes[payload.node_a]["cross_pulse_count"] += 1
    nodes[payload.node_b]["cross_pulse_count"] += 1
    event = {
        "crosspulse_id": f"cp_{len(cross_pulses)+1}",
        "node_a": payload.node_a, "node_b": payload.node_b,
        "relationship_weight_before": before,
        "relationship_weight_after": rel["weight"],
        "shared_context_score": payload.shared_context_score,
        "temporal_delta_ms": payload.temporal_delta_ms,
        "source": payload.source,
        "time": now()
    }
    cross_pulses.append(event)
    for nid in [payload.node_a, payload.node_b]:
        calculate_fraud_exposure(nid); update_status(nid); calculate_guardian_score(nid)
    return event

@app.post("/api/evaluate")
def evaluate(payload: EvalIn):
    ensure_node(payload.source_node_id); ensure_node(payload.target_node_id)
    bd = compute_breakdown(payload.source_node_id, payload.target_node_id, payload.amount_anomaly, payload.routine_break, payload.industry)
    if bd["decision"] == "BLOCK":
        fraud_flags.add(payload.target_node_id)
    calculate_fraud_exposure(payload.target_node_id)
    update_status(payload.target_node_id)
    update_all_guardians()
    ev_id = f"ev_{len(evaluations)+1}"
    audit = {
        "evaluation_id": ev_id,
        "timestamp": now(),
        "source_node_id": payload.source_node_id,
        "target_node_id": payload.target_node_id,
        "decision": bd["decision"],
        "trust_score": bd["trust_score"],
        "reason": bd["reason"],
        "breakdown": {"RDS": bd["rds"], "ASS": bd["ass"], "SRS": bd["srs"], "SC": bd["sc"], "FE": bd["fe"]},
        "recommended_action": bd["recommended_action"],
    }
    audit["audit_receipt"] = receipt(audit)
    evaluations.append(audit)
    return audit

@app.get("/api/evaluation/{evaluation_id}/audit")
def evaluation_audit(evaluation_id: str):
    for e in evaluations:
        if e["evaluation_id"] == evaluation_id:
            return e
    return JSONResponse({"error":"not_found"}, status_code=404)

@app.get("/api/fraud_clusters")
def fraud_clusters():
    clusters = []
    for flagged in sorted(fraud_flags):
        neighbors = []
        for r in relationships.values():
            if flagged in (r["a"], r["b"]):
                neighbors.append(r["b"] if r["a"] == flagged else r["a"])
        clusters.append({"root_node": flagged, "infected_nodes": len(neighbors), "spread_level": "high" if len(neighbors)>=3 else "medium" if neighbors else "low", "neighbors": neighbors})
    return {"clusters": clusters}

@app.get("/api/spread_map")
def spread_map():
    paths = []
    for flagged in fraud_flags:
        for r in relationships.values():
            if flagged in (r["a"], r["b"]):
                other = r["b"] if r["a"] == flagged else r["a"]
                paths.append({"from": flagged, "to": other, "weight": r["weight"], "risk_to": nodes[other]["fraud_exposure"]})
    return {"paths": paths}

@app.get("/api/guardian_algorithm")
def guardian_algorithm():
    return {
        "formula": "0.18*stability + 0.18*trust_rank + 0.15*nodal_mass + 0.12*pulse_factor + 0.17*cross_factor + 0.20*(100-fraud_exposure)",
        "threshold": "guardian if score >= 72, fraud_exposure < 25, degree >= 2"
    }

@app.get("/api/ecosystem_map")
def ecosystem_map():
    return {
        "layers": [
            "Users / Devices",
            "Client Apps / Wallets / Marketplaces / Banks",
            "MitoPulse SDK",
            "MitoPulse API",
            "Trust Graph + Fraud Hunter + MitoRelay",
            "Decision Engine",
            "Global Fraud Memory"
        ],
        "modules": [
            "Trust Graph Engine", "Shared Reality / MitoRelay", "Fraud Hunter Engine",
            "Guardian Nodes", "Fraud Spread Engine", "Audit Layer", "Industry Modules"
        ]
    }

@app.get("/api/demo_cases")
def demo_cases():
    return DEMO_CASES

@app.post("/api/demo/run/{case_name}")
def run_demo(case_name: str):
    if case_name not in DEMO_CASES:
        return JSONResponse({"error":"unknown_case"}, status_code=404)
    payload = DEMO_CASES[case_name]
    return evaluate(EvalIn(**payload))

@app.get("/api/platform_profile")
def platform_profile():
    return {
        "positioning": "Human legitimacy infrastructure",
        "integration": "SDK + backend API",
        "hosting": "Cloud-only deployment recommended",
        "b2b": {
            "clients": ["banks", "fintech", "marketplaces", "wallets"],
            "integration_flow": ["client app", "MitoPulse SDK", "client backend", "MitoPulse API", "decision response"]
        }
    }
