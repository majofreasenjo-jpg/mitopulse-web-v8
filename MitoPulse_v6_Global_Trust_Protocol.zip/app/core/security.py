from fastapi import Header, HTTPException
from app.core.config import settings

def verify_api_key(x_api_key: str | None = Header(default=None), x_tenant_id: str | None = Header(default=None)) -> str:
    if not x_tenant_id:
        raise HTTPException(status_code=400, detail="Missing X-Tenant-ID header")
    expected = settings.api_keys.get(x_tenant_id)
    if not expected or x_api_key != expected:
        raise HTTPException(status_code=401, detail="Invalid API key or tenant")
    return x_tenant_id
