import requests

class MitoPulseMobileSDK:
    def __init__(self, base_url: str, tenant_id: str, api_key: str):
        self.base_url = base_url.rstrip("/")
        self.headers = {
            "Content-Type": "application/json",
            "X-Tenant-ID": tenant_id,
            "X-API-Key": api_key,
        }

    def verify_contact(self, source: str, target: str, context: str = "financial_request") -> dict:
        resp = requests.post(
            f"{self.base_url}/api/precontact",
            headers=self.headers,
            json={"source": source, "target": target, "context": context},
            timeout=10,
        )
        resp.raise_for_status()
        return resp.json()

    def verify_link(self, source: str, target: str) -> dict:
        return self.verify_contact(source, target, "message")

    def verify_request(self, source: str, target: str, context: str) -> dict:
        return self.verify_contact(source, target, context)
