from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session
from fastapi.templating import Jinja2Templates

from app.core.database import get_db
from app.core.security import verify_api_key
from app.api.schemas import (
    BootstrapIn, InteractionIn, CrossPulseIn, AttackIn, PreContactIn,
    IdentityIn, SeedSimulationIn, SharedSignalIn, MobileVerifyIn
)
from app.services.platform import (
    bootstrap_pilot, capture_interaction, create_crosspulse, simulate_attack,
    get_state, PILOT_USERS, seed_simulation, publish_shared_signal, find_shared_signals
)
from app.services.analysis import run_trust_propagation, run_relational_identity, run_precontact, run_cluster_risk

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.post("/api/bootstrap")
def bootstrap(payload: BootstrapIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    bootstrap_pilot(db, tenant_id, payload.cluster)
    return {"ok": True, "tenant_id": tenant_id}

@router.post("/api/interaction")
def interaction(payload: InteractionIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    capture_interaction(db, tenant_id, payload.source, payload.target, payload.interaction_type, payload.context, payload.weight, payload.channel)
    return {"ok": True, "tenant_id": tenant_id}

@router.post("/api/crosspulse")
def crosspulse(payload: CrossPulseIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    pulse_id = create_crosspulse(db, tenant_id, payload.source, payload.target, payload.reason)
    return {"ok": True, "pulse_id": pulse_id}

@router.post("/api/attack")
def attack(payload: AttackIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    return {"ok": True, "alerts": simulate_attack(db, tenant_id, payload.attack_type)}

@router.post("/api/precontact")
def precontact(payload: PreContactIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    return run_precontact(db, tenant_id, payload.source, payload.target, payload.context)

@router.post("/api/identity")
def identity(payload: IdentityIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    return run_relational_identity(db, tenant_id, payload.node_id)

@router.get("/api/trust/{node_id}")
def trust(node_id: str, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    return run_trust_propagation(db, tenant_id, node_id)

@router.get("/api/cluster-risk/{node_id}")
def cluster(node_id: str, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    return run_cluster_risk(db, tenant_id, node_id)

@router.post("/api/simulation/seed")
def simulation_seed(payload: SeedSimulationIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    seed_simulation(db, tenant_id, payload.nodes, payload.fraud_ratio)
    return {"ok": True, "tenant_id": tenant_id, "nodes": payload.nodes, "fraud_ratio": payload.fraud_ratio}

@router.post("/api/protocol/publish-signal")
def publish_signal(payload: SharedSignalIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    row = publish_shared_signal(db, tenant_id, payload.shared_hash, payload.signal_type, payload.severity, payload.payload)
    return {"ok": True, "signal_id": row.id}

@router.get("/api/protocol/signals/{shared_hash}")
def get_signals(shared_hash: str, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    return {"ok": True, "shared_hash": shared_hash, "signals": find_shared_signals(db, shared_hash)}

@router.post("/api/mobile/verify")
def mobile_verify(payload: MobileVerifyIn, tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    return run_precontact(db, tenant_id, payload.source, payload.target, payload.context)

@router.get("/api/state")
def state(tenant_id: str = Depends(verify_api_key), db: Session = Depends(get_db)):
    return get_state(db, tenant_id)

@router.get("/api/pilot/users")
def users():
    return [{"node_id": nid, "display_name": label, "guardian": guardian} for nid, label, guardian in PILOT_USERS]

@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
