import hashlib
import requests

def stable_hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:24]

def evaluate_transfer(base_url: str, tenant: str, api_key: str, source_account: str, target_account: str, context: str = "financial_request"):
    headers = {"Content-Type": "application/json", "X-Tenant-ID": tenant, "X-API-Key": api_key}
    payload = {
        "source": stable_hash(source_account),
        "target": stable_hash(target_account),
        "context": context
    }
    r = requests.post(f"{base_url}/api/precontact", headers=headers, json=payload, timeout=10)
    r.raise_for_status()
    return r.json()
