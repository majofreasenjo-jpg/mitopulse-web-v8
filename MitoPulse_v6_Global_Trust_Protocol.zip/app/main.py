from fastapi import FastAPI
from app.core.database import Base, engine
from app.api.routes import router
from app.core.config import settings

Base.metadata.create_all(bind=engine)

app = FastAPI(title=settings.app_name)
app.include_router(router)
