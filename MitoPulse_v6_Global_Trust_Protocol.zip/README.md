# MitoPulse v6 Global Trust Protocol

Versión completa de desarrollo para continuar sobre la v5.

## Incluye
- PostgreSQL por Docker
- Redis por Docker
- multi-tenant
- API keys por tenant
- Fast Risk Engine
- Deep Graph Worker
- piloto real
- seed de simulación institucional (1000 nodos)
- trust propagation
- relational identity
- pre-contact risk
- cluster risk / fraud spread
- Shared Reality Protocol
- Mobile verify endpoint
- ejemplo de Mobile SDK
- ejemplo de conector bancario
- dashboard institucional

## Ejecución local rápida
```bash
cp .env.example .env
pip install -r requirements.txt
python run.py
```

## Ejecución con Docker
```bash
cp .env.example .env
docker compose up --build
```

## Demo por defecto
Tenant:
`bank_demo`

API key:
`demo-bank-key`

Abrir:
`http://127.0.0.1:8000`
