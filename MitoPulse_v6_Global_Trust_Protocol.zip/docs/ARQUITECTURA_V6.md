# Arquitectura v6

## Objetivo
Convertir MitoPulse de una plataforma antifraude a un protocolo global de confianza digital.

## Novedades respecto a v5
1. Shared Reality Protocol
2. Mobile verify endpoint
3. SDK móvil de ejemplo
4. conector bancario de ejemplo
5. separación más clara entre protocolo y producto

## Próximos pasos sugeridos
1. HMAC/JWT además de API keys
2. rate limiting por tenant
3. migraciones Alembic
4. métricas y observabilidad
5. SDK móvil real (Android / iOS)
6. protocolos de intercambio interinstitucional
