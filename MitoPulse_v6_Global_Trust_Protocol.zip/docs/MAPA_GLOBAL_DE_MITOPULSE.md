# Mapa global de MitoPulse

## 1. Capa de entrada
- bancos
- fintech
- marketplaces
- telcos
- wallets
- apps con SDK móvil

## 2. MitoPulse API
- `/api/precontact`
- `/api/identity`
- `/api/trust/{node_id}`
- `/api/cluster-risk/{node_id}`
- `/api/interaction`
- `/api/crosspulse`
- `/api/protocol/publish-signal`
- `/api/protocol/signals/{shared_hash}`
- `/api/mobile/verify`

## 3. Fast Risk Engine
Responde en milisegundos usando:
- pre-contact risk
- relational identity
- cluster risk
- propagated trust
- guardian decision

## 4. Deep Graph Engine
Trabaja de forma asíncrona en:
- trust propagation
- fraud spread
- recomputación de scores
- patrones topológicos

## 5. Shared Reality Protocol
Permite publicar y consultar señales entre instituciones sin compartir datos personales.
Cada institución aporta:
- hashes de nodos
- severidad
- tipo de señal
- contexto codificado

## 6. Guardian Network
Guardian nodes:
- bancos
- telcos
- nodos verificados
- usuarios con relaciones sólidas

## 7. Productos
- Fraud Social Detection Layer
- Pre-Contact Risk API
- Relational Identity API
- Institutional Dashboard
- Mobile SDK
- Shared Reality Consortium
- Global Trust Protocol

## 8. Secuencia de expansión
1. piloto real
2. marketplace / fintech / app
3. telco
4. primer banco
5. consorcio de señales compartidas
6. red global de confianza digital

## 9. Narrativa
Cloudflare protege servidores.
MitoPulse protege relaciones humanas digitales.
