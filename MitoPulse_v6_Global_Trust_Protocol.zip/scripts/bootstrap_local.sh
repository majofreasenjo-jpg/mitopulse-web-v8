#!/usr/bin/env bash
set -e
cp -n .env.example .env || true
pip install -r requirements.txt
python run.py
