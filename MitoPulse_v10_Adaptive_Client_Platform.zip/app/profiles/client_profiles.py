CLIENT_PROFILES = {
    "retail_bank": {
        "attacks": ["social_fraud","mule_accounts","new_beneficiary"],
        "channels": ["bank_app","phone","messaging"],
        "kpis": ["fraud_prevented","false_positive_rate","manual_review_load"]
    },
    "marketplace": {
        "attacks": ["fake_receipt","seller_cluster","buyer_scam"],
        "channels": ["marketplace_chat","bank_app","messaging"],
        "kpis": ["seller_risk_precision","fraud_ring_detection","chargebacks"]
    },
    "telco": {
        "attacks": ["sim_swap","number_change","identity_takeover"],
        "channels": ["telco_app","sms","bank_app"],
        "kpis": ["identity_risk","channel_change_alerts"]
    },
    "wallet_crypto": {
        "attacks": ["wallet_drainer","malicious_signature","withdrawal_cluster"],
        "channels": ["wallet","browser","messaging"],
        "kpis": ["withdrawal_fraud_blocked","wallet_cluster_detection"]
    }
}
