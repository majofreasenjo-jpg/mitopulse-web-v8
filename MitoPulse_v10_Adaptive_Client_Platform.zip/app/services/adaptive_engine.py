from app.profiles.client_profiles import CLIENT_PROFILES

def run_adaptive_simulation(customer_name, client_type, attack_type, nodes, fraud_ratio, shared_reality, mobile_verify):
    profile = CLIENT_PROFILES[client_type]
    fraud_nodes = int(nodes * fraud_ratio)

    block_rate = 0.60 if shared_reality else 0.48
    review_rate = 0.25 if mobile_verify else 0.18

    block = int(fraud_nodes * block_rate)
    review = int(fraud_nodes * review_rate)
    allow = nodes - block - review

    return {
        "customer": customer_name,
        "client_type": client_type,
        "attack_type": attack_type,
        "nodes": nodes,
        "fraud_nodes": fraud_nodes,
        "channels": profile["channels"],
        "kpis": profile["kpis"],
        "decision_projection": {
            "ALLOW": allow,
            "REVIEW": review,
            "BLOCK": block
        },
        "narrative": f"{customer_name} simulation for {client_type} detecting {attack_type} fraud."
    }
