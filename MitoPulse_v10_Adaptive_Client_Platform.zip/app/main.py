from fastapi import FastAPI
from app.core.database import Base, engine
from app.api.routes import router

Base.metadata.create_all(bind=engine)

app = FastAPI(title="MitoPulse v10 Adaptive Client Platform")
app.include_router(router)
