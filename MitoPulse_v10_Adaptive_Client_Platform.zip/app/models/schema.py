from sqlalchemy import Column, Integer, String, Text, DateTime
from datetime import datetime
from app.core.database import Base

def now():
    return datetime.utcnow()

class AdaptiveRun(Base):
    __tablename__ = "adaptive_runs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    customer_name = Column(String, nullable=False)
    client_type = Column(String, nullable=False)
    configuration_json = Column(Text, default="{}")
    result_json = Column(Text, default="{}")
    created_at = Column(DateTime, default=now)
