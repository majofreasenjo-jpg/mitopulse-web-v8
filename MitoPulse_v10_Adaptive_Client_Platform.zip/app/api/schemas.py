from pydantic import BaseModel, Field

class AdaptiveRequest(BaseModel):
    customer_name: str = "Cliente Demo"
    client_type: str = "retail_bank"
    attack_type: str = "social_fraud"
    nodes: int = Field(default=2000, ge=100, le=50000)
    fraud_ratio: float = Field(default=0.04, ge=0.0, le=0.25)
    shared_reality: bool = True
    mobile_verify: bool = True
