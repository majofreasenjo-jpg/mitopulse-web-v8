import json
from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.schema import AdaptiveRun
from app.api.schemas import AdaptiveRequest
from app.services.adaptive_engine import run_adaptive_simulation
from app.profiles.client_profiles import CLIENT_PROFILES

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/api/client-types")
def types():
    return CLIENT_PROFILES

@router.post("/api/run")
def run(payload: AdaptiveRequest, db: Session = Depends(get_db)):
    result = run_adaptive_simulation(
        payload.customer_name,
        payload.client_type,
        payload.attack_type,
        payload.nodes,
        payload.fraud_ratio,
        payload.shared_reality,
        payload.mobile_verify
    )

    row = AdaptiveRun(
        customer_name=payload.customer_name,
        client_type=payload.client_type,
        configuration_json=json.dumps(payload.model_dump()),
        result_json=json.dumps(result)
    )
    db.add(row)
    db.commit()
    db.refresh(row)

    return {"run_id": row.id, "result": result}

@router.get("/api/runs")
def runs(db: Session = Depends(get_db)):
    rows = db.query(AdaptiveRun).order_by(AdaptiveRun.id.desc()).limit(20).all()
    return [{
        "id": r.id,
        "customer_name": r.customer_name,
        "client_type": r.client_type,
        "created_at": r.created_at.isoformat() + "Z"
    } for r in rows]

@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
