MitoPulse v10 Adaptive Client Platform

Run:

pip install -r requirements.txt
python run.py

Open:
http://127.0.0.1:8000
