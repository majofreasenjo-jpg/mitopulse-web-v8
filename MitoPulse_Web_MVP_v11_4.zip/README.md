
MitoPulse v11.4

Investor demo oriented version.

Features
- executive landing page
- dashboard
- guided fraud demo
- simple network explorer

Deploy on:
Render / Railway / Fly.io
