
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from datetime import datetime
import random, json, hashlib

app = FastAPI(title="MitoPulse v11.4 Investor Demo")
templates = Jinja2Templates(directory="templates")

nodes = {}
relationships = {}
fraud_flags = {"node_9","node_10"}
evaluations = []

def now():
    return datetime.utcnow().isoformat()

def rel_key(a,b):
    return "::".join(sorted([a,b]))

def ensure_node(n):
    if n not in nodes:
        nodes[n] = {
            "node_id": n,
            "pulse_count": random.randint(2,15),
            "cross_pulse_count": random.randint(1,12),
            "trust_rank": random.randint(40,95),
            "nodal_mass": random.randint(30,90),
            "fraud_exposure": random.randint(0,40),
            "status": "healthy"
        }
    return nodes[n]

def ensure_relationship(a,b):
    k = rel_key(a,b)
    if k not in relationships:
        relationships[k] = {
            "a":a,"b":b,
            "weight": random.randint(20,90)
        }
    return relationships[k]

def seed():
    if nodes: return
    for i in range(1,16):
        ensure_node(f"node_{i}")
    edges=[("node_1","node_2"),("node_1","node_3"),("node_2","node_4"),("node_3","node_5"),
           ("node_9","node_10"),("node_7","node_8"),("node_6","node_7"),("node_4","node_6")]
    for a,b in edges:
        ensure_relationship(a,b)

seed()

class EvalIn(BaseModel):
    source_node_id:str
    target_node_id:str
    amount_anomaly:float=0.8
    routine_break:float=0.7
    industry:str="banking"

def compute_score(src,tgt,aa,rb):
    rel=relationships.get(rel_key(src,tgt))
    rds=rel["weight"] if rel else 10
    ass=nodes[tgt]["trust_rank"]
    srs=nodes[tgt]["cross_pulse_count"]*5
    sc=max(0,100-(aa*100+rb*100)/2)
    fe=nodes[tgt]["fraud_exposure"]
    trust=(rds+ass+srs+sc)/4-fe
    decision="VERIFY" if trust>75 else "REVIEW" if trust>55 else "BLOCK"
    return trust,decision,rds,ass,srs,sc,fe

@app.get("/",response_class=HTMLResponse)
def home(request:Request):
    return templates.TemplateResponse("home.html",{"request":request})

@app.get("/dashboard",response_class=HTMLResponse)
def dash(request:Request):
    return templates.TemplateResponse("dashboard.html",{"request":request})

@app.get("/network",response_class=HTMLResponse)
def net(request:Request):
    return templates.TemplateResponse("network.html",{"request":request})

@app.get("/demo",response_class=HTMLResponse)
def demo(request:Request):
    return templates.TemplateResponse("demo.html",{"request":request})

@app.get("/api/nodes")
def get_nodes():
    return list(nodes.values())

@app.post("/api/evaluate")
def evaluate(payload:EvalIn):
    ensure_node(payload.source_node_id)
    ensure_node(payload.target_node_id)
    trust,decision,rds,ass,srs,sc,fe=compute_score(
        payload.source_node_id,payload.target_node_id,
        payload.amount_anomaly,payload.routine_break)
    audit={
        "source":payload.source_node_id,
        "target":payload.target_node_id,
        "trust_score":round(trust,2),
        "decision":decision,
        "breakdown":{"RDS":rds,"ASS":ass,"SRS":srs,"SC":sc,"FE":fe},
        "time":now()
    }
    audit["receipt"]=hashlib.sha256(json.dumps(audit).encode()).hexdigest()[:20]
    evaluations.append(audit)
    return audit

@app.get("/api/summary")
def summary():
    n=len(nodes)
    high=sum(1 for x in nodes.values() if x["fraud_exposure"]>30)
    return {"nodes":n,"high_risk":high,"clusters":len(fraud_flags)}
