
# MitoPulse Pilot Real v2

Versión corregida del piloto real usando los nombres oficiales:
- Manuel
- Natalie
- Paulina
- Ricardo

## Incluye
- bootstrap del piloto real
- trust graph visual
- invitaciones reales
- simulación de ataques
- alertas y eventos

## Ejecutar
```bash
pip install fastapi uvicorn jinja2
uvicorn server:app --reload
```

Abrir:
http://127.0.0.1:8000
