
# Guía rápida — piloto real

## Invite codes
- ALPHA-MANUEL
- ALPHA-NATALIE
- ALPHA-PAULINA
- ALPHA-RICARDO

## Node IDs
- nd_manuel_01
- nd_natalie_01
- nd_paulina_01
- nd_ricardo_01

## Pasos
1. Ejecuta el servidor.
2. Abre la consola.
3. Presiona "Inicializar piloto real".
4. Verifica que aparezcan los 4 nodos reales.
5. Simula ataques y revisa alertas.
