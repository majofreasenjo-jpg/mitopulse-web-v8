
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from datetime import datetime
import random

app = FastAPI(title="MitoPulse Pilot Real v2")
templates = Jinja2Templates(directory="templates")

nodes = {}
edges = []
alerts = []
events = []

REAL_PILOT = [
    ("nd_manuel_01", "Manuel"),
    ("nd_natalie_01", "Natalie"),
    ("nd_paulina_01", "Paulina"),
    ("nd_ricardo_01", "Ricardo"),
]

INVITE_CODES = {
    "ALPHA-MANUEL": "nd_manuel_01",
    "ALPHA-NATALIE": "nd_natalie_01",
    "ALPHA-PAULINA": "nd_paulina_01",
    "ALPHA-RICARDO": "nd_ricardo_01",
}

class NodeRegister(BaseModel):
    node_id: str
    label: str | None = None

class Relation(BaseModel):
    source: str
    target: str
    interaction_type: str = "whatsapp_message"

class InviteResolve(BaseModel):
    invite_code: str

class AttackSim(BaseModel):
    attack_type: str = "number_change"

def ensure_node(node_id: str, label: str | None = None):
    if node_id not in nodes:
        nodes[node_id] = {
            "id": node_id,
            "label": label or node_id,
            "risk": 0.0,
            "type": "pilot" if node_id.startswith("nd_") else "external"
        }

@app.post("/api/pilot/resolve-invite")
def resolve_invite(payload: InviteResolve):
    nid = INVITE_CODES.get(payload.invite_code)
    if not nid:
        return {"ok": False, "error": "invalid_invite_code"}
    label = dict(REAL_PILOT).get(nid, nid)
    ensure_node(nid, label)
    return {"ok": True, "node_id": nid, "display_name": label}

@app.post("/api/node/register")
def register_node(payload: NodeRegister):
    ensure_node(payload.node_id, payload.label)
    return {"status": "registered", "node": nodes[payload.node_id]}

@app.post("/api/relation/add")
def add_relation(payload: Relation):
    if payload.source not in nodes or payload.target not in nodes:
        return {"error": "nodes must exist first"}
    edges.append({
        "source": payload.source,
        "target": payload.target,
        "interaction_type": payload.interaction_type,
        "created_at": datetime.utcnow().isoformat() + "Z"
    })
    events.append({
        "type": "relation",
        "source": payload.source,
        "target": payload.target,
        "interaction_type": payload.interaction_type,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    })
    return {"status": "relation_added"}

@app.post("/api/pilot/bootstrap")
def bootstrap():
    nodes.clear()
    edges.clear()
    alerts.clear()
    events.clear()

    for nid, label in REAL_PILOT:
        ensure_node(nid, label)

    base_edges = [
        ("nd_manuel_01", "nd_natalie_01", "whatsapp_message"),
        ("nd_manuel_01", "nd_ricardo_01", "call"),
        ("nd_natalie_01", "nd_paulina_01", "whatsapp_message"),
        ("nd_ricardo_01", "nd_paulina_01", "in_person"),
    ]
    for s, t, itype in base_edges:
        edges.append({
            "source": s,
            "target": t,
            "interaction_type": itype,
            "created_at": datetime.utcnow().isoformat() + "Z"
        })

    events.append({
        "type": "bootstrap",
        "message": "Pilot ring initialized with Manuel, Natalie, Paulina and Ricardo",
        "timestamp": datetime.utcnow().isoformat() + "Z"
    })

    return {
        "status": "pilot_initialized",
        "nodes": list(nodes.values()),
        "edges": edges
    }

@app.get("/api/graph")
def graph():
    return {"nodes": list(nodes.values()), "edges": edges}

@app.get("/api/alerts")
def get_alerts():
    return alerts

@app.get("/api/events")
def get_events():
    return list(reversed(events[-20:]))

@app.get("/api/pilot/users")
def get_pilot_users():
    return [{"node_id": nid, "display_name": label, "invite_code": code} for code, nid in INVITE_CODES.items() for nid2, label in REAL_PILOT if nid2 == nid]

@app.post("/api/attack/simulate")
def simulate_attack(payload: AttackSim):
    attack_type = payload.attack_type
    ext_id = "ext_attack_01"
    ensure_node(ext_id, "Attacker X")
    nodes[ext_id]["risk"] = 0.95

    if attack_type == "number_change":
        targets = ["nd_natalie_01", "nd_ricardo_01"]
        message = "Hola, cambié mi número. Necesito ayuda urgente."
    elif attack_type == "marketplace":
        targets = ["nd_ricardo_01"]
        message = "Ya transferí. Revisa el comprobante y envía el producto."
    else:
        targets = ["nd_paulina_01"]
        message = "Firma esta solicitud urgente ahora."

    for tgt in targets:
        risk_score = round(random.uniform(0.68, 0.94), 3)
        nodes[tgt]["risk"] = max(nodes[tgt]["risk"], min(1.0, risk_score * 0.55))
        alerts.append({
            "attack_type": attack_type,
            "source": ext_id,
            "target": tgt,
            "risk_score": risk_score,
            "guardian_decision": "BLOCK" if risk_score >= 0.75 else "REVIEW",
            "message": message,
            "timestamp": datetime.utcnow().isoformat() + "Z"
        })
        events.append({
            "type": "attack",
            "attack_type": attack_type,
            "source": ext_id,
            "target": tgt,
            "message": message,
            "timestamp": datetime.utcnow().isoformat() + "Z"
        })

    return {
        "status": "simulated",
        "attack_type": attack_type,
        "targets": targets,
        "alerts_created": len(targets)
    }

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
