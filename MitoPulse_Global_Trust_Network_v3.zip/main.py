
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import random

app = FastAPI(title="MitoPulse Global Trust Network v3")
templates = Jinja2Templates(directory="templates")

nodes = [
 {"id":"Manuel","group":"family"},
 {"id":"Ana","group":"family"},
 {"id":"Bruno","group":"market"},
 {"id":"Carla","group":"market"},
 {"id":"Guardian","group":"system"},
]

links = [
 {"source":"Manuel","target":"Ana"},
 {"source":"Ana","target":"Carla"},
 {"source":"Manuel","target":"Bruno"},
 {"source":"Bruno","target":"Carla"}
]

attacks=[
 {"id":"bank","name":"Fraude bancario"},
 {"id":"crypto","name":"Phishing wallet"},
 {"id":"market","name":"Estafa marketplace"},
 {"id":"telco","name":"Cambio de numero telco"}
]

@app.get("/", response_class=HTMLResponse)
def home(request:Request):
    return templates.TemplateResponse("index.html",{"request":request})

@app.get("/api/graph")
def graph():
    return {"nodes":nodes,"links":links}

@app.get("/api/attacks")
def get_attacks():
    return attacks

@app.post("/api/run/{attack}")
def run_attack(attack:str):
    legitimacy=round(random.uniform(0.2,0.9),3)
    risk=round(1-legitimacy,3)
    decision="BLOCK" if risk>0.65 else "REVIEW" if risk>0.4 else "ALLOW"
    return {
        "attack":attack,
        "legitimacy_score":legitimacy,
        "risk_score":risk,
        "guardian_decision":decision
    }
