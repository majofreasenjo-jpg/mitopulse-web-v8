
# MitoPulse Global Trust Network v3

Demo avanzada con:

- Visualizador de Trust Graph
- Simulador de ataques
- Guardian Decision Engine

## Ejecutar

pip install fastapi uvicorn jinja2

uvicorn main:app --reload

Abrir:

http://127.0.0.1:8000
